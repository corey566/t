<?php

return [
    'name' => 'Connector',
    'module_version' => '3.3',
    'pid' => 9,
];