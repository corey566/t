<?php

return [
    'spreadsheet' => 'جدول',
    'spreadsheet_module' => 'وحدة جدول البيانات',
    'sheets' => 'أوراق',
    'my_spreadsheets' => 'جداول البيانات الخاصة بي',
    'create_spreadsheet' => 'أنشئ جدول بيانات',
    'no_spreadsheet_found' => 'لم يتم العثور على جدول بيانات!',
    'view_spreadsheet' => 'عرض جدول البيانات',
    'share' => 'شارك',
    'share_excel' => 'مشاركة جدول البيانات',
    'todos' => 'تودوس',
    'access_spreadsheet' => 'الوصول إلى جدول البيانات',
    'create_spreadsheet' => 'قم بإنشاء جدول بيانات',
    'spreadsheet_shared_notif_text' => ': shared_by شارك جدول بيانات -: name',
    'shared_by' => 'مشترك بواسطة: name',
    'created_by' => 'تم إنشاؤه بواسطة: name',
];
