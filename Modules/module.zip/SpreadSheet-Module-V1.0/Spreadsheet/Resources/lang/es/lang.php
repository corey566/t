<?php

return [
    'spreadsheet' => 'Hoja de cálculo',
    'spreadsheet_module' => 'Módulo de hoja de cálculo',
    'sheets' => 'Hojas',
    'my_spreadsheets' => 'Mis hojas de cálculo',
    'create_spreadsheet' => 'Crear hoja de cálculo',
    'no_spreadsheet_found' => '¡No se ha encontrado ninguna hoja de cálculo!',
    'view_spreadsheet' => 'Ver hoja de cálculo',
    'share' => 'Cuota',
    'share_excel' => 'Compartir hoja de cálculo',
    'todos' => 'Todos',
    'access_spreadsheet' => 'Acceder a la hoja de cálculo',
    'create_spreadsheet' => 'Crear hoja de cálculo',
    'spreadsheet_shared_notif_text' => ':shared_by compartió una hoja de cálculo - :name',
    'shared_by' => 'Compartido por : :nombre',
    'created_by' => 'Creado por : :nombre',
];
