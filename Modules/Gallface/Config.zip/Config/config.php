<?php

return [
    'name' => 'Gallface',
    'module_version' => '5.0',
	'pid' => 22,
];
