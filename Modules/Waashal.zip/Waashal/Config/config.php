<?php

return [
    'name' => 'Waashal',
    'module_version' => '1.2',
];
