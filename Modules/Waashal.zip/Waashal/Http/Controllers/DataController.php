<?php

namespace Modules\Waashal\Http\Controllers;

use App\Utils\ModuleUtil;
use App\Utils\Util;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Menu;

class DataController extends Controller
{
    /**
     * Superadmin package permissions
     *
     * @return array
     */
    public function superadmin_package()
    {
        return [
            [
                'name' => 'Waashal_module',
                'label' => __('Waashal::lang.Waashal_module'),
                'default' => false,
            ],
        ];
    }

    /**
     * Adds Waashal menus
     *
     * @return null
     */
    public function modifyAdminMenu()
    {
        $business_id = session()->get('user.business_id');
        $module_util = new ModuleUtil();

        $is_Waashal_enabled = (bool) $module_util->hasThePermissionInSubscription($business_id, 'Waashal_module');

        $commonUtil = new Util();
        $is_admin = $commonUtil->is_admin(auth()->user(), $business_id);

        if ($is_Waashal_enabled) {
            $menu = Menu::instance('admin-sidebar-menu');
            $menu->url(action([\Modules\Waashal\Http\Controllers\WaashalController::class, 'dashboard']), __('Waashal::lang.Waashal_module'), ['icon' => 'fab fa-whatsapp', 'active' => request()->segment(1) == 'Waashal'])->order(70);
        }
    }
}
