<?php

namespace Modules\Waashal\Http\Controllers;

use App\BusinessLocation;
use App\Contact;
use App\Transaction;
use App\User;
use App\Utils\BusinessUtil;
use App\Utils\ModuleUtil;
use App\Utils\TransactionUtil;
use App\Utils\ProductUtil;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Yajra\DataTables\Facades\DataTables;
use Modules\Waashal\Entities\WaashalSetting;
use Illuminate\Support\Facades\Log;

class InvoiceController extends Controller
{
    protected $businessUtil;
    protected $transactionUtil;
    protected $moduleUtil;
    protected $productUtil;

    /**
     * Constructor
     */
    public function __construct(BusinessUtil $businessUtil, TransactionUtil $transactionUtil, ModuleUtil $moduleUtil, ProductUtil $productUtil)
    {
        $this->businessUtil = $businessUtil;
        $this->transactionUtil = $transactionUtil;
        $this->moduleUtil = $moduleUtil;
        $this->productUtil = $productUtil;
    }

    /**
     * Display the sales invoices page.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $business_id = request()->session()->get('user.business_id');
        $is_woocommerce = $this->moduleUtil->isModuleInstalled('Woocommerce');
        $is_crm = $this->moduleUtil->isModuleInstalled('Crm');
        $is_tables_enabled = $this->transactionUtil->isModuleEnabled('tables');
        $is_service_staff_enabled = $this->transactionUtil->isModuleEnabled('service_staff');
        $is_types_service_enabled = $this->moduleUtil->isModuleEnabled('types_of_service');

        if ($request->ajax()) {
            $payment_types = $this->transactionUtil->payment_types(null, true, $business_id);
            $shipping_statuses = $this->transactionUtil->shipping_statuses();

            $sells = $this->transactionUtil->getListSells($business_id, 'sell')
                ->whereNull('transactions.sub_type'); // Only display sell invoices

            $permitted_locations = auth()->user()->permitted_locations();
            if ($permitted_locations != 'all') {
                $sells->whereIn('transactions.location_id', $permitted_locations);
            }

            if ($request->has('created_by')) {
                $created_by = $request->get('created_by');
                if (!empty($created_by)) {
                    $sells->where('transactions.created_by', $created_by);
                }
            }

            if (!auth()->user()->can('direct_sell.view')) {
                $sells->where(function ($q) {
                    if (auth()->user()->hasAnyPermission(['view_own_sell_only', 'access_own_shipping'])) {
                        $q->where('transactions.created_by', request()->session()->get('user.id'));
                    }
                    if (auth()->user()->hasAnyPermission(['view_commission_agent_sell', 'access_commission_agent_shipping'])) {
                        $q->orWhere('transactions.commission_agent', request()->session()->get('user.id'));
                    }
                });
            }

            if (!empty($request->input('payment_status')) && $request->input('payment_status') != 'overdue') {
                $sells->where('transactions.payment_status', $request->input('payment_status'));
            } elseif ($request->input('payment_status') == 'overdue') {
                $sells->whereIn('transactions.payment_status', ['due', 'partial'])
                    ->whereNotNull('transactions.pay_term_number')
                    ->whereNotNull('transactions.pay_term_type')
                    ->whereRaw("IF(transactions.pay_term_type='days', DATE_ADD(transactions.transaction_date, INTERVAL transactions.pay_term_number DAY) < CURDATE(), DATE_ADD(transactions.transaction_date, INTERVAL transactions.pay_term_number MONTH) < CURDATE())");
            }

            if (!empty($request->input('location_id'))) {
                $sells->where('transactions.location_id', $request->input('location_id'));
            }

            if (!empty($request->input('customer_id'))) {
                $sells->where('contacts.id', $request->input('customer_id'));
            }

            if (!empty($request->input('start_date')) && !empty($request->input('end_date'))) {
                $sells->whereDate('transactions.transaction_date', '>=', $request->input('start_date'))
                      ->whereDate('transactions.transaction_date', '<=', $request->input('end_date'));
            }

            if ($request->input('only_subscriptions')) {
                $sells->where(function ($q) {
                    $q->whereNotNull('transactions.recur_parent_id')
                      ->orWhere('transactions.is_recurring', 1);
                });
            }

            if (!empty($request->input('sales_cmsn_agnt'))) {
                $sells->where('transactions.commission_agent', $request->input('sales_cmsn_agnt'));
            }

            if (!empty($request->input('service_staffs'))) {
                $sells->where('transactions.res_waiter_id', $request->input('service_staffs'));
            }

            if (!empty($request->input('shipping_status'))) {
                $sells->where('transactions.shipping_status', $request->input('shipping_status'));
            }

            if (!empty($request->input('payment_method'))) {
                $sells->whereHas('payment_lines', function ($query) use ($request) {
                    $query->where('method', $request->input('payment_method'));
                });
            }

            if (!empty($request->input('source'))) {
                if ($request->input('source') == 'woocommerce') {
                    $sells->whereNotNull('transactions.woocommerce_order_id');
                } else {
                    $sells->where('transactions.source', $request->input('source'));
                }
            }

            $sells->groupBy('transactions.id');

            $datatable = Datatables::of($sells)
                ->addColumn('action', function ($row) {
                    $html = '<div class="btn-group">
                                <button type="button" class="tw-dw-btn tw-dw-btn-xs tw-dw-btn-outline tw-dw-btn-info tw-w-max dropdown-toggle" 
                                        data-toggle="dropdown" aria-expanded="false">'.
                                        __('waashal::lang.actions').
                                        '<span class="caret"></span><span class="sr-only">Toggle Dropdown</span>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-left" role="menu">';
                    if (auth()->user()->can('sell.view') || auth()->user()->can('direct_sell.view') || auth()->user()->can('view_own_sell_only')) {
                        $html .= '<li><a href="#" data-href="'.action([\App\Http\Controllers\SellController::class, 'show'], [$row->id]).'" class="btn-modal" data-container=".view_modal"><i class="fas fa-eye" aria-hidden="true"></i> '.__('waashal::lang.view').'</a></li>';
                        $html .= '<li><a href="#" data-href="'.route('waashal.invoices.send_whatsapp', [$row->id]).'" class="send-invoice-whatsapp"><i class="fab fa-whatsapp" aria-hidden="true"></i> '.__('waashal::lang.send_invoice').'</a></li>';
                    }
                    $html .= '</ul></div>';
                    return $html;
                })
                ->removeColumn('id')
                ->editColumn('final_total', '<span class="final-total" data-orig-value="{{$final_total}}">@format_currency($final_total)</span>')
                ->editColumn('total_paid', '<span class="total-paid" data-orig-value="{{$total_paid}}">@format_currency($total_paid)</span>')
                ->editColumn('transaction_date', '{{@format_datetime($transaction_date)}}')
                ->editColumn('payment_status', function ($row) {
                    $payment_status = Transaction::getPaymentStatus($row);
                    return (string) view('sell.partials.payment_status', ['payment_status' => $payment_status, 'id' => $row->id]);
                })
                ->addColumn('total_remaining', function ($row) {
                    $total_remaining = $row->final_total - $row->total_paid;
                    return '<span class="payment_due" data-orig-value="'.$total_remaining.'">'.$this->transactionUtil->num_f($total_remaining, true).'</span>';
                })
                ->addColumn('return_due', function ($row) {
                    $return_due_html = '';
                    if (!empty($row->return_exists)) {
                        $return_due = $row->amount_return - $row->return_paid;
                        $return_due_html .= '<a href="'.action([\App\Http\Controllers\TransactionPaymentController::class, 'show'], [$row->return_transaction_id]).'" class="view_purchase_return_payment_modal"><span class="sell_return_due" data-orig-value="'.$return_due.'">'.$this->transactionUtil->num_f($return_due, true).'</span></a>';
                    }
                    return $return_due_html;
                })
                ->editColumn('invoice_no', function ($row) use ($is_crm) {
                    $invoice_no = $row->invoice_no;
                    if (!empty($row->woocommerce_order_id)) {
                        $invoice_no .= ' <i class="fab fa-wordpress text-primary no-print" title="'.__('waashal::lang.synced_from_woocommerce').'"></i>';
                    }
                    if (!empty($row->return_exists)) {
                        $invoice_no .= '  <small class="label bg-red label-round no-print" title="'.__('waashal::lang.some_qty_returned_from_sell').'"><i class="fas fa-undo"></i></small>';
                    }
                    if (!empty($row->is_recurring)) {
                        $invoice_no .= '  <small class="label bg-red label-round no-print" title="'.__('waashal::lang.subscribed_invoice').'"><i class="fas fa-recycle"></i></small>';
                    }
                    if (!empty($row->recur_parent_id)) {
                        $invoice_no .= '  <small class="label bg-info label-round no-print" title="'.__('waashal::lang.subscription_invoice').'"><i class="fas fa-recycle"></i></small>';
                    }
                    if (!empty($row->is_export)) {
                        $invoice_no .= '</br><small class="label label-default no-print" title="'.__('waashal::lang.export').'">'.__('waashal::lang.export').'</small>';
                    }
                    if ($is_crm && !empty($row->crm_is_order_request)) {
                        $invoice_no .= '  <small class="label bg-yellow label-round no-print" title="'.__('crm::lang.order_request').'"><i class="fas fa-tasks"></i></small>';
                    }
                    return $invoice_no;
                })
                ->editColumn('shipping_status', function ($row) use ($shipping_statuses) {
                    $status_color = !empty($this->transactionUtil->shipping_status_colors[$row->shipping_status]) ? $this->transactionUtil->shipping_status_colors[$row->shipping_status] : 'bg-gray';
                    return !empty($row->shipping_status) ? '<span class="label '.$status_color.'">'.$shipping_statuses[$row->shipping_status].'</span>' : '';
                })
                ->addColumn('conatct_name', '@if(!empty($supplier_business_name)) {{$supplier_business_name}}, <br> @endif {{$name}}')
                ->editColumn('total_items', '{{@format_quantity($total_items)}}')
                ->filterColumn('conatct_name', function ($query, $keyword) {
                    $query->where(function ($q) use ($keyword) {
                        $q->where('contacts.name', 'like', "%{$keyword}%")
                          ->orWhere('contacts.supplier_business_name', 'like', "%{$keyword}%");
                    });
                })
                ->addColumn('payment_methods', function ($row) use ($payment_types) {
                    $methods = array_unique($row->payment_lines->pluck('method')->toArray());
                    $count = count($methods);
                    $payment_method = '';
                    if ($count == 1) {
                        $payment_method = $payment_types[$methods[0]] ?? '';
                    } elseif ($count > 1) {
                        $payment_method = __('waashal::lang.checkout_multi_pay');
                    }
                    return !empty($payment_method) ? '<span class="payment-method" data-orig-value="'.$payment_method.'" data-status-name="'.$payment_method.'">'.$payment_method.'</span>' : '';
                });

            $rawColumns = ['final_total', 'action', 'total_paid', 'total_remaining', 'payment_status', 'invoice_no', 'shipping_status', 'payment_methods', 'return_due', 'conatct_name'];
            return $datatable->rawColumns($rawColumns)->make(true);
        }

        $business_locations = BusinessLocation::forDropdown($business_id, false);
        $customers = Contact::customersDropdown($business_id, false);
        $sales_representative = User::forDropdown($business_id, false, false, true);
        $is_cmsn_agent_enabled = request()->session()->get('business.sales_cmsn_agnt');
        $commission_agents = $is_cmsn_agent_enabled ? User::forDropdown($business_id, false, true, true) : [];
        $service_staffs = $this->productUtil->isModuleEnabled('service_staff') ? $this->productUtil->serviceStaffDropdown($business_id) : null;
        $shipping_statuses = $this->transactionUtil->shipping_statuses();
        $sources = $this->transactionUtil->getSources($business_id);
        if ($is_woocommerce) {
            $sources['woocommerce'] = 'Woocommerce';
        }
        $payment_types = $this->transactionUtil->payment_types(null, true, $business_id);

        return view('Waashal::invoices.index')
            ->with(compact('business_locations', 'customers', 'sales_representative', 'is_cmsn_agent_enabled', 'commission_agents', 'service_staffs', 'is_tables_enabled', 'is_service_staff_enabled', 'is_types_service_enabled', 'shipping_statuses', 'sources', 'payment_types'));
    }

    /**
     * Send invoice details via WhatsApp
     *
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function sendInvoiceWhatsApp($id)
    {
        try {
            $business_id = request()->session()->get('user.business_id');
            $sms_settings = WaashalSetting::where('business_id', $business_id)
                ->where('is_default', true)
                ->with('brands')
                ->first();

            if (!$sms_settings) {
                Log::warning('Waashal: No default settings found for business_id ' . $business_id);
                return response()->json(['error' => __('waashal::lang.settings_not_found')], 400);
            }

            // Fetch transaction with related data
            $transaction = Transaction::where('business_id', $business_id)
                ->where('id', $id)
                ->with([
                    'contact',
                    'sell_lines.product.brand',
                    'sell_lines.variations',
                    'payment_lines',
                    'location'
                ])
                ->firstOrFail();

            if (!$transaction->contact || empty($transaction->contact->mobile)) {
                Log::warning('Waashal: No mobile number found for transaction ' . $id);
                return response()->json(['error' => __('waashal::lang.customer_mobile_not_found')], 400);
            }

            // Format mobile number
            $to = $transaction->contact->mobile;
            if (preg_match('/^0[0-9]{10}$/', $to)) {
                $to = '2' . $to;
            }

            // Determine the brand name
            $brand_name = $sms_settings->brands->isNotEmpty() ? $sms_settings->brands->first()->name : 'GM Axel';

            // Prepare order details
            $order_details = $transaction->sell_lines->map(function ($sell_line) {
                $product_name = $sell_line->product->name;
                if ($sell_line->variations && $sell_line->variations->name !== 'DUMMY') {
                    $product_name .= ' (' . $sell_line->variations->name . ')';
                }
                $quantity = $this->transactionUtil->num_f($sell_line->quantity, false);
                $price = $this->transactionUtil->num_f($sell_line->unit_price_inc_tax * $sell_line->quantity, true);
                return "• $product_name - $quantity - $price";
            })->implode("\n");

            // Get payment method
            $payment_methods = $transaction->payment_lines->pluck('method')->unique();
            $payment_method = $payment_methods->count() === 1 
                ? $this->transactionUtil->payment_types(null, true, $business_id)[$payment_methods->first()] ?? __('waashal::lang.unknown')
                : __('waashal::lang.checkout_multi_pay');

            // Get order status
            $order_status = $transaction->status === 'final' ? __('waashal::lang.completed') : __('waashal::lang.' . $transaction->status);

            // Get payment status
            $payment_status = Transaction::getPaymentStatus($transaction);
            $payment_status_text = __('waashal::lang.' . $payment_status);

            // Prepare invoice message
            $message = sprintf(
                "شكرًا لاختيارك %s 🥰\n\n" .
                "طلبك اتأكد بنجاح، ودي تفاصيل الفاتورة الخاصة بيك:\n" .
                "• رقم الفاتورة: %s\n" .
                "• تفاصيل الطلب:\n%s\n" .
                "• الإجمالي: %s\n" .
                "• حالة الطلب: %s\n" .
                "• طريقة الدفع: %s\n" .
                "• حالة الدفع: %s\n" .
                "• تاريخ الطلب: %s\n\n" .
                "السعر اللي فوق غير شامل مصاريف الشحن\n" .
                "وهي 50 جنية للقاهرة و65 جنية لباقي المحافظات\n\n" .
                "طلبك دلوقتي تحت التجهيز، وهيكون في طريقه لحضرتك قريب جدًا.\n" .
                "لو محتاجة أي حاجة أو عندك أي استفسار، تواصلي معانا على الواتساب أو كلمينا على صفحتنا الفيسبوك أو الانستجرام.\n\n" .
                "شكرًا على ثقتك في %s، ونتمنى منتجاتنا تعجبك ❤️",
                $brand_name,
                $transaction->invoice_no,
                $order_details,
                $this->transactionUtil->num_f($transaction->final_total, true),
                $order_status,
                $payment_method,
                $payment_status_text,
                $this->transactionUtil->format_date($transaction->transaction_date),
                $brand_name
            );

            $curl = curl_init();

            $postData = [
                'appkey' => $sms_settings->appkey,
                'authkey' => $sms_settings->authkey,
                'to' => $to,
                'message' => $message,
                'sandbox' => $sms_settings->sandbox ? 'true' : 'false',
            ];

            curl_setopt_array($curl, [
                CURLOPT_URL => 'https://sender-wa.ashsender.online/api/create-message',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => $postData,
            ]);

            $response = curl_exec($curl);
            $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);

            curl_close($curl);

            Log::info('Waashal: Sending invoice WhatsApp message', $postData);
            Log::info('Waashal: Invoice WhatsApp Response', ['http_code' => $http_code, 'response' => $response]);

            if ($http_code == 200) {
                return response()->json(['success' => true, 'msg' => __('waashal::lang.message_sent')]);
            } else {
                $decoded_response = json_decode($response, true);
                $error_message = $decoded_response['error'] ?? __('waashal::lang.message_failed');
                return response()->json(['error' => $error_message], 400);
            }
        } catch (\Exception $e) {
            Log::error('Waashal: Exception in sendInvoiceWhatsApp - ' . $e->getMessage());
            return response()->json(['error' => __('waashal::lang.message_failed') . ': ' . $e->getMessage()], 500);
        }
    }
}