<?php

namespace Modules\Waashal\Http\Controllers;

use App\Contact;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Waashal\Entities\WaashalSetting;

class SupplierController extends Controller
{
    /**
     * Display the suppliers page.
     */
    public function index(Request $request)
    {
        $business_id = session('business.id');

        // Filter and pagination
        $query = Contact::where('business_id', $business_id)
            ->where('type', 'supplier')
            ->active();

        if ($request->filled('search')) {
            $search = $request->input('search');
            $query->where(function ($q) use ($search) {
                $q->where('name', 'LIKE', "%$search%")
                  ->orWhere('mobile', 'LIKE', "%$search%");
            });
        }

        $suppliers = $query->paginate(20);
        $configurations = WaashalSetting::where('business_id', $business_id)->get();

        return view('Waashal::suppliers', compact('suppliers', 'configurations'));
    }

    /**
     * Handle sending a message to a supplier.
     */
    public function sendMessage(Request $request)
    {
        $request->validate([
            'to' => 'required|string',
            'message' => 'required|string|max:1000',
            'configuration_id' => 'required|exists:waashal_settings,id',
        ]);

        $business_id = session('business.id');
        if (!$business_id) {
            return redirect()->back()->with('status', __('waashal::lang.business_id_missing'));
        }

        $settings = WaashalSetting::where('business_id', $business_id)
            ->with('brands')
            ->findOrFail($request->configuration_id);

        // تعديل رقم الهاتف: إذا بدأ بـ 0، أضف 2 قبل الرقم
        $to = $request->to;
        if (preg_match('/^0[0-9]{10}$/', $to)) {
            $to = '2' . $to;
        }

        // إضافة اسم العلامة التجارية إذا وجدت
        $message = $request->message;
        if ($settings->brands->isNotEmpty()) {
            $brand_name = $settings->brands->first()->name;
            $message = "مرحبا بك في {$brand_name}\n{$message}";
        }

        $postData = [
            'appkey' => $settings->appkey,
            'authkey' => $settings->authkey,
            'to' => $to,
            'message' => $message,
            'sandbox' => $settings->sandbox ? 'true' : 'false',
        ];

        \Log::info('Sending Data to API', $postData);

        $curl = curl_init();

        curl_setopt_array($curl, [
            CURLOPT_URL => 'https://sender-wa.ashsender.online/api/create-message', // توحيد رابط الـ API
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $postData,
        ]);

        $response = curl_exec($curl);
        $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);

        \Log::info('API Response Details', ['response' => $response, 'http_code' => $http_code]);

        if (curl_errno($curl)) {
            $error_msg = curl_error($curl);
            curl_close($curl);
            return redirect()->back()->with('status', __('waashal::lang.message_failed') . ': ' . $error_msg);
        }

        curl_close($curl);

        if ($http_code == 200) {
            return redirect()->back()->with('status', __('waashal::lang.message_sent'));
        } else {
            $decoded_response = json_decode($response, true);
            $error_message = $decoded_response['error'] ?? __('waashal::lang.message_failed');
            return redirect()->back()->with('status', __('waashal::lang.message_failed') . ': ' . $error_message);
        }
    }
}