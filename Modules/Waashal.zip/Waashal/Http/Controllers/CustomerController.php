<?php

namespace Modules\Waashal\Http\Controllers;

use App\Contact;
use App\Transaction;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Waashal\Entities\WaashalSetting;

class CustomerController extends Controller
{
    /**
     * Display the customers page.
     */
    public function index(Request $request)
    {
        $business_id = session('business.id');

        // Filter and pagination
        $query = Contact::where('business_id', $business_id)
            ->where('type', 'customer')
            ->active();

        if ($request->filled('search')) {
            $search = $request->input('search');
            $query->where(function ($q) use ($search) {
                $q->where('name', 'LIKE', "%$search%")
                  ->orWhere('mobile', 'LIKE', "%$search%");
            });
        }

        $customers = $query->paginate(20);
        $configurations = WaashalSetting::where('business_id', $business_id)->get();

        return view('Waashal::customers', compact('customers', 'configurations'));
    }

    /**
     * Handle sending a message to a customer.
     */
    public function sendMessage(Request $request)
    {
        $this->validateRequest($request);

        return $this->sendToApi($request->to, $request->message, $request->configuration_id);
    }

    /**
     * Fetch account statement for a customer.
     */
    public function fetchAccountStatement($customer_id)
    {
        $statement = $this->generateAccountStatement($customer_id);

        if (is_array($statement) && isset($statement['error'])) {
            return response()->json($statement, 404);
        }

        return response()->json(['statement' => $statement]);
    }

    /**
     * Send account statement to a customer's mobile.
     */
    public function sendAccountStatement(Request $request)
    {
        $request->validate([
            'customer_id' => 'required|integer',
            'configuration_id' => 'required|exists:waashal_settings,id',
        ]);

        $customer_id = $request->customer_id;

        // Generate account statement
        $statement = $this->generateAccountStatement($customer_id);

        if (is_array($statement) && isset($statement['error'])) {
            return redirect()->back()->with('status', $statement['error']);
        }

        // Retrieve customer mobile number
        $customer = Contact::find($customer_id);
        if (!$customer) {
            return redirect()->back()->with('status', __('waashal::lang.customer_not_found'));
        }

        // Send account statement as message
        return $this->sendToApi($customer->mobile, $statement, $request->configuration_id);
    }

    /**
     * Generate account statement for a customer.
     */
    private function generateAccountStatement($customer_id)
    {
        $business_id = session('business.id');

        $customer = Contact::where('id', $customer_id)
            ->where('business_id', $business_id)
            ->first();

        if (!$customer) {
            return ['error' => __('waashal::lang.customer_not_found')];
        }

        $transactions = Transaction::where('contact_id', $customer_id)
            ->orderBy('transaction_date', 'desc')
            ->get();

        $statement = __('waashal::lang.account_statement_for', ['name' => $customer->name]) . "\n";
        $statement .= "--------------------------\n";

        foreach ($transactions as $transaction) {
            $statement .= __('waashal::lang.date') . ": {$transaction->transaction_date}, ";
            $statement .= __('waashal::lang.type') . ": {$transaction->type}, ";
            $statement .= __('waashal::lang.amount') . ": {$transaction->final_total}\n";
        }

        return $statement;
    }

    /**
     * Send a message to the API.
     */
    private function sendToApi($to, $message, $configuration_id = null)
    {
        $business_id = session('business.id');

        // استرجاع الإعداد بناءً على configuration_id أو الإعداد الافتراضي
        $query = WaashalSetting::where('business_id', $business_id)->with('brands');
        if ($configuration_id) {
            $settings = $query->findOrFail($configuration_id);
        } else {
            $settings = $query->where('is_default', true)->first();
        }

        if (!$settings) {
            return redirect()->back()->with('status', __('waashal::lang.no_settings'));
        }

        // تعديل رقم الهاتف: إذا بدأ بـ 0، أضف 2 قبل الرقم
        if (preg_match('/^0[0-9]{10}$/', $to)) {
            $to = '2' . $to;
        }

        // إضافة اسم العلامة التجارية إذا وجدت
        if ($settings->brands->isNotEmpty()) {
            $brand_name = $settings->brands->first()->name;
            $message = "مرحبا بك في {$brand_name}\n{$message}";
        }

        $postData = [
            'appkey' => $settings->appkey,
            'authkey' => $settings->authkey,
            'to' => $to,
            'message' => $message,
            'sandbox' => $settings->sandbox ? 'true' : 'false',
        ];

        \Log::info('Sending Data to API', $postData);

        $curl = curl_init();

        curl_setopt_array($curl, [
            CURLOPT_URL => 'https://sender-wa.ashsender.online/api/create-message', // توحيد رابط الـ API
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $postData,
        ]);

        $response = curl_exec($curl);
        $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);

        \Log::info('API Response Details', ['response' => $response, 'http_code' => $http_code]);

        if (curl_errno($curl)) {
            $error_msg = curl_error($curl);
            curl_close($curl);
            return redirect()->back()->with('status', __('waashal::lang.message_failed') . ': ' . $error_msg);
        }

        curl_close($curl);

        if ($http_code == 200) {
            return redirect()->back()->with('status', __('waashal::lang.message_sent'));
        } else {
            $decoded_response = json_decode($response, true);
            $error_message = $decoded_response['error'] ?? __('waashal::lang.message_failed');
            return redirect()->back()->with('status', __('waashal::lang.message_failed') . ': ' . $error_message);
        }
    }

    /**
     * Validate the request for sending a message.
     */
    private function validateRequest($request)
    {
        $request->validate([
            'to' => 'required|string',
            'message' => 'required|string|max:1000',
            'configuration_id' => 'required|exists:waashal_settings,id',
        ]);
    }
}