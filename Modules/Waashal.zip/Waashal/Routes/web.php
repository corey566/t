<?php

use Modules\Waashal\Http\Controllers\WaashalController;
use Modules\Waashal\Http\Controllers\CustomerController;
use Modules\Waashal\Http\Controllers\SupplierController;
use Modules\Waashal\Http\Controllers\InstallController;
use Modules\Waashal\Http\Controllers\InvoiceController;

// Public routes
Route::prefix('Waashal')->group(function () {
    Route::get('/', [WaashalController::class, 'index']);
});

// Admin-specific routes with middleware
Route::middleware(['web', 'SetSessionData', 'auth', 'language', 'timezone', 'AdminSidebarMenu'])
    ->prefix('Waashal')
    ->group(function () {
        Route::get('dashboard', [WaashalController::class, 'dashboard']);

        // Installation routes
        Route::get('/install', [InstallController::class, 'index']);
        Route::get('/install/update', [InstallController::class, 'update']);
        Route::get('/install/uninstall', [InstallController::class, 'uninstall']);
    });

// Waashal settings routes
Route::middleware(['web', 'SetSessionData', 'auth', 'language', 'timezone', 'AdminSidebarMenu'])
    ->prefix('waashal')
    ->group(function () {
        Route::get('/settings', [WaashalController::class, 'index'])->name('waashal.settings');
        Route::get('/settings/create', [WaashalController::class, 'create'])->name('waashal.settings.create');
        Route::post('/settings', [WaashalController::class, 'store'])->name('waashal.settings.store');
        Route::get('/settings/{id}/edit', [WaashalController::class, 'edit'])->name('waashal.settings.edit');
        Route::put('/settings/{id}', [WaashalController::class, 'update'])->name('waashal.settings.update');
        Route::delete('/settings/{id}', [WaashalController::class, 'destroy'])->name('waashal.settings.destroy');
        Route::post('/test-message', [WaashalController::class, 'testMessage'])->name('waashal.test_message');
        Route::get('/settings/{id}/set-default', [WaashalController::class, 'setDefault'])->name('waashal.settings.set_default');

        Route::get('/message', [WaashalController::class, 'messageForm'])->name('waashal.message_form');
        Route::post('/message/send', [WaashalController::class, 'sendMessage'])->name('waashal.send_message');

        // Invoices page
        Route::get('/invoices', [InvoiceController::class, 'index'])->name('waashal.invoices');
        Route::post('/invoices/{id}/send-whatsapp', [InvoiceController::class, 'sendInvoiceWhatsApp'])->name('waashal.invoices.send_whatsapp');
    });

// Customers page
Route::middleware(['web', 'SetSessionData', 'auth', 'language', 'timezone', 'AdminSidebarMenu'])
    ->prefix('waashal')
    ->group(function () {
        Route::get('/customers', [CustomerController::class, 'index'])->name('waashal.customers');
        Route::post('/customers/send-message', [CustomerController::class, 'sendMessage'])->name('waashal.customers.send_message');
        Route::get('/customers/{id}/account-statement', [CustomerController::class, 'fetchAccountStatement'])->name('waashal.customers.account_statement');
        Route::post('/customers/{id}/send-account-statement', [CustomerController::class, 'sendAccountStatement'])->name('waashal.customers.send_account_statement');
    });

// Suppliers page
Route::middleware(['web', 'SetSessionData', 'auth', 'language', 'timezone', 'AdminSidebarMenu'])
    ->prefix('waashal')
    ->group(function () {
        Route::get('/suppliers', [SupplierController::class, 'index'])->name('waashal.suppliers.index');
        Route::post('/suppliers/send', [SupplierController::class, 'sendMessage'])->name('waashal.suppliers.send');
    });