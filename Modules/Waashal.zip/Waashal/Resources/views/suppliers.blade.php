@extends('layouts.app')

@section('content')
@include('Waashal::layouts.nav')

<section class="no-print">
    <h3 class="m-4">{{ __('waashal::lang.suppliers') }}</h3>

    <!-- Search Form -->
    <form method="GET" action="{{ route('waashal.suppliers.index') }}" class="mb-4">
        <div class="form-group d-flex">
            <input type="text" name="search" class="form-control" placeholder="{{ __('waashal::lang.search_placeholder') }}" value="{{ request('search') }}">
            <button type="submit" class="btn btn-primary ml-2">{{ __('waashal::lang.search') }}</button>
        </div>
    </form>

    <div class="container-fluid">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>{{ __('waashal::lang.name') }}</th>
                    <th>{{ __('waashal::lang.mobile') }}</th>
                    <th>{{ __('waashal::lang.actions') }}</th>
                </tr>
            </thead>
            <tbody>
                @forelse($suppliers as $supplier)
                <tr>
                    <td>{{ $supplier->name }}</td>
                    <td>{{ $supplier->mobile }}</td>
                    <td>
                        <button class="btn btn-primary send-message" 
                                data-name="{{ $supplier->name }}" 
                                data-mobile="{{ $supplier->mobile }}">
                            {{ __('waashal::lang.send_message') }}
                        </button>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="3" class="text-center">{{ __('waashal::lang.no_suppliers_found') }}</td>
                </tr>
                @endforelse
            </tbody>
        </table>
        <!-- Pagination -->
        <div class="mt-3">
            {{ $suppliers->withQueryString()->links() }}
        </div>
    </div>
</section>

<!-- Modal for Sending Message -->
<div class="modal fade" id="sendMessageModal" tabindex="-1" role="dialog" aria-labelledby="sendMessageModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form action="{{ route('waashal.suppliers.send') }}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="sendMessageModalLabel">{{ __('waashal::lang.send_message') }}</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="to">{{ __('waashal::lang.mobile') }}</label>
                        <input type="text" name="to" id="to" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="configuration_id">{{ __('waashal::lang.configuration') }}</label>
                        <select name="configuration_id" id="configuration_id" class="form-control" required>
                            <option value="">{{ __('waashal::lang.select_configuration') }}</option>
                            @foreach($configurations as $config)
                                <option value="{{ $config->id }}">{{ $config->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="message">{{ __('waashal::lang.message') }}</label>
                        <textarea name="message" id="message" rows="5" class="form-control" maxlength="1000" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">{{ __('waashal::lang.close') }}</button>
                    <button type="submit" class="btn btn-primary">{{ __('waashal::lang.send') }}</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const modal = $('#sendMessageModal');
        $('.send-message').on('click', function () {
            const name = $(this).data('name');
            const mobile = $(this).data('mobile');
            modal.find('#to').val(mobile);
            modal.find('#message').val('');
            modal.find('#configuration_id').val('');
            modal.modal('show');
        });
    });
</script>
@endsection