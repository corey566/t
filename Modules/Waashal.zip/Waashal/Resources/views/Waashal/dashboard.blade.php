@extends('layouts.app')

@section('title', __('Waashal::lang.Waashal_module'))

@section('content')

	@include('Waashal::layouts.nav')

@endsection