@extends('layouts.app')

@section('title', __('Waashal::lang.Waashal_module'))

@section('content')

@include('Waashal::layouts.nav')

<section class="content-header">
    <h1 class="text-center text-primary">@lang('waashal::lang.settings')</h1>
</section>

<section class="content">
    @if (session('status'))
        <div class="alert alert-success">
            {{ session('status') }}
        </div>
    @endif

    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h4 class="card-title">@lang('waashal::lang.configure_settings')</h4>
            <a href="{{ route('waashal.settings.create') }}" class="btn btn-success btn-sm">
                @lang('waashal::lang.add_configuration')
            </a>
        </div>
        <div class="card-body">
            @if($configurations->isEmpty())
                <p>@lang('waashal::lang.no_configurations')</p>
            @else
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>@lang('waashal::lang.name')</th>
                            <th>@lang('waashal::lang.appkey')</th>
                            <th>@lang('waashal::lang.from')</th>
                            <th>@lang('waashal::lang.sandbox')</th>
                            <th>@lang('waashal::lang.brands')</th>
                            <th>@lang('waashal::lang.actions')</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($configurations as $config)
                            <tr>
                                <td>{{ $config->name }}</td>
                                <td>{{ $config->appkey }}</td>
                                <td>{{ $config->from }}</td>
                                <td>{{ $config->sandbox ? __('waashal::lang.yes') : __('waashal::lang.no') }}</td>
                                <td>{{ $config->brands->pluck('name')->implode(', ') ?: __('waashal::lang.no_brands') }}</td>
                                <td>
                                    <a href="{{ route('waashal.settings.edit', $config->id) }}" class="btn btn-primary btn-sm">
                                        @lang('messages.edit')
                                    </a>
                                    <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#testMessageModal{{ $config->id }}">
                                        @lang('waashal::lang.test_message')
                                    </button>
                                    <a href="{{ route('waashal.settings.set_default', $config->id) }}" class="btn btn-{{ $config->is_default ? 'warning' : 'info' }} btn-sm">
                                        {{ $config->is_default ? __('waashal::lang.unset_default') : __('waashal::lang.set_default') }}
                                    </a>
                                    <form action="{{ route('waashal.settings.destroy', $config->id) }}" method="POST" style="display:inline;">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('@lang('messages.confirm_delete')')">
                                            @lang('messages.delete')
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            @endif
        </div>
    </div>
</section>

<!-- نافذة منبثقة لاختبار الرسائل -->
@foreach($configurations as $config)
    <div class="modal fade" id="testMessageModal{{ $config->id }}" tabindex="-1" role="dialog" aria-labelledby="testMessageModalLabel{{ $config->id }}" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form action="{{ action([\Modules\Waashal\Http\Controllers\WaashalController::class, 'testMessage']) }}" method="POST">
                    @csrf
                    <div class="modal-header bg-secondary text-white">
                        <h5 class="modal-title" id="testMessageModalLabel{{ $config->id }}">@lang('waashal::lang.test_message') - {{ $config->name }}</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="configuration_id" value="{{ $config->id }}">
                        <div class="mb-3">
                            <label for="to{{ $config->id }}" class="form-label">@lang('waashal::lang.to')</label>
                            <input type="text" 
                                   name="to" 
                                   id="to{{ $config->id }}" 
                                   class="form-control" 
                                   placeholder="@lang('waashal::lang.to_placeholder')" 
                                   required>
                            <small class="text-muted">@lang('waashal::lang.to_hint')</small>
                        </div>
                        <div class="mb-3">
                            <label for="message{{ $config->id }}" class="form-label">@lang('waashal::lang.message')</label>
                            <textarea name="message" 
                                      id="message{{ $config->id }}" 
                                      class="form-control" 
                                      rows="4" 
                                      placeholder="@lang('waashal::lang.message_placeholder')" 
                                      required></textarea>
                            <small class="text-muted">@lang('waashal::lang.message_hint')</small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">@lang('waashal::lang.send')</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">@lang('waashal::lang.close')</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endforeach

@endsection