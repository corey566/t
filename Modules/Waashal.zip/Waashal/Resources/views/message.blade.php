@extends('layouts.app')

@section('title', __('waashal::lang.send_message'))

@section('content')

@include('Waashal::layouts.nav')

<section class="content-header bg-whatsapp-light py-3">
    <h1 class="text-center text-whatsapp-green fw-bold">@lang('waashal::lang.send_message')</h1>
</section>

<section class="content bg-whatsapp-bg">
    @if (session('status'))
        <div class="alert alert-success rounded-pill shadow-sm mx-auto w-75">
            {{ session('status') }}
        </div>
    @endif

    <div class="card shadow-none border-0 bg-transparent">
        <div class="card-header bg-whatsapp-green text-white rounded-top">
            <h4 class="card-title mb-0">@lang('waashal::lang.send_message')</h4>
        </div>
        <div class="card-body p-4">
            <form action="{{ route('waashal.send_message') }}" method="POST">
                @csrf
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="configuration_id" class="form-label text-muted">@lang('waashal::lang.configuration')</label>
                        <select name="configuration_id" id="configuration_id" class="form-control border-whatsapp rounded-pill" required>
                            <option value="">@lang('waashal::lang.select_configuration')</option>
                            @foreach($configurations as $config)
                                <option value="{{ $config->id }}">{{ $config->name }}</option>
                            @endforeach
                        </select>
                        <small class="text-muted">@lang('waashal::lang.configuration_hint')</small>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="to" class="form-label text-muted">@lang('waashal::lang.to')</label>
                        <input type="text" 
                               name="to" 
                               id="to" 
                               class="form-control border-whatsapp rounded-pill" 
                               placeholder="@lang('waashal::lang.to_placeholder')" 
                               required>
                        <small class="text-muted">@lang('waashal::lang.to_hint')</small>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 mb-3">
                        <label for="message" class="form-label text-muted">@lang('waashal::lang.message')</label>
                        <textarea name="message" 
                                  id="message" 
                                  class="form-control border-whatsapp rounded-3" 
                                  rows="4" 
                                  placeholder="@lang('waashal::lang.message_placeholder')" 
                                  required></textarea>
                        <small class="text-muted">@lang('waashal::lang.message_hint')</small>
                    </div>
                </div>
                <div class="d-flex justify-content-end align-items-center mt-3">
                    <a href="{{ route('waashal.settings') }}" class="btn btn-secondary me-2 rounded-pill">@lang('waashal::lang.cancel')</a>
                    <button type="submit" class="btn btn-whatsapp-send rounded-circle shadow"><i class="fas fa-paper-plane text-white"></i></button>
                </div>
            </form>
        </div>
    </div>
</section>

@endsection

<style>
    .bg-whatsapp-light { background-color: #EDEDED !important; }
    .bg-whatsapp-bg { background-color: #F0F2F5 !important; min-height: 100vh; }
    .text-whatsapp-green { color: #075E54 !important; }
    .border-whatsapp { border-color: #25D366 !important; }
    .btn-whatsapp-send { background-color: #25D366 !important; width: 50px; height: 50px; display: flex; align-items: center; justify-content: center; transition: all 0.3s; }
    .btn-whatsapp-send:hover { background-color: #128C7E !important; transform: scale(1.1); }
    .form-control:focus { border-color: #25D366 !important; box-shadow: 0 0 0 0.2rem rgba(37, 211, 102, 0.25); }
</style>