<?php

namespace Modules\Waashal\Entities;

use Illuminate\Database\Eloquent\Model;
use App\Brands;

class WaashalSetting extends Model
{
    protected $table = 'waashal_settings';

    protected $fillable = [
        'business_id',
        'appkey',
        'authkey',
        'from',
        'sandbox',
        'is_default',
        'name',
    ];

    public function brands()
    {
        return $this->belongsToMany(Brands::class, 'waashal_configuration_brands', 'configuration_id', 'brand_id');
    }
}