<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateWaashalSettingsTable extends Migration
{
    public function up()
    {
        Schema::create('waashal_settings', function (Blueprint $table) {
            $table->id(); // BIGINT UNSIGNED - لا مشكلة، لأنه هو المفتاح الأساسي هنا
            $table->unsignedInteger('business_id'); // تم التعديل هنا ليتوافق مع جدول business
            $table->string('appkey');
            $table->string('authkey');
            $table->string('from');
            $table->boolean('sandbox');
            $table->timestamps();

            // علاقة المفتاح الأجنبي مع جدول business
            $table->foreign('business_id')->references('id')->on('business')->onDelete('cascade');
        });
    }

    public function down()
    {
        Schema::dropIfExists('waashal_settings');
    }
}
