<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddNameAndIsDefaultToWaashalSettingsTable extends Migration
{
    public function up()
    {
        Schema::table('waashal_settings', function (Blueprint $table) {
            $table->string('name')->after('business_id'); // إضافة عمود name بعد business_id
            $table->boolean('is_default')->default(false)->after('sandbox'); // إضافة عمود is_default بعد sandbox
        });
    }

    public function down()
    {
        Schema::table('waashal_settings', function (Blueprint $table) {
            $table->dropColumn(['name', 'is_default']); // إزالة العمودين عند التراجع
        });
    }
}