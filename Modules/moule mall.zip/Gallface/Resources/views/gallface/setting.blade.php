@extends('layouts.app')

@section('title', __('Gallface'))

@section('content')
    @include('gallface::layouts.nav')
	
	<section class="content-header">
		<h1 class="tw-text-xl md:tw-text-3xl tw-font-bold tw-text-black">
			<i class="fas fa-tools"></i>
			Settings    </h1>
	</section>
    
    <section class="content">
        
                <div class="nav-tabs-custom">
					<div class="p-10 row">						
						{!! Form::open(['url' => action([\Modules\Gallface\Http\Controllers\GallfaceController::class, 'setting']), 'method' => 'post', 'id' => 'gallface_form' ]) !!}
							<div class="col-sm-3"> 
								<div class="form-group">
									<label for="job_sheet_prefix">Access Token URL</label>
									<input class="form-control" placeholder="Access Token URL" name="gallface_access_token_url" type="text" value="{{ $gallfacessetting->gallface_access_token_url ?? '' }}" id="gallface_access_token_url">
								</div>
							</div>
							<div class="col-sm-3"> 
								<div class="form-group">
									<label for="job_sheet_prefix">Production URL</label>
									<input class="form-control" placeholder="Production URL" name="gallface_production_url" type="text" value="{{ $gallfacessetting->gallface_production_url ?? '' }}" id="gallface_production_url">
								</div>
							</div>
							<div class="col-sm-3">
								<div class="form-group">
									<label for="job_sheet_prefix">Client Secret</label>
									<input class="form-control" placeholder="Client Secret" name="gallface_client_secret" type="text" value="{{ $gallfacessetting->gallface_client_secret ?? '' }}" id="gallface_client_secret">
								</div>
							</div>
							<div class="col-sm-3">
								<div class="form-group">
									<label for="job_sheet_prefix">Client id</label>
									<input class="form-control" placeholder="Client id" name="gallface_client_id" type="text" value="{{ $gallfacessetting->gallface_client_id ?? '' }}" id="gallface_client_id">
								</div>
							</div>							
							<div class="col-md-12">
								<div class="form-group pull-right">
								<input class="tw-dw-btn tw-dw-btn-error tw-text-white" type="submit" value="update">
								</div>
							</div>
						{!! Form::close() !!}
					</div>
                </div>
            
        

    </section>
@stop