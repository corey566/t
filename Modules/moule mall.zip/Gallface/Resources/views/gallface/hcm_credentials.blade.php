
@extends('gallface::layouts.master')

@section('title', 'HCM Mall Integration')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">HCM Havelock City Mall - API Credentials</h3>
                </div>
                <div class="card-body">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i> Configure unique HCM API credentials for each business location. Each location will sync independently.
                    </div>

                    @foreach($locations as $location)
                    <div class="card mb-3">
                        <div class="card-header">
                            <h5>{{ $location->name }}</h5>
                        </div>
                        <div class="card-body">
                            <form action="{{ url('gallface/hcm/save-credentials/' . $location->id) }}" method="POST">
                                @csrf
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>API URL</label>
                                            <input type="text" name="api_url" class="form-control" 
                                                value="{{ $location->getCredentialsForMall('hcm')->api_url ?? 'https://trms-api.azurewebsites.net' }}" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Username</label>
                                            <input type="text" name="username" class="form-control" 
                                                value="{{ $location->getCredentialsForMall('hcm')->username ?? '' }}" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Password</label>
                                            <input type="password" name="password" class="form-control" 
                                                value="{{ $location->getCredentialsForMall('hcm')->password ?? '' }}" required>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Stall No</label>
                                            <input type="text" name="stall_no" class="form-control" 
                                                value="{{ $location->getCredentialsForMall('hcm')->stall_no ?? '' }}" required>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>POS ID</label>
                                            <input type="text" name="pos_id" class="form-control" 
                                                value="{{ $location->getCredentialsForMall('hcm')->pos_id ?? '' }}" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" name="is_active" class="custom-control-input" 
                                                    id="active_{{ $location->id }}" 
                                                    {{ ($location->getCredentialsForMall('hcm')->is_active ?? false) ? 'checked' : '' }}>
                                                <label class="custom-control-label" for="active_{{ $location->id }}">Active</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <button type="submit" class="btn btn-primary">Save Credentials</button>
                                        <button type="button" class="btn btn-info test-connection" data-location-id="{{ $location->id }}">
                                            <i class="fas fa-plug"></i> Test Connection
                                        </button>
                                        <button type="button" class="btn btn-success sync-sales" data-location-id="{{ $location->id }}">
                                            <i class="fas fa-sync"></i> Sync Sales
                                        </button>
                                        <button type="button" class="btn btn-warning send-ping" data-location-id="{{ $location->id }}">
                                            <i class="fas fa-heartbeat"></i> Send Ping
                                        </button>
                                        <a href="{{ url('gallface/hcm/location/' . $location->id . '/download-excel?report_type=daily') }}" class="btn btn-secondary">
                                            <i class="fas fa-download"></i> Download Daily Report
                                        </a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
$(document).ready(function() {
    $('.test-connection').click(function() {
        var locationId = $(this).data('location-id');
        $.post('/gallface/hcm/location/' + locationId + '/ping', function(response) {
            if(response.success) {
                toastr.success(response.message);
            } else {
                toastr.error(response.message);
            }
        });
    });

    $('.sync-sales').click(function() {
        var locationId = $(this).data('location-id');
        var btn = $(this);
        btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Syncing...');
        
        $.post('/gallface/hcm/location/' + locationId + '/sync-sales', function(response) {
            btn.prop('disabled', false).html('<i class="fas fa-sync"></i> Sync Sales');
            if(response.success) {
                toastr.success(response.message + ' (' + response.records_synced + ' records)');
            } else {
                toastr.error(response.message);
            }
        });
    });

    $('.send-ping').click(function() {
        var locationId = $(this).data('location-id');
        $.post('/gallface/hcm/location/' + locationId + '/ping', function(response) {
            if(response.success) {
                toastr.success('Ping successful - POS is active');
            } else {
                toastr.error('Ping failed - POS may be offline');
            }
        });
    });
});
</script>
@endpush
@endsection
