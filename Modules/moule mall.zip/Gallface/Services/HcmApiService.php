
<?php

namespace Modules\Gallface\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class HcmApiService
{
    protected $apiUrl;
    protected $username;
    protected $password;
    protected $stallNo;
    protected $posId;
    
    public function __construct($credentials)
    {
        $this->apiUrl = $credentials['api_url'] ?? 'https://trms-api.azurewebsites.net';
        $this->username = $credentials['username'] ?? '';
        $this->password = $credentials['password'] ?? '';
        $this->stallNo = $credentials['stall_no'] ?? '';
        $this->posId = $credentials['pos_id'] ?? '';
    }
    
    /**
     * Test API connection
     */
    public function testConnection()
    {
        try {
            $response = Http::timeout(10)->post($this->apiUrl . '/api/ping', [
                'username' => $this->username,
                'password' => $this->password,
                'stall_no' => $this->stallNo,
                'pos_id' => $this->posId
            ]);
            
            if ($response->successful()) {
                return [
                    'success' => true,
                    'message' => 'HCM API connection successful'
                ];
            }
            
            return [
                'success' => false,
                'message' => 'Connection failed: ' . $response->body()
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => 'Connection error: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Sync sales data in real-time
     */
    public function syncSales($salesData, $locationId)
    {
        try {
            $formattedData = $this->formatSalesData($salesData);
            
            $response = Http::timeout(30)->post($this->apiUrl . '/api/sales', [
                'username' => $this->username,
                'password' => $this->password,
                'stall_no' => $this->stallNo,
                'pos_id' => $this->posId,
                'sales' => $formattedData
            ]);
            
            if ($response->successful()) {
                return [
                    'success' => true,
                    'message' => 'Sales data synced successfully',
                    'records_synced' => count($formattedData)
                ];
            }
            
            return [
                'success' => false,
                'message' => 'Sync failed: ' . $response->body(),
                'records_synced' => 0
            ];
        } catch (\Exception $e) {
            Log::error('HCM Sales Sync Error', [
                'location_id' => $locationId,
                'error' => $e->getMessage()
            ]);
            
            return [
                'success' => false,
                'message' => 'Sync error: ' . $e->getMessage(),
                'records_synced' => 0
            ];
        }
    }
    
    /**
     * Format sales data for HCM API
     */
    protected function formatSalesData($salesData)
    {
        $formatted = [];
        
        foreach ($salesData as $sale) {
            $saleRecord = [
                'invoice_no' => $sale['invoice_no'] ?? '',
                'transaction_date' => $sale['transaction_date'] ?? now()->toDateTimeString(),
                'customer_mobile' => $sale['customer_mobile'] ?? '',
                'total_amount' => floatval($sale['final_total'] ?? 0),
                'tax_amount' => floatval($sale['tax_amount'] ?? 0),
                'discount_amount' => floatval($sale['discount_amount'] ?? 0),
                'payment_method' => $sale['payment_method'] ?? 'cash',
                'payment_status' => $sale['payment_status'] ?? 'paid',
                'items' => []
            ];
            
            // Add line items
            if (isset($sale['sell_lines']) && is_array($sale['sell_lines'])) {
                foreach ($sale['sell_lines'] as $line) {
                    $saleRecord['items'][] = [
                        'product_sku' => $line['product']['sku'] ?? '',
                        'product_name' => $line['product']['name'] ?? '',
                        'quantity' => floatval($line['quantity'] ?? 0),
                        'unit_price' => floatval($line['unit_price_inc_tax'] ?? 0),
                        'discount' => floatval($line['line_discount_amount'] ?? 0),
                        'tax' => floatval($line['item_tax'] ?? 0)
                    ];
                }
            }
            
            // Check for gift voucher sales
            if (isset($sale['is_gift_voucher']) && $sale['is_gift_voucher']) {
                $saleRecord['gift_voucher_amount'] = floatval($sale['final_total'] ?? 0);
            }
            
            // Check for HCM loyalty card payment
            if (isset($sale['hcm_loyalty_amount']) && $sale['hcm_loyalty_amount'] > 0) {
                $saleRecord['hcm_loyalty'] = floatval($sale['hcm_loyalty_amount']);
            }
            
            $formatted[] = $saleRecord;
        }
        
        return $formatted;
    }
    
    /**
     * Send ping to monitor POS status
     */
    public function sendPing()
    {
        try {
            $response = Http::timeout(5)->post($this->apiUrl . '/api/ping', [
                'username' => $this->username,
                'password' => $this->password,
                'stall_no' => $this->stallNo,
                'pos_id' => $this->posId,
                'timestamp' => now()->toDateTimeString()
            ]);
            
            return [
                'success' => $response->successful(),
                'message' => $response->successful() ? 'Ping successful' : 'Ping failed'
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => 'Ping error: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Upload Excel data for day/month end
     */
    public function uploadExcelData($excelData)
    {
        try {
            $response = Http::timeout(60)->post($this->apiUrl . '/api/excel-upload', [
                'username' => $this->username,
                'password' => $this->password,
                'stall_no' => $this->stallNo,
                'pos_id' => $this->posId,
                'data' => $excelData
            ]);
            
            if ($response->successful()) {
                return [
                    'success' => true,
                    'message' => 'Excel data uploaded successfully'
                ];
            }
            
            return [
                'success' => false,
                'message' => 'Upload failed: ' . $response->body()
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => 'Upload error: ' . $e->getMessage()
            ];
        }
    }
}
