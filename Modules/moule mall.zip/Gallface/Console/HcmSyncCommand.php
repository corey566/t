<?php
namespace Modules\Gallface\Console;

use Illuminate\Console\Command;
use Modules\Gallface\Models\LocationApiCredential;
use Modules\Gallface\Services\HcmApiService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class HcmSyncCommand extends Command
{
    protected $signature = 'hcm:sync {--ping-only : Only send ping without syncing sales}';
    protected $description = 'Sync sales data to HCM API and send ping to monitor POS status';

    public function handle()
    {
        $pingOnly = $this->option('ping-only');
        
        $credentials = LocationApiCredential::where('mall_code', 'hcm')
            ->where('is_active', true)
            ->get();
        
        if ($credentials->isEmpty()) {
            $this->info('No active HCM credentials found.');
            return 0;
        }
        
        foreach ($credentials as $credential) {
            $this->info("Processing location: {$credential->businessLocation->name}");
            
            $apiService = new HcmApiService($credential->getCredentialsForApi());
            
            // Send ping
            $pingResult = $apiService->sendPing();
            if ($pingResult['success']) {
                $this->info("✓ Ping successful");
            } else {
                $this->error("✗ Ping failed: {$pingResult['message']}");
            }
            
            if (!$pingOnly) {
                // Sync sales data
                $salesData = DB::table('transactions')
                    ->where('business_id', $credential->business_id)
                    ->where('location_id', $credential->business_location_id)
                    ->where('type', 'sell')
                    ->whereNull('hcm_synced_at')
                    ->limit(100)
                    ->get()
                    ->toArray();
                
                if (!empty($salesData)) {
                    $syncResult = $apiService->syncSales($salesData, $credential->business_location_id);
                    
                    if ($syncResult['success']) {
                        $this->info("✓ Synced {$syncResult['records_synced']} sales records");
                        
                        // Mark as synced
                        $invoiceNos = array_column($salesData, 'invoice_no');
                        DB::table('transactions')
                            ->whereIn('invoice_no', $invoiceNos)
                            ->update(['hcm_synced_at' => now()]);
                    } else {
                        $this->error("✗ Sync failed: {$syncResult['message']}");
                    }
                } else {
                    $this->info("No new sales to sync");
                }
            }
            
            // Update last synced timestamp
            $credential->update(['last_synced_at' => now()]);
        }
        
        $this->info('HCM sync completed successfully!');
        return 0;
    }
}
