
<?php

namespace Modules\Gallface\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Validator;
use Modules\Gallface\Models\LocationApiCredential;
use Modules\Gallface\Services\HcmApiService;
use Maatwebsite\Excel\Facades\Excel;
use Modules\Gallface\Exports\HcmSalesExport;
use Illuminate\Support\Facades\DB;

class HcmController extends Controller
{
    /**
     * Send ping to HCM API
     */
    public function sendPing(Request $request, $location_id)
    {
        try {
            $business_id = request()->session()->get('user.business_id');
            
            $credentials = LocationApiCredential::where('business_id', $business_id)
                ->where('business_location_id', $location_id)
                ->where('mall_code', 'hcm')
                ->where('is_active', true)
                ->first();
            
            if (!$credentials) {
                return response()->json([
                    'success' => false,
                    'message' => 'No active HCM credentials found'
                ]);
            }
            
            $apiService = new HcmApiService($credentials->getCredentialsForApi());
            return response()->json($apiService->sendPing());
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Ping failed: ' . $e->getMessage()
            ]);
        }
    }
    
    /**
     * Sync sales data to HCM in real-time
     */
    public function syncSales(Request $request, $location_id)
    {
        try {
            $business_id = request()->session()->get('user.business_id');
            
            $credentials = LocationApiCredential::where('business_id', $business_id)
                ->where('business_location_id', $location_id)
                ->where('mall_code', 'hcm')
                ->where('is_active', true)
                ->first();
            
            if (!$credentials) {
                return response()->json([
                    'success' => false,
                    'message' => 'No active HCM credentials found'
                ]);
            }
            
            // Get sales data - adjust table name and fields based on your database schema
            $salesData = DB::table('transactions')
                ->where('business_id', $business_id)
                ->where('location_id', $location_id)
                ->where('type', 'sell')
                ->whereNull('hcm_synced_at')
                ->limit(100) // Sync in batches
                ->get()
                ->toArray();
            
            if (empty($salesData)) {
                return response()->json([
                    'success' => true,
                    'message' => 'No new sales to sync',
                    'records_synced' => 0
                ]);
            }
            
            $apiService = new HcmApiService($credentials->getCredentialsForApi());
            $result = $apiService->syncSales($salesData, $location_id);
            
            // Mark as synced if successful
            if ($result['success']) {
                $invoiceNos = array_column($salesData, 'invoice_no');
                DB::table('transactions')
                    ->whereIn('invoice_no', $invoiceNos)
                    ->update(['hcm_synced_at' => now()]);
            }
            
            return response()->json($result);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Sync failed: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Generate and download Excel for manual upload
     */
    public function downloadExcel(Request $request, $location_id)
    {
        try {
            $business_id = request()->session()->get('user.business_id');
            $reportType = $request->input('report_type', 'daily'); // daily or monthly
            $startDate = $request->input('start_date', now()->startOfDay());
            $endDate = $request->input('end_date', now()->endOfDay());
            
            $fileName = 'HCM_Sales_' . $reportType . '_' . now()->format('Y-m-d') . '.xlsx';
            
            return Excel::download(
                new HcmSalesExport($business_id, $location_id, $startDate, $endDate),
                $fileName
            );
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Excel generation failed: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Upload Excel data to HCM
     */
    public function uploadExcel(Request $request, $location_id)
    {
        $validator = Validator::make($request->all(), [
            'excel_file' => 'required|file|mimes:xlsx,xls'
        ]);
        
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }
        
        try {
            $business_id = request()->session()->get('user.business_id');
            
            $credentials = LocationApiCredential::where('business_id', $business_id)
                ->where('business_location_id', $location_id)
                ->where('mall_code', 'hcm')
                ->where('is_active', true)
                ->first();
            
            if (!$credentials) {
                return response()->json([
                    'success' => false,
                    'message' => 'No active HCM credentials found'
                ]);
            }
            
            // Parse Excel file
            $excelData = Excel::toArray(new \stdClass(), $request->file('excel_file'));
            
            $apiService = new HcmApiService($credentials->getCredentialsForApi());
            return response()->json($apiService->uploadExcelData($excelData));
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Excel upload failed: ' . $e->getMessage()
            ], 500);
        }
    }
}
