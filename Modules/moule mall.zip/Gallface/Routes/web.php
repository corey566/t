<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/* Route::prefix('gallface')->group(function() {
    Route::get('/', 'GallfaceController@index');
}); */

Route::middleware('web', 'SetSessionData', 'auth', 'language', 'timezone', 'AdminSidebarMenu')->prefix('gallface')->group(function () {
	
	Route::get('dashboard', [\Modules\Gallface\Http\Controllers\GallfaceController::class, 'dashboard']);  
	Route::any('setting', [\Modules\Gallface\Http\Controllers\GallfaceController::class, 'setting']);
	
	// HCM Integration Routes
	Route::prefix('hcm')->group(function () {
		Route::get('credentials', [\Modules\Gallface\Http\Controllers\GallfaceController::class, 'hcmCredentials']);
		Route::post('save-credentials/{location_id}', [\Modules\Gallface\Http\Controllers\GallfaceController::class, 'saveHcmCredentials']);
		Route::post('location/{location_id}/ping', [\Modules\Gallface\Http\Controllers\HcmController::class, 'sendPing']);
		Route::post('location/{location_id}/sync-sales', [\Modules\Gallface\Http\Controllers\HcmController::class, 'syncSales']);
		Route::get('location/{location_id}/download-excel', [\Modules\Gallface\Http\Controllers\HcmController::class, 'downloadExcel']);
		Route::post('location/{location_id}/upload-excel', [\Modules\Gallface\Http\Controllers\HcmController::class, 'uploadExcel']);
	});
	
	Route::get('/install', [Modules\Gallface\Http\Controllers\InstallController::class, 'index']);
    Route::post('/install', [Modules\Gallface\Http\Controllers\InstallController::class, 'install']);
    Route::get('/install/update', [Modules\Gallface\Http\Controllers\InstallController::class, 'update']);
    Route::get('/install/uninstall', [Modules\Gallface\Http\Controllers\InstallController::class, 'uninstall']);
	
    Route::get('/', 'GallfaceController@index');
});