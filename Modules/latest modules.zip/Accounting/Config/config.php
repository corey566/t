<?php

return [
    'name' => 'Accounting',
    'module_version' => '0.85',
    'pid' => 16,
];
