<?php

return [
    'spreadsheet' => '电子表格',
    'spreadsheet_module' => '电子表格模块',
    'sheets' => '床单',
    'my_spreadsheets' => '我的电子表格',
    'create_spreadsheet' => '创建电子表格',
    'no_spreadsheet_found' => '未找到电子表格！',
    'view_spreadsheet' => '查看电子表格',
    'share' => '分享',
    'share_excel' => '共享电子表格',
    'todos' => '待办事项',
    'access_spreadsheet' => '访问电子表格',
    'create_spreadsheet' => '创建电子表格',
    'spreadsheet_shared_notif_text' => ':shared_by 分享了一个电子表格 - :name',
    'shared_by' => '共享者: :name',
    'created_by' => '创建者::name',
];
