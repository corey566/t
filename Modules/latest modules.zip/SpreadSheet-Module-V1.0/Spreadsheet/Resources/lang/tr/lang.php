<?php

return [
    'spreadsheet' => 'E-tablo',
    'spreadsheet_module' => 'Elektronik Tablo Modülü',
    'sheets' => 'Çarşaflar',
    'my_spreadsheets' => 'E-tablolarım',
    'create_spreadsheet' => 'Elektronik Tablo Oluştur',
    'no_spreadsheet_found' => 'E-tablo bulunamadı!',
    'view_spreadsheet' => 'Elektronik Tabloyu Görüntüle',
    'share' => 'Paylaş',
    'share_excel' => 'E-tabloyu paylaş',
    'todos' => 'Todo',
    'access_spreadsheet' => 'E-tabloya erişim',
    'create_spreadsheet' => 'E-tablo oluştur',
    'spreadsheet_shared_notif_text' => ':shared_by bir elektronik tablo paylaştı - :name',
    'shared_by' => 'Paylaşan : :name',
    'created_by' => 'Oluşturan : :name',
];
