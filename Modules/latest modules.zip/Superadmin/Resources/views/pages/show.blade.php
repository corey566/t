@extends('layouts.home')
@section('title', $page->title)

@section('content')
    {!! $page->content !!}
@endsection