@extends('layouts.app')

@section('title', __('waashal::lang.sales_invoices'))

@section('content')

@include('Waashal::layouts.nav')

<!-- Content Header (Page header) -->
<section class="content-header no-print">
    <h1 class="tw-text-xl md:tw-text-3xl tw-font-bold tw-text-black">@lang('waashal::lang.sales_invoices')</h1>
</section>

<!-- Main content -->
<section class="content no-print">
    @component('components.filters', ['title' => __('waashal::lang.filters')])
        @include('sell.partials.sell_list_filters')
        @if ($payment_types)
            <div class="col-md-3">
                <div class="form-group">
                    {!! Form::label('payment_method', __('waashal::lang.payment_method') . ':') !!}
                    {!! Form::select('payment_method', $payment_types, null, [
                        'class' => 'form-control select2',
                        'style' => 'width:100%',
                        'placeholder' => __('waashal::lang.all'),
                    ]) !!}
                </div>
            </div>
        @endif
        @if (!empty($sources))
            <div class="col-md-3">
                <div class="form-group">
                    {!! Form::label('sell_list_filter_source', __('waashal::lang.sources') . ':') !!}
                    {!! Form::select('sell_list_filter_source', $sources, null, [
                        'class' => 'form-control select2',
                        'style' => 'width:100%',
                        'placeholder' => __('waashal::lang.all'),
                    ]) !!}
                </div>
            </div>
        @endif
    @endcomponent

    @component('components.widget', ['class' => 'box-primary', 'title' => __('waashal::lang.all_sales')])
        @php
            $custom_labels = json_decode(session('business.custom_labels'), true);
        @endphp
        <table class="table table-bordered table-striped ajax_view" id="sell_table">
            <thead>
                <tr>
                    <th>@lang('waashal::lang.actions')</th>
                    <th>@lang('waashal::lang.date')</th>
                    <th>@lang('waashal::lang.invoice_no')</th>
                    <th>@lang('waashal::lang.customer_name')</th>
                    <th>@lang('waashal::lang.contact_no')</th>
                    <th>@lang('waashal::lang.location')</th>
                    <th>@lang('waashal::lang.payment_status')</th>
                    <th>@lang('waashal::lang.payment_method')</th>
                    <th>@lang('waashal::lang.total_amount')</th>
                    <th>@lang('waashal::lang.total_paid')</th>
                    <th>@lang('waashal::lang.sell_due')</th>
                    <th>@lang('waashal::lang.sell_return_due')</th>
                    <th>@lang('waashal::lang.shipping_status')</th>
                    <th>@lang('waashal::lang.total_items')</th>
                    <th>@lang('waashal::lang.types_of_service')</th>
                    <th>{{ $custom_labels['types_of_service']['custom_field_1'] ?? __('waashal::lang.service_custom_field_1') }}</th>
                    <th>{{ $custom_labels['sell']['custom_field_1'] ?? '' }}</th>
                    <th>{{ $custom_labels['sell']['custom_field_2'] ?? '' }}</th>
                    <th>{{ $custom_labels['sell']['custom_field_3'] ?? '' }}</th>
                    <th>{{ $custom_labels['sell']['custom_field_4'] ?? '' }}</th>
                    <th>@lang('waashal::lang.added_by')</th>
                    <th>@lang('waashal::lang.sell_note')</th>
                    <th>@lang('waashal::lang.staff_note')</th>
                    <th>@lang('waashal::lang.shipping_details')</th>
                    <th>@lang('waashal::lang.table')</th>
                    <th>@lang('waashal::lang.service_staff')</th>
                </tr>
            </thead>
            <tbody></tbody>
            <tfoot>
                <tr class="bg-gray font-17 footer-total text-center">
                    <td colspan="6"><strong>@lang('waashal::lang.total'):</strong></td>
                    <td class="footer_payment_status_count"></td>
                    <td class="payment_method_count"></td>
                    <td class="footer_sale_total"></td>
                    <td class="footer_total_paid"></td>
                    <td class="footer_total_remaining"></td>
                    <td class="footer_total_sell_return_due"></td>
                    <td colspan="2"></td>
                    <td class="service_type_count"></td>
                    <td colspan="7"></td>
                </tr>
            </tfoot>
        </table>
    @endcomponent
</section>

<!-- Modals -->
<div class="modal fade payment_modal" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel"></div>
<div class="modal fade edit_payment_modal" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel"></div>
<div class="modal fade view_modal" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel"></div>

<!-- Print Section -->
<section class="invoice print_section" id="receipt_section"></section>

@endsection

@section('javascript')
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">
    $(document).ready(function() {
        // Enable DataTables debug mode for better error reporting
        $.fn.dataTable.ext.errMode = 'throw';

        // Date range picker
        $('#sell_list_filter_date_range').daterangepicker(
            dateRangeSettings,
            function(start, end) {
                $('#sell_list_filter_date_range').val(start.format(moment_date_format) + ' ~ ' + end.format(moment_date_format));
                sell_table.ajax.reload();
            }
        );
        $('#sell_list_filter_date_range').on('cancel.daterangepicker', function(ev, picker) {
            $('#sell_list_filter_date_range').val('');
            sell_table.ajax.reload();
        });

        // Initialize DataTable
        sell_table = $('#sell_table').DataTable({
            processing: true,
            serverSide: true,
            fixedHeader: false,
            aaSorting: [[1, 'desc']],
            ajax: {
                url: "{{ route('waashal.invoices') }}",
                data: function(d) {
                    if ($('#sell_list_filter_date_range').val()) {
                        var start = $('#sell_list_filter_date_range').data('daterangepicker').startDate.format('YYYY-MM-DD');
                        var end = $('#sell_list_filter_date_range').data('daterangepicker').endDate.format('YYYY-MM-DD');
                        d.start_date = start;
                        d.end_date = end;
                    }
                    d.is_direct_sale = 1;
                    d.location_id = $('#sell_list_filter_location_id').val();
                    d.customer_id = $('#sell_list_filter_customer_id').val();
                    d.payment_status = $('#sell_list_filter_payment_status').val();
                    d.created_by = $('#created_by').val();
                    d.sales_cmsn_agnt = $('#sales_cmsn_agnt').val();
                    d.service_staffs = $('#service_staffs').val();
                    d.shipping_status = $('#shipping_status').val();
                    d.source = $('#sell_list_filter_source').val();
                    d.payment_method = $('#payment_method').val();
                    if ($('#only_subscriptions').is(':checked')) {
                        d.only_subscriptions = 1;
                    }
                    d = __datatable_ajax_callback(d);
                }
            },
            scrollY: "75vh",
            scrollX: true,
            scrollCollapse: true,
            columns: [
                { data: 'action', name: 'action', orderable: false, searchable: false },
                { data: 'transaction_date', name: 'transaction_date' },
                { data: 'invoice_no', name: 'invoice_no' },
                { data: 'conatct_name', name: 'conatct_name' },
                { data: 'mobile', name: 'contacts.mobile' },
                { data: 'business_location', name: 'bl.name' },
                { data: 'payment_status', name: 'payment_status' },
                { data: 'payment_methods', orderable: false, searchable: false },
                { data: 'final_total', name: 'final_total' },
                { data: 'total_paid', name: 'total_paid', searchable: false },
                { data: 'total_remaining', name: 'total_remaining' },
                { data: 'return_due', orderable: false, searchable: false },
                { data: 'shipping_status', name: 'shipping_status' },
                { data: 'total_items', name: 'total_items', searchable: false },
                { data: 'types_of_service_name', name: 'tos.name', visible: {{ $is_types_service_enabled ? 'true' : 'false' }} },
                { data: 'service_custom_field_1', name: 'service_custom_field_1', visible: {{ $is_types_service_enabled ? 'true' : 'false' }} },
                { data: 'custom_field_1', name: 'transactions.custom_field_1', visible: {{ !empty($custom_labels['sell']['custom_field_1']) ? 'true' : 'false' }} },
                { data: 'custom_field_2', name: 'transactions.custom_field_2', visible: {{ !empty($custom_labels['sell']['custom_field_2']) ? 'true' : 'false' }} },
                { data: 'custom_field_3', name: 'transactions.custom_field_3', visible: {{ !empty($custom_labels['sell']['custom_field_3']) ? 'true' : 'false' }} },
                { data: 'custom_field_4', name: 'transactions.custom_field_4', visible: {{ !empty($custom_labels['sell']['custom_field_4']) ? 'true' : 'false' }} },
                { data: 'added_by', name: 'u.first_name' },
                { data: 'additional_notes', name: 'additional_notes' },
                { data: 'staff_note', name: 'staff_note' },
                { data: 'shipping_details', name: 'shipping_details' },
                { data: 'table_name', name: 'tables.name', visible: {{ $is_tables_enabled ? 'true' : 'false' }} },
                { data: 'waiter', name: 'ss.first_name', visible: {{ $is_service_staff_enabled ? 'true' : 'false' }} },
            ],
            fnDrawCallback: function(oSettings) {
                __currency_convert_recursively($('#sell_table'));
            },
            footerCallback: function(row, data, start, end, display) {
                var footer_sale_total = 0;
                var footer_total_paid = 0;
                var footer_total_remaining = 0;
                var footer_total_sell_return_due = 0;
                for (var r in data) {
                    footer_sale_total += $(data[r].final_total).data('orig-value') ? parseFloat($(data[r].final_total).data('orig-value')) : 0;
                    footer_total_paid += $(data[r].total_paid).data('orig-value') ? parseFloat($(data[r].total_paid).data('orig-value')) : 0;
                    footer_total_remaining += $(data[r].total_remaining).data('orig-value') ? parseFloat($(data[r].total_remaining).data('orig-value')) : 0;
                    footer_total_sell_return_due += $(data[r].return_due).find('.sell_return_due').data('orig-value') ? parseFloat($(data[r].return_due).find('.sell_return_due').data('orig-value')) : 0;
                }
                $('.footer_total_sell_return_due').html(__currency_trans_from_en(footer_total_sell_return_due));
                $('.footer_total_remaining').html(__currency_trans_from_en(footer_total_remaining));
                $('.footer_total_paid').html(__currency_trans_from_en(footer_total_paid));
                $('.footer_sale_total').html(__currency_trans_from_en(footer_sale_total));
                $('.footer_payment_status_count').html(__count_status(data, 'payment_status'));
                $('.service_type_count').html(__count_status(data, 'types_of_service_name'));
                $('.payment_method_count').html(__count_status(data, 'payment_methods'));
            },
            createdRow: function(row, data, dataIndex) {
                $(row).find('td:eq(6)').attr('class', 'clickable_td');
            }
        });

        // Handle filter changes
        $(document).on('change',
            '#sell_list_filter_location_id, #sell_list_filter_customer_id, #sell_list_filter_payment_status, #created_by, #sales_cmsn_agnt, #service_staffs, #shipping_status, #sell_list_filter_source, #payment_method',
            function() {
                sell_table.ajax.reload();
            });

        $('#only_subscriptions').on('ifChanged', function(event) {
            sell_table.ajax.reload();
        });

        // Handle send invoice WhatsApp with delegation to handle dynamic content
        $(document).on('click', '.send-invoice-whatsapp', function(e) {
            e.preventDefault();
            var href = $(this).data('href');
            console.log('Send Invoice WhatsApp clicked, URL:', href); // Debug log

            if (typeof Swal === 'undefined') {
                console.error('SweetAlert2 is not loaded');
                alert('خطأ: مكتبة SweetAlert2 غير محملة. يرجى التحقق من إعدادات النظام.');
                return;
            }

            Swal.fire({
                title: '@lang("waashal::lang.confirm")',
                text: '@lang("waashal::lang.send_invoice_confirmation")',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: '@lang("waashal::lang.send")',
                cancelButtonText: '@lang("waashal::lang.cancel")',
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: href,
                        method: 'POST',
                        data: {
                            _token: '{{ csrf_token() }}'
                        },
                        success: function(response) {
                            console.log('AJAX Success:', response); // Debug log
                            if (response.success) {
                                Swal.fire({
                                    title: '@lang("waashal::lang.success")',
                                    text: response.msg,
                                    icon: 'success'
                                });
                            } else {
                                Swal.fire({
                                    title: '@lang("waashal::lang.error")',
                                    text: response.error,
                                    icon: 'error'
                                });
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error('AJAX Error:', status, error, xhr.responseText); // Debug log
                            Swal.fire({
                                title: '@lang("waashal::lang.error")',
                                text: '@lang("waashal::lang.message_failed")' + ': ' + (xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : '@lang("waashal::lang.unknown_error")'),
                                icon: 'error'
                            });
                        }
                    });
                }
            }).catch(function(error) {
                console.error('Swal Error:', error); // Debug log
            });
        });
    });
</script>
<script src="{{ asset('js/payment.js?v=' . $asset_v) }}"></script>
@endsection