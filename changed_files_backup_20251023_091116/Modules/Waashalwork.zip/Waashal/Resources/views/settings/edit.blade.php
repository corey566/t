@extends('layouts.app')

@section('title', __('waashal::lang.edit_configuration'))

@section('content')

@include('Waashal::layouts.nav')

<section class="content-header">
    <h1 class="text-center text-primary">@lang('waashal::lang.edit_configuration')</h1>
</section>

<section class="content">
    @if (session('status'))
        <div class="alert alert-success">
            {{ session('status') }}
        </div>
    @endif

    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h4 class="card-title">@lang('waashal::lang.edit_configuration')</h4>
        </div>
        <div class="card-body">
            <form action="{{ route('waashal.settings.update', $configuration->id) }}" method="POST">
                @csrf
                @method('PUT')
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="name" class="form-label">@lang('waashal::lang.configuration_name')</label>
                        <input type="text" 
                               name="name" 
                               id="name" 
                               class="form-control" 
                               value="{{ $configuration->name }}" 
                               required>
                        <small class="text-muted">@lang('waashal::lang.configuration_name_hint')</small>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="appkey" class="form-label">@lang('waashal::lang.appkey')</label>
                        <input type="text" 
                               name="appkey" 
                               id="appkey" 
                               class="form-control" 
                               value="{{ $configuration->appkey }}" 
                               required>
                        <small class="text-muted">@lang('waashal::lang.appkey_hint')</small>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="authkey" class="form-label">@lang('waashal::lang.authkey')</label>
                        <input type="text" 
                               name="authkey" 
                               id="authkey" 
                               class="form-control" 
                               value="{{ $configuration->authkey }}" 
                               required>
                        <small class="text-muted">@lang('waashal::lang.authkey_hint')</small>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="from" class="form-label">@lang('waashal::lang.from')</label>
                        <input type="text" 
                               name="from" 
                               id="from" 
                               class="form-control" 
                               value="{{ $configuration->from }}" 
                               required>
                        <small class="text-muted">@lang('waashal::lang.from_hint')</small>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="sandbox" class="form-label">@lang('waashal::lang.sandbox')</label>
                        <select name="sandbox" id="sandbox" class="form-control" required>
                            <option value="1" {{ $configuration->sandbox ? 'selected' : '' }}>@lang('waashal::lang.yes')</option>
                            <option value="0" {{ !$configuration->sandbox ? 'selected' : '' }}>@lang('waashal::lang.no')</option>
                        </select>
                        <small class="text-muted">@lang('waashal::lang.sandbox_hint')</small>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="brands" class="form-label">@lang('waashal::lang.brands')</label>
                        <select name="brands[]" id="brands" class="form-control" multiple>
                            @foreach($brands as $id => $name)
                                <option value="{{ $id }}" {{ $configuration->brands->contains($id) ? 'selected' : '' }}>
                                    {{ $name }}
                                </option>
                            @endforeach
                        </select>
                        <small class="text-muted">@lang('waashal::lang.brands_hint')</small>
                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-center">
                    <button type="submit" class="btn btn-primary">@lang('waashal::lang.save')</button>
                    <a href="{{ route('waashal.settings') }}" class="btn btn-secondary">@lang('waashal::lang.cancel')</a>
                </div>
            </form>
        </div>
    </div>
</section>

@endsection

@section('javascript')
    <script>
        $(document).ready(function() {
            $('#brands').select2({
                placeholder: "@lang('waashal::lang.select_brands')",
                allowClear: true
            });
        });
    </script>
@endsection