<section class="no-print">
    <nav class="navbar navbar-default bg-whatsapp-green m-0 shadow-sm">
        <div class="container-fluid px-3">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header d-flex align-items-center">
                <button type="button" class="navbar-toggle collapsed me-3" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar bg-white"></span>
                    <span class="icon-bar bg-white"></span>
                    <span class="icon-bar bg-white"></span>
                </button>
                <a class="navbar-brand text-white fw-bold" href="{{ action([\Modules\Waashal\Http\Controllers\WaashalController::class, 'dashboard']) }}">
                    <i class="fab fa-whatsapp text-whatsapp-icon me-2"></i> 
                    {{ __('Waashal::lang.Waashal_module') }}
                </a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav d-flex justify-content-around w-100">
                    <!-- Link to Message Page -->
                    <li @if(request()->segment(2) == 'message') class="active" @endif>
                        <a href="{{ action([\Modules\Waashal\Http\Controllers\WaashalController::class, 'messageForm']) }}" class="text-white d-flex flex-column align-items-center py-2">
                            <i class="fas fa-envelope fa-lg mb-1"></i> 
                            @lang('waashal::lang.message')
                        </a>
                    </li>

                    <!-- Link to Settings Page -->
                    <li @if(request()->segment(2) == 'settings') class="active" @endif>
                        <a href="{{ action([\Modules\Waashal\Http\Controllers\WaashalController::class, 'index']) }}" class="text-white d-flex flex-column align-items-center py-2">
                            <i class="fas fa-cogs fa-lg mb-1"></i> 
                            @lang('waashal::lang.settings')
                        </a>
                    </li>

                    <!-- Link to Customers Page -->
                    <li @if(request()->segment(2) == 'customers') class="active" @endif>
                        <a href="{{ action([\Modules\Waashal\Http\Controllers\CustomerController::class, 'index']) }}" class="text-white d-flex flex-column align-items-center py-2">
                            <i class="fas fa-users fa-lg mb-1"></i> 
                            @lang('waashal::lang.customers')
                        </a>
                    </li>

                    <!-- Link to Suppliers Page -->
                    <li @if(request()->segment(2) == 'suppliers') class="active" @endif>
                        <a href="{{ action([\Modules\Waashal\Http\Controllers\SupplierController::class, 'index']) }}" class="text-white d-flex flex-column align-items-center py-2">
                            <i class="fas fa-truck fa-lg mb-1"></i> 
                            @lang('waashal::lang.suppliers')
                        </a>
                    </li>

                    <!-- Link to Invoices Page -->
                    <li @if(request()->segment(2) == 'invoices') class="active" @endif>
                        <a href="{{ action([\Modules\Waashal\Http\Controllers\InvoiceController::class, 'index']) }}" class="text-white d-flex flex-column align-items-center py-2">
                            <i class="fas fa-file-invoice fa-lg mb-1"></i> 
                            @lang('waashal::lang.sales_invoices')
                        </a>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </nav>
</section>

<style>
    .bg-whatsapp-green { background-color: #075E54 !important; }
    .text-whatsapp-icon { color: #25D366 !important; }
    .navbar-nav li.active a { background-color: #128C7E !important; border-radius: 8px; }
    .navbar-nav a:hover { transition: all 0.3s; color: #25D366 !important; }
    @media (max-width: 768px) {
        .navbar-nav { flex-direction: row; justify-content: space-around; position: fixed; bottom: 0; width: 100%; background-color: #075E54; padding: 10px 0; }
        .navbar-header { width: 100%; justify-content: space-between; }
    }
</style>