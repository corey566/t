<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateWaashalConfigurationBrandsTable extends Migration
{
    public function up()
    {
        Schema::create('waashal_configuration_brands', function (Blueprint $table) {
            $table->unsignedBigInteger('configuration_id');
            $table->unsignedBigInteger('brand_id');
            $table->timestamps();

            // المفاتيح الأجنبية
            $table->foreign('configuration_id')->references('id')->on('waashal_settings')->onDelete('cascade');
            $table->foreign('brand_id')->references('id')->on('brands')->onDelete('cascade');

            // مفتاح أساسي مركب لتجنب التكرار
            $table->primary(['configuration_id', 'brand_id']);
        });
    }

    public function down()
    {
        Schema::dropIfExists('waashal_configuration_brands');
    }
}