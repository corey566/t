<?php

namespace Modules\Waashal\Http\Controllers;

use App\Brands;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Waashal\Entities\WaashalSetting;

class WaashalController extends Controller
{
    public function dashboard()
    {
        return view('Waashal::Waashal.dashboard');
    }

    public function index()
    {
        $business_id = session('business.id');
        $configurations = WaashalSetting::where('business_id', $business_id)->with('brands')->get();
        $brands = Brands::forDropdown($business_id, false);

        return view('Waashal::settings.index', compact('configurations', 'brands'));
    }

    public function create()
    {
        $business_id = session('business.id');
        $brands = Brands::forDropdown($business_id, false);
        return view('Waashal::settings.create', compact('brands'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'appkey' => 'required|string',
            'authkey' => 'required|string',
            'from' => 'required|string',
            'sandbox' => 'required|boolean',
            'brands' => 'nullable|array',
            'brands.*' => 'exists:brands,id',
        ]);

        $business_id = session('business.id');

        $configuration = WaashalSetting::create([
            'business_id' => $business_id,
            'name' => $request->name,
            'appkey' => $request->appkey,
            'authkey' => $request->authkey,
            'from' => $request->from,
            'sandbox' => $request->sandbox,
            'is_default' => false,
        ]);

        if ($request->has('brands')) {
            $configuration->brands()->sync($request->brands);
        }

        return redirect()->route('waashal.settings')->with('status', __('lang_v1.success'));
    }

    public function edit($id)
    {
        $business_id = session('business.id');
        $configuration = WaashalSetting::where('business_id', $business_id)->with('brands')->findOrFail($id);
        $brands = Brands::forDropdown($business_id, false);

        return view('Waashal::settings.edit', compact('configuration', 'brands'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'appkey' => 'required|string',
            'authkey' => 'required|string',
            'from' => 'required|string',
            'sandbox' => 'required|boolean',
            'brands' => 'nullable|array',
            'brands.*' => 'exists:brands,id',
        ]);

        $business_id = session('business.id');
        $configuration = WaashalSetting::where('business_id', $business_id)->findOrFail($id);

        $configuration->update([
            'name' => $request->name,
            'appkey' => $request->appkey,
            'authkey' => $request->authkey,
            'from' => $request->from,
            'sandbox' => $request->sandbox,
        ]);

        $configuration->brands()->sync($request->brands ?? []);

        return redirect()->route('waashal.settings')->with('status', __('lang_v1.success'));
    }

    public function destroy($id)
    {
        $business_id = session('business.id');
        $configuration = WaashalSetting::where('business_id', $business_id)->findOrFail($id);
        $configuration->brands()->detach();
        $configuration->delete();

        return redirect()->route('waashal.settings')->with('status', __('lang_v1.success'));
    }

    public function setDefault($id)
    {
        $business_id = session('business.id');
        $configuration = WaashalSetting::where('business_id', $business_id)->findOrFail($id);

        // إلغاء الافتراضية لجميع التكوينات الأخرى
        WaashalSetting::where('business_id', $business_id)->where('id', '!=', $id)->update(['is_default' => false]);

        // تعيين/إلغاء الافتراضية للتكوين الحالي
        $configuration->update(['is_default' => !$configuration->is_default]);

        return redirect()->route('waashal.settings')->with('status', __('lang_v1.success'));
    }

    public function messageForm()
    {
        $business_id = session('business.id');
        $configurations = WaashalSetting::where('business_id', $business_id)->get();
        return view('Waashal::message', compact('configurations'));
    }

    public function sendMessage(Request $request)
    {
        $request->validate([
            'to' => 'required|string',
            'message' => 'required|string|max:1000',
            'configuration_id' => 'required|exists:waashal_settings,id',
        ]);

        $business_id = session('business.id');
        $settings = WaashalSetting::where('business_id', $business_id)
            ->with('brands')
            ->findOrFail($request->configuration_id);

        // تعديل رقم الهاتف: إذا بدأ بـ 0، أضف 2 قبل الرقم
        $to = $request->to;
        if (preg_match('/^0[0-9]{10}$/', $to)) {
            $to = '2' . $to;
        }

        // إضافة اسم الماركة قبل الرسالة
        $message = $request->message;
        if ($settings->brands->isNotEmpty()) {
            $brand_name = $settings->brands->first()->name;
            $message = "مرحبا بك في {$brand_name}\n{$message}";
        }

        $curl = curl_init();

        $postData = [
            'appkey' => $settings->appkey,
            'authkey' => $settings->authkey,
            'to' => $to,
            'message' => $message,
            'sandbox' => $settings->sandbox ? 'true' : 'false',
        ];

        curl_setopt_array($curl, [
            CURLOPT_URL => 'https://sender-wa.ashsender.online/api/create-message',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $postData,
        ]);

        $response = curl_exec($curl);
        $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);

        curl_close($curl);

        if ($http_code == 200) {
            return redirect()->back()->with('status', __('waashal::lang.message_sent'));
        } else {
            return redirect()->back()->with('status', __('waashal::lang.message_failed'));
        }
    }
}