<?php

namespace Modules\Waashal\Entities;

use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = ['id'];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'send_message' => 'boolean',
    ];

    /**
     * علاقة مع الكيان Business.
     */
    public function business()
    {
        return $this->belongsTo(\App\Business::class);
    }
}
