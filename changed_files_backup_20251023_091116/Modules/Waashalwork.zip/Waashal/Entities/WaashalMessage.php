<?php

namespace Modules\Waashal\Entities;

use Illuminate\Database\Eloquent\Model;

class WaashalMessage extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['business_id', 'to', 'message', 'status'];

    /**
     * Get the business associated with the message.
     */
    public function business()
    {
        return $this->belongsTo(\App\Business::class);
    }
}
