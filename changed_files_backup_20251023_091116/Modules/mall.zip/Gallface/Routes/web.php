
<?php

use Illuminate\Support\Facades\Route;
use Modules\Gallface\Http\Controllers\GallfaceController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::prefix('gallface')->group(function() {
    // Main dashboard
    Route::get('/', [GallfaceController::class, 'index'])->name('gallface.index');
    
    // Mall-specific routes
    Route::prefix('{mall_code}')->group(function() {
        // Dashboard
        Route::get('/dashboard', [GallfaceController::class, 'dashboard'])->name('gallface.dashboard');
        
        // Settings
        Route::get('/settings', [GallfaceController::class, 'setting'])->name('gallface.setting');
        
        // API endpoints
        Route::post('/test-connection', [GallfaceController::class, 'testConnection'])->name('gallface.testConnection');
        Route::post('/manual-sync', [GallfaceController::class, 'manualSync'])->name('gallface.manualSync');
        
        // Location-specific API endpoints
        Route::post('/save-credentials', [GallfaceController::class, 'saveLocationCredentials'])->name('gallface.saveLocationCredentials');
        Route::post('/test-credentials/{location_id}', [GallfaceController::class, 'testLocationCredentials'])->name('gallface.testLocationCredentials');
        Route::post('/sync-sales/{location_id}', [GallfaceController::class, 'syncLocationSales'])->name('gallface.syncLocationSales');
    });
});
