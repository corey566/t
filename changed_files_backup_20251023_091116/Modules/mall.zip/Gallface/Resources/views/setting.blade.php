
@extends('gallface::layouts.master')

@section('title', 'Mall Integration Settings - ' . $current_mall['name'])

@section('content')
<div class="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
    <!-- Navigation -->
    @include('gallface::layouts.nav')
    
    <!-- Main Content -->
    <div class="container mx-auto px-4 py-8">
        <!-- Header -->
        <div class="mb-8">
            <div class="flex items-center gap-4 mb-4">
                <div class="p-3 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl">
                    <i class="{{ $current_mall['icon'] ?? 'fas fa-cog' }} text-white text-xl"></i>
                </div>
                <div>
                    <h1 class="text-3xl font-bold text-white">{{ $current_mall['name'] }} Settings</h1>
                    <p class="text-slate-400">Configure API credentials and sync preferences</p>
                </div>
            </div>
            
            <!-- Breadcrumb -->
            <nav class="flex text-sm text-slate-400">
                <a href="{{ url('/') }}" class="hover:text-white transition-colors">Home</a>
                <span class="mx-2">/</span>
                <a href="{{ route('gallface.dashboard', $mall_code) }}" class="hover:text-white transition-colors">{{ $current_mall['name'] }}</a>
                <span class="mx-2">/</span>
                <span class="text-white">Settings</span>
            </nav>
        </div>

        <!-- Alert Messages -->
        @if(session('success'))
        <div class="mb-6 p-4 bg-green-500/10 border border-green-500/20 rounded-xl flex items-center gap-3">
            <i class="fas fa-check-circle text-green-400"></i>
            <span class="text-green-300">{{ session('success') }}</span>
        </div>
        @endif

        @if(session('error'))
        <div class="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-xl flex items-center gap-3">
            <i class="fas fa-exclamation-circle text-red-400"></i>
            <span class="text-red-300">{{ session('error') }}</span>
        </div>
        @endif

        <!-- Settings Grid -->
        <div class="grid grid-cols-1 xl:grid-cols-3 gap-8">
            <!-- Location Configuration -->
            <div class="xl:col-span-2">
                <div class="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6">
                    <div class="flex items-center gap-3 mb-6">
                        <i class="fas fa-map-marker-alt text-blue-400"></i>
                        <h2 class="text-xl font-semibold text-white">Location API Credentials</h2>
                    </div>

                    @if($business_locations->isEmpty())
                    <div class="text-center py-12">
                        <i class="fas fa-store text-4xl text-slate-500 mb-4"></i>
                        <p class="text-slate-400">No business locations found.</p>
                    </div>
                    @else
                    <div class="space-y-6">
                        @foreach($business_locations as $location)
                        <div class="border border-white/10 rounded-xl p-6 bg-white/5">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center gap-3">
                                    <div class="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                                        <i class="fas fa-building text-white text-sm"></i>
                                    </div>
                                    <div>
                                        <h3 class="font-semibold text-white">{{ $location->name }}</h3>
                                        <p class="text-sm text-slate-400">{{ $location->city }}, {{ $location->state }}</p>
                                    </div>
                                </div>
                                @php
                                    $credentials = $location->locationApiCredentials->where('mall_code', $mall_code)->first();
                                @endphp
                                <div class="flex items-center gap-2">
                                    @if($credentials && $credentials->is_active)
                                    <span class="px-3 py-1 bg-green-500/20 text-green-300 text-xs rounded-full">Configured</span>
                                    @else
                                    <span class="px-3 py-1 bg-yellow-500/20 text-yellow-300 text-xs rounded-full">Not Configured</span>
                                    @endif
                                </div>
                            </div>

                            <!-- Configuration Form -->
                            <form class="location-config-form" data-location-id="{{ $location->id }}">
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div class="space-y-2">
                                        <label class="text-sm font-medium text-slate-300">API URL</label>
                                        <input type="url" name="api_url" 
                                               value="{{ $credentials->api_url ?? '' }}"
                                               class="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                                               placeholder="https://api.mall.com/v1">
                                    </div>
                                    
                                    <div class="space-y-2">
                                        <label class="text-sm font-medium text-slate-300">API Key</label>
                                        <input type="password" name="api_key" 
                                               value="{{ $credentials->api_key ?? '' }}"
                                               class="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                                               placeholder="Your API key">
                                    </div>
                                    
                                    <div class="space-y-2">
                                        <label class="text-sm font-medium text-slate-300">Client ID</label>
                                        <input type="text" name="client_id" 
                                               value="{{ $credentials->client_id ?? '' }}"
                                               class="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                                               placeholder="Client ID">
                                    </div>
                                    
                                    <div class="space-y-2">
                                        <label class="text-sm font-medium text-slate-300">Client Secret</label>
                                        <input type="password" name="client_secret" 
                                               value="{{ $credentials->client_secret ?? '' }}"
                                               class="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                                               placeholder="Client secret">
                                    </div>
                                    
                                    <div class="space-y-2">
                                        <label class="text-sm font-medium text-slate-300">Username (Optional)</label>
                                        <input type="text" name="username" 
                                               value="{{ $credentials->username ?? '' }}"
                                               class="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                                               placeholder="Username">
                                    </div>
                                    
                                    <div class="space-y-2">
                                        <label class="text-sm font-medium text-slate-300">Password (Optional)</label>
                                        <input type="password" name="password" 
                                               value="{{ $credentials->password ?? '' }}"
                                               class="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                                               placeholder="Password">
                                    </div>
                                    
                                    <div class="space-y-2 md:col-span-2">
                                        <label class="text-sm font-medium text-slate-300">Sync Type</label>
                                        <select name="sync_type" class="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all">
                                            <option value="manual" {{ ($credentials->sync_type ?? '') == 'manual' ? 'selected' : '' }}>Manual Sync</option>
                                            <option value="realtime" {{ ($credentials->sync_type ?? '') == 'realtime' ? 'selected' : '' }}>Real-time Sync</option>
                                            <option value="scheduled" {{ ($credentials->sync_type ?? '') == 'scheduled' ? 'selected' : '' }}>Scheduled Sync</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="flex justify-between items-center mt-6 pt-4 border-t border-white/10">
                                    <div class="flex gap-3">
                                        <button type="button" class="test-connection-btn px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors flex items-center gap-2"
                                                data-location-id="{{ $location->id }}">
                                            <i class="fas fa-plug text-sm"></i>
                                            Test Connection
                                        </button>
                                        @if($credentials && $credentials->is_active)
                                        <button type="button" class="sync-location-btn px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors flex items-center gap-2"
                                                data-location-id="{{ $location->id }}">
                                            <i class="fas fa-sync text-sm"></i>
                                            Sync Now
                                        </button>
                                        @endif
                                    </div>
                                    <button type="submit" class="px-6 py-2 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white rounded-lg transition-all flex items-center gap-2">
                                        <i class="fas fa-save text-sm"></i>
                                        Save Configuration
                                    </button>
                                </div>
                            </form>
                        </div>
                        @endforeach
                    </div>
                    @endif
                </div>
            </div>

            <!-- Quick Actions & Status -->
            <div class="space-y-6">
                <!-- API Configuration Guide -->
                <div class="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6">
                    <div class="flex items-center gap-3 mb-4">
                        <i class="fas fa-info-circle text-blue-400"></i>
                        <h3 class="text-lg font-semibold text-white">Configuration Guide</h3>
                    </div>
                    
                    <div class="space-y-4">
                        <div class="p-4 bg-blue-500/10 border border-blue-500/20 rounded-xl">
                            <h4 class="font-medium text-blue-300 mb-2">API URL</h4>
                            <p class="text-sm text-slate-400">The base endpoint URL provided by the mall's API documentation.</p>
                        </div>
                        
                        <div class="p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-xl">
                            <h4 class="font-medium text-yellow-300 mb-2">API Key</h4>
                            <p class="text-sm text-slate-400">Unique authentication key for your application.</p>
                        </div>
                        
                        <div class="p-4 bg-green-500/10 border border-green-500/20 rounded-xl">
                            <h4 class="font-medium text-green-300 mb-2">Client Credentials</h4>
                            <p class="text-sm text-slate-400">Public identifier and private key used for secure authentication.</p>
                        </div>
                    </div>
                </div>

                <!-- Security Best Practices -->
                <div class="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6">
                    <div class="flex items-center gap-3 mb-4">
                        <i class="fas fa-shield-alt text-orange-400"></i>
                        <h3 class="text-lg font-semibold text-white">Security Best Practices</h3>
                    </div>
                    
                    <div class="space-y-3 text-sm text-slate-400">
                        <div class="flex items-start gap-3">
                            <i class="fas fa-check text-green-400 mt-1"></i>
                            <span>Never share credentials with unauthorized users</span>
                        </div>
                        <div class="flex items-start gap-3">
                            <i class="fas fa-check text-green-400 mt-1"></i>
                            <span>Test connections before saving settings</span>
                        </div>
                        <div class="flex items-start gap-3">
                            <i class="fas fa-check text-green-400 mt-1"></i>
                            <span>Rotate credentials regularly</span>
                        </div>
                        <div class="flex items-start gap-3">
                            <i class="fas fa-check text-green-400 mt-1"></i>
                            <span>Use HTTPS endpoints only</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Loading Modal -->
<div id="loadingModal" class="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 hidden items-center justify-center">
    <div class="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-8 text-center">
        <div class="animate-spin w-8 h-8 border-2 border-blue-400 border-t-transparent rounded-full mx-auto mb-4"></div>
        <p class="text-white">Processing...</p>
    </div>
</div>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Save configuration
    document.querySelectorAll('.location-config-form').forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const locationId = this.dataset.locationId;
            const formData = new FormData(this);
            
            showLoading();
            
            fetch(`{{ route('gallface.saveLocationCredentials', $mall_code) }}`, {
                method: 'POST',
                body: formData,
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                hideLoading();
                if (data.success) {
                    showAlert('Configuration saved successfully!', 'success');
                    location.reload();
                } else {
                    showAlert(data.message || 'Failed to save configuration', 'error');
                }
            })
            .catch(error => {
                hideLoading();
                showAlert('An error occurred while saving', 'error');
            });
        });
    });
    
    // Test connection
    document.querySelectorAll('.test-connection-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const locationId = this.dataset.locationId;
            
            showLoading();
            
            fetch(`{{ route('gallface.testLocationCredentials', [$mall_code, '']) }}/${locationId}`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                hideLoading();
                if (data.success) {
                    showAlert('Connection successful!', 'success');
                } else {
                    showAlert(data.message || 'Connection failed', 'error');
                }
            })
            .catch(error => {
                hideLoading();
                showAlert('Connection test failed', 'error');
            });
        });
    });
    
    // Sync location
    document.querySelectorAll('.sync-location-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const locationId = this.dataset.locationId;
            
            showLoading();
            
            fetch(`{{ route('gallface.syncLocationSales', [$mall_code, '']) }}/${locationId}`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                hideLoading();
                if (data.success) {
                    showAlert(`Sync completed! ${data.records_synced || 0} records synced.`, 'success');
                } else {
                    showAlert(data.message || 'Sync failed', 'error');
                }
            })
            .catch(error => {
                hideLoading();
                showAlert('Sync failed', 'error');
            });
        });
    });
    
    function showLoading() {
        document.getElementById('loadingModal').classList.remove('hidden');
        document.getElementById('loadingModal').classList.add('flex');
    }
    
    function hideLoading() {
        document.getElementById('loadingModal').classList.add('hidden');
        document.getElementById('loadingModal').classList.remove('flex');
    }
    
    function showAlert(message, type) {
        const alertDiv = document.createElement('div');
        alertDiv.className = `fixed top-4 right-4 z-50 p-4 rounded-xl border flex items-center gap-3 transition-all duration-300 ${
            type === 'success' 
                ? 'bg-green-500/10 border-green-500/20 text-green-300' 
                : 'bg-red-500/10 border-red-500/20 text-red-300'
        }`;
        
        alertDiv.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            <span>${message}</span>
            <button onclick="this.parentElement.remove()" class="ml-2 text-slate-400 hover:text-white">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        document.body.appendChild(alertDiv);
        
        setTimeout(() => {
            if (alertDiv.parentElement) {
                alertDiv.remove();
            }
        }, 5000);
    }
});
</script>
@endpush
@endsection
