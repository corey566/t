<section class="no-print">
   <nav class="bg-white/5 backdrop-blur-xl border-b border-white/10 sticky top-0 z-40">
    <div class="container mx-auto px-4">
        <div class="flex items-center justify-between h-16">
            <!-- Brand -->
            <a href="{{ action([\Modules\Gallface\Http\Controllers\GallfaceController::class, 'index']) }}" 
               class="flex items-center gap-3 text-white hover:text-blue-400 transition-colors">
                <div class="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                    <i class="fas fa-shopping-center text-sm"></i>
                </div>
                <span class="text-lg font-semibold">Mall Integration Platform</span>
            </a>

            <!-- Navigation Items -->
            <div class="hidden md:flex items-center gap-6">
                <a href="{{ action([\Modules\Gallface\Http\Controllers\GallfaceController::class, 'index']) }}" 
                   class="text-slate-300 hover:text-white transition-colors flex items-center gap-2">
                    <i class="fas fa-dashboard text-sm"></i>
                    Dashboard
                </a>

                @if(isset($mall_code) && $mall_code)
                <a href="{{ route('gallface.setting', $mall_code) }}" 
                   class="text-slate-300 hover:text-white transition-colors flex items-center gap-2">
                    <i class="fas fa-cog text-sm"></i>
                    Settings
                </a>
                @endif

                <div class="flex items-center gap-2 pl-4 border-l border-white/10">
                    <div class="w-8 h-8 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center">
                        <i class="fas fa-user text-white text-xs"></i>
                    </div>
                    <span class="text-sm text-slate-300">Admin</span>
                </div>
            </div>

            <!-- Mobile Menu Button -->
            <button class="md:hidden text-white" onclick="toggleMobileMenu()">
                <i class="fas fa-bars"></i>
            </button>
        </div>

        <!-- Mobile Menu -->
        <div id="mobileMenu" class="md:hidden hidden py-4 border-t border-white/10">
            <div class="space-y-3">
                <a href="{{ action([\Modules\Gallface\Http\Controllers\GallfaceController::class, 'index']) }}" 
                   class="block text-slate-300 hover:text-white transition-colors">
                    <i class="fas fa-dashboard mr-2"></i>Dashboard
                </a>

                @if(isset($mall_code) && $mall_code)
                <a href="{{ route('gallface.setting', $mall_code) }}" 
                   class="block text-slate-300 hover:text-white transition-colors">
                    <i class="fas fa-cog mr-2"></i>Settings
                </a>
                @endif
            </div>
        </div>
    </div>
</nav>

<script>
function toggleMobileMenu() {
    const menu = document.getElementById('mobileMenu');
    menu.classList.toggle('hidden');
}
</script>
</section>

<!-- Help Modals -->
<div class="modal fade" id="helpModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="helpModalTitle">Help</h4>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body" id="helpModalBody">
                <!-- Content will be loaded dynamically -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
function showSyncTypesHelp() {
    $('#helpModalTitle').text('Sync Types Explained');
    $('#helpModalBody').html(`
        <div class="row">
            <div class="col-md-4">
                <div class="card border-primary">
                    <div class="card-header bg-primary text-white">
                        <h5><i class="fas fa-hand-pointer"></i> Manual Sync</h5>
                    </div>
                    <div class="card-body">
                        <p>Sync data only when manually triggered by users.</p>
                        <strong>Best for:</strong>
                        <ul>
                            <li>Testing purposes</li>
                            <li>Occasional sync needs</li>
                            <li>Full control over timing</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-success">
                    <div class="card-header bg-success text-white">
                        <h5><i class="fas fa-bolt"></i> Real-time Sync</h5>
                    </div>
                    <div class="card-body">
                        <p>Automatically sync data immediately when sales are made.</p>
                        <strong>Best for:</strong>
                        <ul>
                            <li>Live inventory updates</li>
                            <li>Immediate CRM updates</li>
                            <li>High-frequency operations</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-info">
                    <div class="card-header bg-info text-white">
                        <h5><i class="fas fa-clock"></i> Scheduled Sync</h5>
                    </div>
                    <div class="card-body">
                        <p>Sync data at specific times (daily, weekly, monthly).</p>
                        <strong>Best for:</strong>
                        <ul>
                            <li>Batch processing</li>
                            <li>Off-peak hours sync</li>
                            <li>Resource optimization</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    `);
    $('#helpModal').modal('show');
}

function showAPIHelp() {
    $('#helpModalTitle').text('API Configuration Guide');
    $('#helpModalBody').html(`
        <div class="alert alert-info">
            <h5><i class="fas fa-info-circle"></i> API Configuration Requirements</h5>
            <p>To integrate with mall CRM systems, you need the following credentials:</p>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <h6><i class="fas fa-link text-primary"></i> API URL</h6>
                <p>The base endpoint URL provided by the mall's API documentation.</p>
                <code>Example: https://api.mallname.com/v1</code>
            </div>
            <div class="col-md-6">
                <h6><i class="fas fa-key text-warning"></i> API Key</h6>
                <p>Unique authentication key for your application.</p>
                <code>Example: sk_live_abc123...</code>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <h6><i class="fas fa-id-card text-success"></i> Client ID</h6>
                <p>Public identifier for your application.</p>
                <code>Example: app_123456789</code>
            </div>
            <div class="col-md-6">
                <h6><i class="fas fa-user-secret text-danger"></i> Client Secret</h6>
                <p>Private key used for secure authentication.</p>
                <code>Example: cs_secret_xyz789...</code>
            </div>
        </div>
        
        <div class="alert alert-warning mt-3">
            <h6><i class="fas fa-shield-alt"></i> Security Best Practices</h6>
            <ul>
                <li>Never share credentials with unauthorized users</li>
                <li>Test connections before saving settings</li>
                <li>Rotate credentials regularly</li>
                <li>Use HTTPS endpoints only</li>
            </ul>
        </div>
    `);
    $('#helpModal').modal('show');
}

function showAbout() {
    $('#helpModalTitle').text('About Mall Integration Platform');
    $('#helpModalBody').html(`
        <div class="text-center mb-4">
            <h3><i class="fas fa-shopping-center text-primary"></i> Mall Integration Platform</h3>
            <p class="lead">Version 6.0</p>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <h5><i class="fas fa-info-circle text-info"></i> Platform Features</h5>
                <ul>
                    <li>Multi-mall CRM integration</li>
                    <li>Real-time sales synchronization</li>
                    <li>Flexible sync scheduling</li>
                    <li>Comprehensive error handling</li>
                    <li>Business location management</li>
                    <li>Secure credential storage</li>
                </ul>
            </div>
            <div class="col-md-6">
                <h5><i class="fas fa-building text-success"></i> Supported Malls</h5>
                <ul>
                    <li><strong>One Galle Face (OGF)</strong> - Active</li>
                    <li><strong>Haveloc City Mall (HCM)</strong> - Active</li>
                    <li><strong>Colombo City Center (CCC)</strong> - Coming Soon</li>
                </ul>
            </div>
        </div>
        
        <hr>
        
        <div class="text-center">
            <p><strong>Developed by:</strong></p>
            <h4><i class="fas fa-code text-primary"></i> Yazeed Company - CodeStudio</h4>
            <p class="text-muted">Professional software development solutions</p>
        </div>
    `);
    $('#helpModal').modal('show');
}
</script>