
@extends('layouts.app')

@section('title', $current_mall['name'] . ' - Dashboard')

@section('content')
    @include('gallface::layouts.nav')
    
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="tw-text-xl md:tw-text-3xl tw-font-bold tw-text-black">
                        <i class="fas fa-building tw-mr-2"></i>
                        {{ $current_mall['name'] }}
                    </h1>
                    <p class="tw-text-gray-600">Dashboard & Sync Management</p>
                </div>
                <div class="col-sm-6">
                    <div class="float-right">
                        @if($current_mall['has_backend'])
                            <button type="button" class="btn btn-success btn-sm" id="test-connection-btn" data-mall="{{ $mall_code }}">
                                <i class="fas fa-plug tw-mr-1"></i> Test Connection
                            </button>
                            <button type="button" class="btn btn-primary btn-sm" id="manual-sync-btn" data-mall="{{ $mall_code }}">
                                <i class="fas fa-sync tw-mr-1"></i> Manual Sync
                            </button>
                        @else
                            <span class="badge badge-warning">
                                <i class="fas fa-tools tw-mr-1"></i> Backend Coming Soon
                            </span>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <section class="content">
        <div class="container-fluid">
            <!-- Stats Cards -->
            <div class="row">
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3>{{ count($business_locations) }}</h3>
                            <p>Business Locations</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-success">
                        <div class="inner">
                            <h3>{{ collect($sync_history)->where('status', 'successful')->count() }}</h3>
                            <p>Successful Syncs</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-check-circle"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-warning">
                        <div class="inner">
                            <h3>{{ collect($sync_history)->where('status', 'failed')->count() }}</h3>
                            <p>Failed Syncs</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-exclamation-triangle"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-danger">
                        <div class="inner">
                            <h3>{{ collect($sync_history)->where('status', 'in_progress')->count() }}</h3>
                            <p>In Progress</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-spinner"></i>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Sync History -->
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-history tw-mr-2"></i>
                                Recent Sync History
                            </h3>
                            <div class="card-tools">
                                <div class="input-group input-group-sm" style="width: 150px;">
                                    <input type="text" class="form-control float-right" placeholder="Search" id="sync-search">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-default">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover text-nowrap">
                                <thead>
                                    <tr>
                                        <th>Date/Time</th>
                                        <th>Type</th>
                                        <th>Location</th>
                                        <th>Records</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($sync_history as $sync)
                                    <tr>
                                        <td>{{ $sync['created_at']->format('M d, Y H:i') }}</td>
                                        <td>
                                            <span class="badge badge-{{ $sync['sync_type'] === 'manual' ? 'primary' : ($sync['sync_type'] === 'realtime' ? 'success' : 'info') }}">
                                                {{ ucfirst($sync['sync_type']) }}
                                            </span>
                                        </td>
                                        <td>{{ $sync['location_name'] }}</td>
                                        <td>{{ $sync['records_synced'] }}</td>
                                        <td>
                                            @if($sync['status'] === 'successful')
                                                <span class="badge badge-success">
                                                    <i class="fas fa-check tw-mr-1"></i>Successful
                                                </span>
                                            @elseif($sync['status'] === 'failed')
                                                <span class="badge badge-danger">
                                                    <i class="fas fa-times tw-mr-1"></i>Failed
                                                </span>
                                            @elseif($sync['status'] === 'in_progress')
                                                <span class="badge badge-warning">
                                                    <i class="fas fa-spinner fa-spin tw-mr-1"></i>In Progress
                                                </span>
                                            @endif
                                        </td>
                                        <td>
                                            <button class="btn btn-sm btn-outline-primary view-details" data-id="{{ $sync['id'] }}">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            @if($sync['status'] === 'failed')
                                                <button class="btn btn-sm btn-outline-warning retry-sync" data-id="{{ $sync['id'] }}">
                                                    <i class="fas fa-redo"></i>
                                                </button>
                                            @endif
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-bolt tw-mr-2"></i>
                                Quick Actions
                            </h3>
                        </div>
                        <div class="card-body">
                            @if($current_mall['has_backend'])
                                <div class="mb-3">
                                    <label for="location-select" class="form-label">Select Locations:</label>
                                    <select class="form-control" id="location-select" multiple>
                                        @foreach($business_locations as $location)
                                            <option value="{{ $location->id }}">{{ $location->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                
                                <div class="d-grid gap-2">
                                    <button type="button" class="btn btn-primary btn-block" id="quick-sync-btn">
                                        <i class="fas fa-sync tw-mr-2"></i>
                                        Sync Selected Locations
                                    </button>
                                    
                                    <button type="button" class="btn btn-success btn-block" id="sync-all-btn">
                                        <i class="fas fa-sync-alt tw-mr-2"></i>
                                        Sync All Locations
                                    </button>
                                    
                                    <a href="{{ action([\Modules\Gallface\Http\Controllers\GallfaceController::class, 'setting'], $mall_code) }}" class="btn btn-outline-secondary btn-block">
                                        <i class="fas fa-cog tw-mr-2"></i>
                                        Mall Settings
                                    </a>
                                </div>
                            @else
                                <div class="alert alert-info">
                                    <h5><i class="icon fas fa-info-circle"></i> Coming Soon!</h5>
                                    Backend integration for {{ $current_mall['name'] }} is currently in development. UI is ready for future integration.
                                </div>
                                
                                <a href="{{ action([\Modules\Gallface\Http\Controllers\GallfaceController::class, 'setting'], $mall_code) }}" class="btn btn-outline-secondary btn-block">
                                    <i class="fas fa-cog tw-mr-2"></i>
                                    Configure Settings
                                </a>
                            @endif
                        </div>
                    </div>

                    <!-- Sync Configuration -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-gear tw-mr-2"></i>
                                Current Configuration
                            </h3>
                        </div>
                        <div class="card-body">
                            @if(isset($mall_settings['sync_type']))
                                <div class="info-box bg-light">
                                    <span class="info-box-icon bg-info">
                                        <i class="fas fa-sync"></i>
                                    </span>
                                    <div class="info-box-content">
                                        <span class="info-box-text">Sync Type</span>
                                        <span class="info-box-number">{{ ucfirst($mall_settings['sync_type']) }}</span>
                                    </div>
                                </div>
                                
                                @if($mall_settings['sync_type'] === 'scheduled' && isset($mall_settings['scheduled_time']))
                                    <div class="info-box bg-light">
                                        <span class="info-box-icon bg-warning">
                                            <i class="fas fa-clock"></i>
                                        </span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Scheduled Time</span>
                                            <span class="info-box-number">{{ $mall_settings['scheduled_time'] }}</span>
                                        </div>
                                    </div>
                                @endif
                            @else
                                <div class="alert alert-warning">
                                    <i class="fas fa-exclamation-triangle tw-mr-2"></i>
                                    No sync configuration found. Please configure sync settings.
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Sync Modal -->
    <div class="modal fade" id="syncModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">
                        <i class="fas fa-sync tw-mr-2"></i>
                        Manual Sync
                    </h4>
                    <button type="button" class="close" data-dismiss="modal">
                        <span>&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Select business locations to sync with {{ $current_mall['name'] }}:</p>
                    <div class="form-group">
                        @foreach($business_locations as $location)
                            <div class="form-check">
                                <input class="form-check-input sync-location" type="checkbox" value="{{ $location->id }}" id="loc-{{ $location->id }}">
                                <label class="form-check-label" for="loc-{{ $location->id }}">
                                    {{ $location->name }}
                                </label>
                            </div>
                        @endforeach
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="confirm-sync-btn">
                        <i class="fas fa-sync tw-mr-2"></i>
                        Start Sync
                    </button>
                </div>
            </div>
        </div>
    </div>

@stop

@section('javascript')
<script>
$(document).ready(function() {
    const mallCode = '{{ $mall_code }}';
    
    // Test Connection
    $('#test-connection-btn').click(function() {
        const btn = $(this);
        btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Testing...');
        
        $.ajax({
            url: `/gallface/${mallCode}/test-connection`,
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                if (response.success) {
                    toastr.success(response.message);
                } else {
                    toastr.error(response.message);
                }
            },
            error: function() {
                toastr.error('Connection test failed');
            },
            complete: function() {
                btn.prop('disabled', false).html('<i class="fas fa-plug"></i> Test Connection');
            }
        });
    });
    
    // Manual Sync Modal
    $('#manual-sync-btn').click(function() {
        $('#syncModal').modal('show');
    });
    
    // Quick Sync
    $('#quick-sync-btn').click(function() {
        const selectedLocations = $('#location-select').val();
        if (selectedLocations.length === 0) {
            toastr.warning('Please select at least one location');
            return;
        }
        performSync(selectedLocations);
    });
    
    // Sync All
    $('#sync-all-btn').click(function() {
        const allLocations = @json($business_locations->pluck('id'));
        performSync(allLocations);
    });
    
    // Confirm Sync
    $('#confirm-sync-btn').click(function() {
        const selectedLocations = [];
        $('.sync-location:checked').each(function() {
            selectedLocations.push($(this).val());
        });
        
        if (selectedLocations.length === 0) {
            toastr.warning('Please select at least one location');
            return;
        }
        
        $('#syncModal').modal('hide');
        performSync(selectedLocations);
    });
    
    function performSync(locationIds) {
        $.ajax({
            url: `/gallface/${mallCode}/manual-sync`,
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: {
                location_ids: locationIds
            },
            success: function(response) {
                if (response.success) {
                    toastr.success(response.message);
                    setTimeout(() => location.reload(), 2000);
                } else {
                    toastr.error(response.message);
                }
            },
            error: function() {
                toastr.error('Sync request failed');
            }
        });
    }
    
    // Search functionality
    $('#sync-search').on('keyup', function() {
        const value = $(this).val().toLowerCase();
        $('tbody tr').filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
        });
    });
});
</script>
@stop
