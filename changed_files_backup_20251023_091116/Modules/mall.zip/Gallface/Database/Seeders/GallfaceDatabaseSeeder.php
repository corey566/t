
<?php

namespace Modules\Gallface\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class GallfaceDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();

        // Seed mall configurations
        $this->seedMalls();
        
        // Seed default units if needed
        $this->seedDefaultUnits();
        
        // Seed default expense categories if needed
        $this->seedDefaultExpenseCategories();
    }

    private function seedMalls()
    {
        $malls = [
            [
                'name' => 'One Galle Face (OGF)',
                'code' => 'ogf',
                'status' => 'active',
                'has_backend' => true,
                'api_config' => json_encode([
                    'timeout' => 30,
                    'retry_attempts' => 3,
                    'rate_limit' => 100
                ]),
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'name' => 'Havelock City Mall (HCM)',
                'code' => 'hcm', 
                'status' => 'active',
                'has_backend' => true,
                'api_config' => json_encode([
                    'timeout' => 30,
                    'retry_attempts' => 3,
                    'rate_limit' => 100,
                    'supports_realtime' => true,
                    'supports_webhooks' => true
                ]),
                'api_url' => 'https://hcm-api.example.com',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'name' => 'Colombo City Center (CCC)',
                'code' => 'ccc',
                'status' => 'coming_soon',
                'has_backend' => false,
                'api_config' => json_encode([]),
                'created_at' => now(),
                'updated_at' => now()
            ]
        ];

        DB::table('gallface_malls')->insert($malls);
    }

    private function seedDefaultUnits()
    {
        // Only seed if units table is empty and business exists
        if (DB::table('units')->count() == 0 && DB::table('business')->count() > 0) {
            $businessId = DB::table('business')->first()->id ?? 1;
            $userId = DB::table('users')->first()->id ?? 1;
            
            $units = [
                [
                    'business_id' => $businessId,
                    'actual_name' => 'Pieces',
                    'short_name' => 'Pc(s)',
                    'allow_decimal' => 0,
                    'created_by' => $userId,
                    'created_at' => now(),
                    'updated_at' => now()
                ],
                [
                    'business_id' => $businessId,
                    'actual_name' => 'Kilograms',
                    'short_name' => 'Kg',
                    'allow_decimal' => 1,
                    'created_by' => $userId,
                    'created_at' => now(),
                    'updated_at' => now()
                ]
            ];

            DB::table('units')->insert($units);
        }
    }

    private function seedDefaultExpenseCategories()
    {
        // Only seed if expense_categories table is empty and business exists
        if (DB::table('expense_categories')->count() == 0 && DB::table('business')->count() > 0) {
            $businessId = DB::table('business')->first()->id ?? 1;
            
            $categories = [
                [
                    'name' => 'Mall Integration Fees',
                    'business_id' => $businessId,
                    'code' => 'MALL_FEES',
                    'created_at' => now(),
                    'updated_at' => now()
                ],
                [
                    'name' => 'Sync Operation Costs',
                    'business_id' => $businessId,
                    'code' => 'SYNC_COSTS',
                    'created_at' => now(),
                    'updated_at' => now()
                ]
            ];

            DB::table('expense_categories')->insert($categories);
        }
    }
}
