
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        // Units table (if not exists)
        if (!Schema::hasTable('units')) {
            Schema::create('units', function (Blueprint $table) {
                $table->increments('id');
                $table->unsignedInteger('business_id');
                $table->string('actual_name');
                $table->string('short_name');
                $table->boolean('allow_decimal');
                $table->integer('base_unit_id')->nullable();
                $table->decimal('base_unit_multiplier', 20, 4)->nullable();
                $table->unsignedInteger('created_by');
                $table->timestamp('deleted_at')->nullable();
                $table->timestamps();
                
                $table->foreign('business_id')->references('id')->on('business')->onDelete('cascade');
                $table->index(['business_id', 'created_by']);
            });
        }

        // Expense categories table (if not exists)
        if (!Schema::hasTable('expense_categories')) {
            Schema::create('expense_categories', function (Blueprint $table) {
                $table->increments('id');
                $table->string('name');
                $table->unsignedInteger('business_id');
                $table->string('code')->nullable();
                $table->integer('parent_id')->nullable();
                $table->timestamp('deleted_at')->nullable();
                $table->timestamps();
                
                $table->foreign('business_id')->references('id')->on('business')->onDelete('cascade');
                $table->index(['business_id', 'parent_id']);
            });
        }

        // Users table modifications (if needed)
        if (!Schema::hasColumn('users', 'business_id')) {
            Schema::table('users', function (Blueprint $table) {
                $table->unsignedInteger('business_id')->nullable()->after('email');
                $table->string('user_type')->default('user')->after('id');
                $table->char('surname', 10)->nullable()->after('user_type');
                $table->string('first_name')->after('name');
                $table->string('last_name')->nullable()->after('first_name');
                $table->string('username')->nullable()->unique()->after('last_name');
                $table->char('language', 7)->default('en')->after('password');
                $table->char('contact_no', 15)->nullable()->after('language');
                $table->text('address')->nullable()->after('contact_no');
                $table->boolean('allow_login')->default(true)->after('address');
                $table->enum('status', ['active', 'inactive', 'terminated'])->default('active')->after('allow_login');
                
                $table->foreign('business_id')->references('id')->on('business')->onDelete('cascade');
            });
        }
    }

    public function down()
    {
        Schema::dropIfExists('expense_categories');
        Schema::dropIfExists('units');
        
        if (Schema::hasColumn('users', 'business_id')) {
            Schema::table('users', function (Blueprint $table) {
                $table->dropForeign(['business_id']);
                $table->dropColumn(['business_id', 'user_type', 'surname', 'first_name', 'last_name', 'username', 'language', 'contact_no', 'address', 'allow_login', 'status']);
            });
        }
    }
};
