
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        // Mall configurations table
        Schema::create('gallface_malls', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('code')->unique();
            $table->enum('status', ['active', 'inactive', 'coming_soon'])->default('active');
            $table->boolean('has_backend')->default(true);
            $table->json('api_config')->nullable();
            $table->string('api_url')->nullable();
            $table->string('api_key')->nullable();
            $table->timestamps();
        });

        // Sync configurations table
        Schema::create('gallface_sync_configs', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('business_id');
            $table->string('mall_code');
            $table->enum('sync_type', ['manual', 'realtime', 'scheduled'])->default('manual');
            $table->json('sync_settings')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            
            $table->foreign('business_id')->references('id')->on('business')->onDelete('cascade');
            $table->index(['business_id', 'mall_code']);
        });

        // Sync logs table
        Schema::create('gallface_sync_logs', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('business_id');
            $table->string('mall_code');
            $table->string('sync_type');
            $table->enum('status', ['pending', 'in_progress', 'successful', 'failed', 'syncing'])->default('pending');
            $table->string('entity_type')->nullable(); // products, orders, inventory, etc.
            $table->unsignedInteger('entity_id')->nullable();
            $table->json('request_data')->nullable();
            $table->json('response_data')->nullable();
            $table->text('error_message')->nullable();
            $table->timestamp('started_at')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->unsignedInteger('created_by');
            $table->timestamps();
            
            $table->foreign('business_id')->references('id')->on('business')->onDelete('cascade');
            $table->index(['business_id', 'mall_code', 'status']);
            $table->index(['entity_type', 'entity_id']);
        });

        // Mall product mappings table
        Schema::create('gallface_product_mappings', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('business_id');
            $table->unsignedInteger('product_id');
            $table->unsignedInteger('variation_id');
            $table->string('mall_code');
            $table->string('mall_product_id');
            $table->string('mall_sku')->nullable();
            $table->json('mall_data')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamp('last_synced_at')->nullable();
            $table->timestamps();
            
            $table->foreign('business_id')->references('id')->on('business')->onDelete('cascade');
            $table->unique(['product_id', 'variation_id', 'mall_code'], 'unique_product_mall');
            $table->index(['mall_code', 'mall_product_id']);
        });

        // Mall order mappings table
        Schema::create('gallface_order_mappings', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('business_id');
            $table->unsignedInteger('transaction_id');
            $table->string('mall_code');
            $table->string('mall_order_id');
            $table->string('mall_order_number')->nullable();
            $table->enum('sync_status', ['pending', 'synced', 'failed'])->default('pending');
            $table->json('mall_order_data')->nullable();
            $table->timestamp('mall_order_date')->nullable();
            $table->timestamp('last_synced_at')->nullable();
            $table->timestamps();
            
            $table->foreign('business_id')->references('id')->on('business')->onDelete('cascade');
            $table->unique(['transaction_id', 'mall_code'], 'unique_order_mall');
            $table->index(['mall_code', 'mall_order_id']);
        });

        // Mall inventory sync table
        Schema::create('gallface_inventory_sync', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('business_id');
            $table->unsignedInteger('product_id');
            $table->unsignedInteger('variation_id');
            $table->unsignedInteger('location_id');
            $table->string('mall_code');
            $table->decimal('local_quantity', 22, 4)->default(0);
            $table->decimal('mall_quantity', 22, 4)->default(0);
            $table->enum('sync_status', ['pending', 'synced', 'failed'])->default('pending');
            $table->timestamp('last_synced_at')->nullable();
            $table->timestamps();
            
            $table->foreign('business_id')->references('id')->on('business')->onDelete('cascade');
            $table->unique(['product_id', 'variation_id', 'location_id', 'mall_code'], 'unique_inventory_sync');
        });
    }

    public function down()
    {
        Schema::dropIfExists('gallface_inventory_sync');
        Schema::dropIfExists('gallface_order_mappings');
        Schema::dropIfExists('gallface_product_mappings');
        Schema::dropIfExists('gallface_sync_logs');
        Schema::dropIfExists('gallface_sync_configs');
        Schema::dropIfExists('gallface_malls');
    }
};
