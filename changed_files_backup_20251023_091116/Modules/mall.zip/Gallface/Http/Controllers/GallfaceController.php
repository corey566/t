<?php

namespace Modules\Gallface\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Business;
use App\BusinessLocation;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Modules\Gallface\Models\LocationApiCredential;
use Modules\Gallface\Services\HcmApiService;
use Carbon\Carbon;

class GallfaceController extends Controller
{
    /**
     * Display main dashboard with mall selection
     * @return Renderable
     */
    public function index()
    {
        $malls = config('gallface.malls');
        return view('gallface::index', compact('malls'));
    }
    
    /**
     * Display mall-specific dashboard
     * @param string $mall_code
     * @return Renderable
     */
    public function dashboard($mall_code = 'ogf')
    {
        $business_id = request()->session()->get('user.business_id');
        $malls = config('gallface.malls');
        
        if (!isset($malls[$mall_code])) {
            abort(404, 'Mall not found');
        }
        
        $current_mall = $malls[$mall_code];
        
        // Get business locations with their API credentials
        $business_locations = BusinessLocation::where('business_id', $business_id)
            ->with(['locationApiCredentials' => function($query) use ($mall_code) {
                $query->where('mall_code', $mall_code);
            }])
            ->get();
        
        // Get sync history
        $sync_history = $this->getSyncHistory($business_id, $mall_code);
        
        // Get configured locations count
        $configured_locations = LocationApiCredential::where('business_id', $business_id)
            ->where('mall_code', $mall_code)
            ->where('is_active', true)
            ->count();
        
        return view('gallface::dashboard', compact(
            'malls', 
            'current_mall', 
            'mall_code', 
            'business_locations', 
            'sync_history',
            'configured_locations'
        ));
    }
    
    /**
     * Display mall-specific settings
     * @param string $mall_code
     * @return Renderable
     */
    public function setting(Request $request, $mall_code = 'ogf')
    {
        $business_id = request()->session()->get('user.business_id');
        $malls = config('gallface.malls');
        
        if (!isset($malls[$mall_code])) {
            abort(404, 'Mall not found');
        }
        
        $current_mall = $malls[$mall_code];
        
        // Get business locations with their API credentials
        $business_locations = BusinessLocation::where('business_id', $business_id)
            ->with(['locationApiCredentials' => function($query) use ($mall_code) {
                $query->where('mall_code', $mall_code);
            }])
            ->get();
        
        return view('gallface::setting', compact(
            'malls', 
            'current_mall', 
            'mall_code',
            'business_locations'
        ));
    }
    
    /**
     * Test API connection for a mall
     * @param Request $request
     * @param string $mall_code
     * @return \Illuminate\Http\JsonResponse
     */
    public function testConnection(Request $request, $mall_code)
    {
        try {
            $business_id = request()->session()->get('user.business_id');
            $business = Business::find($business_id);
            $mall_settings = $this->getMallSettings($business, $mall_code);
            
            if (!$mall_settings || empty($mall_settings['api_url']) || empty($mall_settings['api_key'])) {
                return response()->json([
                    'success' => false,
                    'message' => 'Mall API credentials not configured'
                ]);
            }
            
            // Mock API test - replace with actual API call
            if ($mall_code === 'ccc') {
                return response()->json([
                    'success' => false,
                    'message' => 'CCC backend integration coming soon'
                ]);
            }
            
            return response()->json([
                'success' => true,
                'message' => 'Connection successful'
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Connection failed: ' . $e->getMessage()
            ]);
        }
    }
    
    /**
     * Manual sync for a mall
     * @param Request $request
     * @param string $mall_code
     * @return \Illuminate\Http\JsonResponse
     */
    public function manualSync(Request $request, $mall_code)
    {
        try {
            $business_id = request()->session()->get('user.business_id');
            $location_ids = $request->input('location_ids', []);
            
            if (empty($location_ids)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Please select at least one business location'
                ]);
            }
            
            if ($mall_code === 'ccc') {
                return response()->json([
                    'success' => false,
                    'message' => 'CCC backend integration coming soon'
                ]);
            }
            
            // Start sync process (mock for now)
            foreach ($location_ids as $location_id) {
                // Log sync attempt
                $this->logSyncAttempt($business_id, $mall_code, $location_id, 'manual');
            }
            
            return response()->json([
                'success' => true,
                'message' => 'Manual sync initiated for selected locations'
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Sync failed: ' . $e->getMessage()
            ]);
        }
    }
    
    /**
     * Get sync history for dashboard
     */
    private function getSyncHistory($business_id, $mall_code, $limit = 10)
    {
        // Mock data - replace with actual database queries
        $statuses = ['successful', 'failed', 'in_progress'];
        $sync_types = ['manual', 'realtime', 'scheduled'];
        
        $history = [];
        for ($i = 0; $i < $limit; $i++) {
            $history[] = [
                'id' => $i + 1,
                'sync_type' => $sync_types[array_rand($sync_types)],
                'status' => $statuses[array_rand($statuses)],
                'location_name' => 'Location ' . ($i + 1),
                'records_synced' => rand(0, 100),
                'created_at' => Carbon::now()->subHours(rand(1, 24)),
                'error_message' => null
            ];
        }
        
        return $history;
    }
    
    /**
     * Get mall-specific settings
     */
    private function getMallSettings($business, $mall_code)
    {
        $all_settings = json_decode($business->gallface_setting ?? '{}', true);
        return $all_settings[$mall_code] ?? [];
    }
    
    /**
     * Update mall-specific settings
     */
    private function updateMallSettings(Request $request, $business, $mall_code)
    {
        $validator = Validator::make($request->all(), [
            'api_url' => 'required|url',
            'api_key' => 'required|string',
            'client_id' => 'required|string',
            'client_secret' => 'required|string',
            'sync_type' => 'required|in:manual,realtime,scheduled',
            'selected_locations' => 'array'
        ]);
        
        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }
        
        try {
            $all_settings = json_decode($business->gallface_setting ?? '{}', true);
            
            $all_settings[$mall_code] = [
                'api_url' => $request->input('api_url'),
                'api_key' => $request->input('api_key'),
                'client_id' => $request->input('client_id'),
                'client_secret' => $request->input('client_secret'),
                'sync_type' => $request->input('sync_type'),
                'selected_locations' => $request->input('selected_locations', []),
                'scheduled_time' => $request->input('scheduled_time'),
                'scheduled_frequency' => $request->input('scheduled_frequency'),
                'is_active' => $request->boolean('is_active'),
                'updated_at' => now()
            ];
            
            $business->gallface_setting = json_encode($all_settings);
            $business->save();
            
            Session::flash('success', 'Mall settings updated successfully');
            
        } catch (\Exception $e) {
            Session::flash('error', 'Failed to update settings: ' . $e->getMessage());
        }
        
        return redirect()->back();
    }
    
    /**
     * Log sync attempt
     */
    private function logSyncAttempt($business_id, $mall_code, $location_id, $sync_type, $status = 'pending', $records_synced = 0, $error_message = null)
    {
        try {
            DB::table('gallface_sync_logs')->insert([
                'business_id' => $business_id,
                'mall_code' => $mall_code,
                'sync_type' => $sync_type,
                'status' => $status,
                'entity_type' => 'sales',
                'entity_id' => $location_id,
                'request_data' => json_encode(['location_id' => $location_id]),
                'response_data' => json_encode(['records_synced' => $records_synced]),
                'error_message' => $error_message,
                'started_at' => now(),
                'completed_at' => $status !== 'pending' ? now() : null,
                'created_by' => request()->session()->get('user.id', 1),
                'created_at' => now(),
                'updated_at' => now()
            ]);
        } catch (\Exception $e) {
            \Log::error("Failed to log sync attempt", [
                'error' => $e->getMessage(),
                'business_id' => $business_id,
                'mall_code' => $mall_code,
                'location_id' => $location_id,
                'sync_type' => $sync_type,
            ]);
        }
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        return view('gallface::create');
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        return view('gallface::show');
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        return view('gallface::edit');
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Save location API credentials
     */
    public function saveLocationCredentials(Request $request, $mall_code)
    {
        $validator = Validator::make($request->all(), [
            'location_id' => 'required|integer|exists:business_locations,id',
            'api_url' => 'required|url',
            'api_key' => 'required|string',
            'client_id' => 'required|string',
            'client_secret' => 'required|string',
            'username' => 'nullable|string',
            'password' => 'nullable|string',
            'sync_type' => 'required|in:manual,realtime,scheduled',
        ]);
        
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }
        
        try {
            $business_id = request()->session()->get('user.business_id');
            
            $credentials = LocationApiCredential::updateOrCreate(
                [
                    'business_id' => $business_id,
                    'business_location_id' => $request->location_id,
                    'mall_code' => $mall_code
                ],
                [
                    'api_url' => $request->api_url,
                    'api_key' => $request->api_key,
                    'client_id' => $request->client_id,
                    'client_secret' => $request->client_secret,
                    'username' => $request->username,
                    'password' => $request->password,
                    'sync_type' => $request->sync_type,
                    'is_active' => true
                ]
            );
            
            return response()->json([
                'success' => true,
                'message' => 'API credentials saved successfully'
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to save credentials: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Test location API credentials
     */
    public function testLocationCredentials(Request $request, $mall_code, $location_id)
    {
        try {
            $business_id = request()->session()->get('user.business_id');
            
            $credentials = LocationApiCredential::where('business_id', $business_id)
                ->where('business_location_id', $location_id)
                ->where('mall_code', $mall_code)
                ->first();
            
            if (!$credentials) {
                return response()->json([
                    'success' => false,
                    'message' => 'No API credentials found for this location'
                ]);
            }
            
            if (!$credentials->hasCompleteCredentials()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Incomplete API credentials'
                ]);
            }
            
            if ($mall_code === 'hcm') {
                $apiService = new HcmApiService($credentials->getCredentialsForApi());
                $result = $apiService->testConnection();
                
                return response()->json($result);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Mall integration not yet implemented'
                ]);
            }
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Connection test failed: ' . $e->getMessage()
            ]);
        }
    }
    
    /**
     * Sync sales for specific location
     */
    public function syncLocationSales(Request $request, $mall_code, $location_id)
    {
        try {
            $business_id = request()->session()->get('user.business_id');
            
            $credentials = LocationApiCredential::where('business_id', $business_id)
                ->where('business_location_id', $location_id)
                ->where('mall_code', $mall_code)
                ->where('is_active', true)
                ->first();
            
            if (!$credentials) {
                return response()->json([
                    'success' => false,
                    'message' => 'No active API credentials found for this location'
                ]);
            }
            
            if ($mall_code === 'hcm') {
                // Get recent sales data (last 7 days)
                $salesData = $this->getRecentSalesData($business_id, $location_id);
                
                $apiService = new HcmApiService($credentials->getCredentialsForApi());
                $result = $apiService->syncSales($salesData, $location_id);
                
                if ($result['success']) {
                    $credentials->update(['last_synced_at' => now()]);
                    
                    // Log sync attempt
                    $this->logSyncAttempt($business_id, $mall_code, $location_id, 'manual', 'successful', $result['records_synced']);
                }
                
                return response()->json($result);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Mall integration not yet implemented'
                ]);
            }
            
        } catch (\Exception $e) {
            $this->logSyncAttempt($business_id ?? 0, $mall_code, $location_id, 'manual', 'failed', 0, $e->getMessage());
            
            return response()->json([
                'success' => false,
                'message' => 'Sync failed: ' . $e->getMessage()
            ]);
        }
    }
    
    /**
     * Get recent sales data for sync
     */
    private function getRecentSalesData($business_id, $location_id)
    {
        // This is a mock implementation - replace with actual data retrieval
        return [
            [
                'invoice_no' => 'INV-001',
                'transaction_date' => now()->toDateTimeString(),
                'customer_id' => null,
                'final_total' => 100.00,
                'tax_amount' => 10.00,
                'discount_amount' => 0.00,
                'payment_method' => 'cash',
                'payment_status' => 'paid',
                'sell_lines' => [
                    [
                        'product_id' => 1,
                        'variation_id' => 1,
                        'quantity' => 2,
                        'unit_price_before_discount' => 45.00,
                        'unit_price_inc_tax' => 50.00,
                        'line_discount_amount' => 0.00,
                        'item_tax' => 5.00,
                        'product' => [
                            'sku' => 'PROD-001',
                            'name' => 'Sample Product'
                        ]
                    ]
                ]
            ]
        ];
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        //
    }
}
