<?php

namespace Modules\Gallface\Http\Controllers;

use App\Business;
use App\Utils\ModuleUtil;
use App\Utils\Util;
use Illuminate\Routing\Controller;
use Menu;

class DataController extends Controller
{
    /**
     * Superadmin package permissions
     *
     * @return array
     */
    public function superadmin_package()
    {
        return [
            [
                'name' => 'gallface_module',
                'label' => __('Mall Integration Platform'),
                'default' => false,
            ],
        ];
    }

    /**
     * Adds cms menus
     *
     * @return null
     */
    public function modifyAdminMenu()
    {
        $business_id = session()->get('user.business_id');
        $module_util = new ModuleUtil();

        $is_gallface_enabled = (bool) $module_util->hasThePermissionInSubscription($business_id, 'gallface_module');

        $commonUtil = new Util();
        $is_admin = $commonUtil->is_admin(auth()->user(), $business_id);

        if (auth()->user()->can('gallface.access_gallface_module') && $is_gallface_enabled) {
            Menu::modify(
                'admin-sidebar-menu',
                function ($menu) {
                    $menu->url(action([\Modules\Gallface\Http\Controllers\GallfaceController::class, 'index']), __('Mall Integration'), ['icon' => '<svg aria-hidden="true" class="tw-size-5 tw-shrink-0" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                    <path d="M3 21l18 0"></path>
                    <path d="M3 10l18 0"></path>
                    <path d="M5 6l7 -3l7 3"></path>
                    <path d="M4 10l0 11"></path>
                    <path d="M20 10l0 11"></path>
                    <path d="M8 14l0 3"></path>
                    <path d="M12 14l0 3"></path>
                    <path d="M16 14l0 3"></path>
                  </svg>', 'style' => config('app.env') == 'demo' ? 'background-color: #D483D9;color:white' : '', 'active' => request()->segment(1) == 'gallface'])->order(51);
                }
            );
        }
    }

    /**
     * Defines user permissions for the module.
     *
     * @return array
     */
    public function user_permissions()
    {
        return [
            [
                'value' => 'gallface.access_gallface_module',
                'label' => __('Access Mall Integration Module'),
                'default' => false,
            ],
            [
                'value' => 'gallface.manage_mall_settings',
                'label' => __('Manage Mall Settings'),
                'default' => false,
            ],
            [
                'value' => 'gallface.sync_data',
                'label' => __('Sync Mall Data'),
                'default' => false,
            ],
            [
                'value' => 'gallface.view_sync_history',
                'label' => __('View Sync History'),
                'default' => false,
            ],
            [
                'value' => 'gallface.test_connections',
                'label' => __('Test Mall Connections'),
                'default' => false,
            ],
        ];
    }
}