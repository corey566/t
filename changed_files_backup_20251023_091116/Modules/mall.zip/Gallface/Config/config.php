
<?php

return [
    'name' => 'Gallface',
    'malls' => [
        'ogf' => [
            'name' => 'One Galle Face (OGF)',
            'icon' => 'fas fa-building',
            'status' => 'active',
            'description' => 'Premium shopping mall in Colombo',
            'api_status' => 'active',
            'features' => [
                'real_time_sync' => true,
                'scheduled_sync' => true,
                'manual_sync' => true,
                'sales_reporting' => true
            ]
        ],
        'hcm' => [
            'name' => 'Havelock City Mall (HCM)',
            'icon' => 'fas fa-shopping-center',
            'status' => 'active',
            'description' => 'Modern shopping destination',
            'api_status' => 'active',
            'features' => [
                'real_time_sync' => true,
                'scheduled_sync' => true,
                'manual_sync' => true,
                'sales_reporting' => true
            ]
        ],
        'ccc' => [
            'name' => 'Colombo City Center (CCC)',
            'icon' => 'fas fa-city',
            'status' => 'coming_soon',
            'description' => 'Integration coming soon',
            'api_status' => 'pending',
            'features' => [
                'real_time_sync' => false,
                'scheduled_sync' => false,
                'manual_sync' => false,
                'sales_reporting' => false
            ]
        ]
    ],
    'sync_types' => [
        'manual' => [
            'name' => 'Manual Sync',
            'description' => 'Sync data only when manually triggered by users',
            'icon' => 'fas fa-hand-pointer'
        ],
        'realtime' => [
            'name' => 'Real-time Sync',
            'description' => 'Automatically sync data immediately when sales are recorded',
            'icon' => 'fas fa-bolt'
        ],
        'scheduled' => [
            'name' => 'Scheduled Sync',
            'description' => 'Sync data at specific times (daily, weekly, monthly)',
            'icon' => 'fas fa-clock'
        ]
    ]
];
