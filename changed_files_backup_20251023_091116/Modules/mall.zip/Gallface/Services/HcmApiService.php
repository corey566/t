
<?php

namespace Modules\Gallface\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Exception;

class HcmApiService
{
    private $apiUrl;
    private $apiKey;
    private $clientId;
    private $clientSecret;
    private $username;
    private $password;
    private $timeout = 30;

    public function __construct($credentials)
    {
        $this->apiUrl = rtrim($credentials['api_url'], '/');
        $this->apiKey = $credentials['api_key'];
        $this->clientId = $credentials['client_id'];
        $this->clientSecret = $credentials['client_secret'];
        $this->username = $credentials['username'] ?? null;
        $this->password = $credentials['password'] ?? null;
    }

    /**
     * Test API connection
     */
    public function testConnection()
    {
        try {
            $response = Http::timeout($this->timeout)
                ->withHeaders([
                    'X-API-Key' => $this->apiKey,
                    'Content-Type' => 'application/json',
                ])
                ->get($this->apiUrl . '/api/test');

            return [
                'success' => $response->successful(),
                'message' => $response->successful() ? 'Connection successful' : 'Connection failed',
                'data' => $response->json()
            ];
        } catch (Exception $e) {
            Log::error('HCM API Connection Test Failed', [
                'error' => $e->getMessage(),
                'api_url' => $this->apiUrl
            ]);
            
            return [
                'success' => false,
                'message' => 'Connection failed: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Sync sales data to HCM
     */
    public function syncSales($salesData, $locationId)
    {
        try {
            $formattedData = $this->formatSalesData($salesData, $locationId);
            
            $response = Http::timeout($this->timeout)
                ->withHeaders([
                    'X-API-Key' => $this->apiKey,
                    'X-Client-ID' => $this->clientId,
                    'X-Client-Secret' => $this->clientSecret,
                    'Content-Type' => 'application/json',
                ])
                ->post($this->apiUrl . '/api/sales/sync', $formattedData);

            if ($response->successful()) {
                return [
                    'success' => true,
                    'message' => 'Sales synced successfully',
                    'data' => $response->json(),
                    'records_synced' => count($salesData)
                ];
            } else {
                throw new Exception('API returned error: ' . $response->body());
            }
        } catch (Exception $e) {
            Log::error('HCM Sales Sync Failed', [
                'error' => $e->getMessage(),
                'location_id' => $locationId,
                'api_url' => $this->apiUrl
            ]);
            
            return [
                'success' => false,
                'message' => 'Sync failed: ' . $e->getMessage(),
                'records_synced' => 0
            ];
        }
    }

    /**
     * Get sales data from HCM
     */
    public function getSalesData($locationId, $dateFrom = null, $dateTo = null)
    {
        try {
            $params = [
                'location_id' => $locationId,
            ];
            
            if ($dateFrom) $params['date_from'] = $dateFrom;
            if ($dateTo) $params['date_to'] = $dateTo;
            
            $response = Http::timeout($this->timeout)
                ->withHeaders([
                    'X-API-Key' => $this->apiKey,
                    'X-Client-ID' => $this->clientId,
                    'X-Client-Secret' => $this->clientSecret,
                ])
                ->get($this->apiUrl . '/api/sales', $params);

            if ($response->successful()) {
                return [
                    'success' => true,
                    'data' => $response->json()
                ];
            } else {
                throw new Exception('API returned error: ' . $response->body());
            }
        } catch (Exception $e) {
            Log::error('HCM Get Sales Data Failed', [
                'error' => $e->getMessage(),
                'location_id' => $locationId
            ]);
            
            return [
                'success' => false,
                'message' => 'Failed to get sales data: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Format sales data for HCM API
     */
    private function formatSalesData($salesData, $locationId)
    {
        $formatted = [
            'location_id' => $locationId,
            'sync_timestamp' => now()->toISOString(),
            'sales' => []
        ];

        foreach ($salesData as $sale) {
            $formatted['sales'][] = [
                'invoice_no' => $sale['invoice_no'] ?? '',
                'transaction_date' => $sale['transaction_date'] ?? '',
                'customer_id' => $sale['customer_id'] ?? null,
                'total_amount' => $sale['final_total'] ?? 0,
                'tax_amount' => $sale['tax_amount'] ?? 0,
                'discount_amount' => $sale['discount_amount'] ?? 0,
                'payment_method' => $sale['payment_method'] ?? 'cash',
                'status' => $sale['payment_status'] ?? 'paid',
                'items' => $this->formatSaleItems($sale['sell_lines'] ?? [])
            ];
        }

        return $formatted;
    }

    /**
     * Format sale items for HCM API
     */
    private function formatSaleItems($sellLines)
    {
        $items = [];
        
        foreach ($sellLines as $line) {
            $items[] = [
                'product_id' => $line['product_id'] ?? '',
                'variation_id' => $line['variation_id'] ?? '',
                'sku' => $line['product']['sku'] ?? '',
                'product_name' => $line['product']['name'] ?? '',
                'quantity' => $line['quantity'] ?? 0,
                'unit_price' => $line['unit_price_before_discount'] ?? 0,
                'unit_price_inc_tax' => $line['unit_price_inc_tax'] ?? 0,
                'line_discount_amount' => $line['line_discount_amount'] ?? 0,
                'item_tax' => $line['item_tax'] ?? 0
            ];
        }
        
        return $items;
    }
}
