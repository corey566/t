<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/* Route::prefix('gallface')->group(function() {
    Route::get('/', 'GallfaceController@index');
}); */

Route::middleware('web', 'SetSessionData', 'auth', 'language', 'timezone', 'AdminSidebarMenu')->prefix('gallface')->group(function () {

	Route::get('dashboard', [\Modules\Gallface\Http\Controllers\GallfaceController::class, 'dashboard']);
	Route::any('setting', [\Modules\Gallface\Http\Controllers\GallfaceController::class, 'setting']);

	// Gallface API Routes
	Route::prefix('api')->group(function () {
		Route::post('save', [\Modules\Gallface\Http\Controllers\GallfaceController::class, 'saveGallfaceApi']);
		Route::post('update/{id}', [\Modules\Gallface\Http\Controllers\GallfaceController::class, 'updateGallfaceApi']);
		Route::delete('delete/{id}', [\Modules\Gallface\Http\Controllers\GallfaceController::class, 'deleteGallfaceApi']);
		Route::post('location/{location_id}/test', [\Modules\Gallface\Http\Controllers\GallfaceController::class, 'testGallfaceConnection']);
		Route::post('location/{location_id}/sync', [\Modules\Gallface\Http\Controllers\GallfaceController::class, 'syncGallfaceSales']);
		Route::post('location/{location_id}/ping', [\Modules\Gallface\Http\Controllers\GallfaceController::class, 'sendGallfacePing']);
	});
    Route::get('/invoices', 'GallfaceController@getGallfaceInvoices');
	Route::get('location/{location_id}/invoice-history', [\Modules\Gallface\Http\Controllers\GallfaceController::class, 'viewGallfaceInvoiceHistory']);

	// HCM Integration Routes
	Route::prefix('hcm')->group(function () {
		Route::get('credentials', [\Modules\Gallface\Http\Controllers\GallfaceController::class, 'hcmCredentials']);
		Route::post('save-credentials/{location_id}', [\Modules\Gallface\Http\Controllers\GallfaceController::class, 'saveHcmCredentials']);
		Route::delete('delete-credentials/{location_id}', [\Modules\Gallface\Http\Controllers\GallfaceController::class, 'deleteHcmCredentials']);
		Route::post('test-api', [\Modules\Gallface\Http\Controllers\HcmTestController::class, 'testHcmApi']);
		Route::post('test-all-invoice-types', [\Modules\Gallface\Http\Controllers\HcmTestController::class, 'testAllInvoiceTypes']);
		Route::get('location/{location_id}/invoice-history', [\Modules\Gallface\Http\Controllers\HcmController::class, 'viewInvoiceHistory']);
		Route::post('location/{location_id}/ping', [\Modules\Gallface\Http\Controllers\HcmController::class, 'sendPing']);
		Route::post('location/{location_id}/sync-sales', [\Modules\Gallface\Http\Controllers\HcmController::class, 'syncSales']);
		Route::get('location/{location_id}/download-excel', [\Modules\Gallface\Http\Controllers\HcmController::class, 'downloadExcel']);
		Route::post('location/{location_id}/upload-excel', [\Modules\Gallface\Http\Controllers\HcmController::class, 'uploadExcel']);
        // Add manual sync test route
        Route::get('/hcm/manual-sync/{location_id}', [Modules\Gallface\Http\Controllers\HcmController::class, 'manualSyncTest'])->name('hcm.manual.sync.test');
	});

	// Integra API Configuration Routes (Colombo City Center)
	Route::prefix('integra')->group(function () {
		Route::get('credentials', [\Modules\Gallface\Http\Controllers\IntegraController::class, 'credentials']);
		Route::post('save-credentials', [\Modules\Gallface\Http\Controllers\IntegraController::class, 'saveCredentials']);
		Route::get('api-logs', [\Modules\Gallface\Http\Controllers\IntegraController::class, 'getApiLogs']);
	});

	Route::get('/install', [Modules\Gallface\Http\Controllers\InstallController::class, 'index']);
    Route::post('/install', [Modules\Gallface\Http\Controllers\InstallController::class, 'install']);
    Route::get('/install/update', [Modules\Gallface\Http\Controllers\InstallController::class, 'update']);
    Route::get('/install/uninstall', [Modules\Gallface\Http\Controllers\InstallController::class, 'uninstall']);

    Route::get('/', 'GallfaceController@index');
});