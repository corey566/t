<?php

return [
    'name' => 'Gallface',
    'module_version' => '6.0',
    'pid' => 22,
    'author' => 'Yazeed Company - CodeStudio',
    'malls' => [
        'ogf' => [
            'name' => 'One Galle Face (OGF)',
            'code' => 'ogf',
            'status' => 'active',
            'has_backend' => true
        ],
        'hcm' => [
            'name' => 'Havelock City Mall (HCM)',
            'icon' => 'fas fa-building',
            'color' => 'info',
            'status' => 'active',
            'has_backend' => true,
            'description' => 'Premium shopping destination with advanced POS integration',
            'features' => [
                'Real-time sales sync',
                'Inventory management',
                'Customer data sync',
                'Automated reporting'
            ],
            'api' => [
                'base_url' => 'https://trms-api.azurewebsites.net',
                'test_credentials' => [
                    'username' => 'EXT-TEST-01',
                    'password' => 'UH2S&%z@',
                    'stall_no' => '1',
                    'pos_id' => 'EXT-TEST-01-1'
                ]
            ],
            'hcm_features' => [
                'real_time_sync' => true,
                'manual_excel_upload' => true,
                'pos_monitoring' => true,
                'gift_voucher_sales' => true,
                'hcm_gift_cards' => true,
                'customer_mobile' => true
            ]
        ],
        'ccc' => [
            'name' => 'Colombo City Center (CCC)',
            'code' => 'ccc',
            'status' => 'coming_soon',
            'has_backend' => false
        ]
    ],
    'sync_types' => [
        'manual' => 'Manual Sync',
        'realtime' => 'Real-time Sync',
        'scheduled' => 'Scheduled Sync'
    ],
    'sync_statuses' => [
        'pending' => 'Pending',
        'in_progress' => 'In Progress',
        'successful' => 'Successful',
        'failed' => 'Failed',
        'syncing' => 'Syncing'
    ]
];