<?php

namespace Modules\Gallface\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Business;
use App\BusinessLocation;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Modules\Gallface\Models\LocationApiCredential;
use Modules\Gallface\Services\HcmApiService;
use Modules\Gallface\Services\OgfApiService;
use Modules\Gallface\Services\CccApiService;
use Carbon\Carbon;

class GallfaceController extends Controller
{
    /**
     * Display main dashboard with mall selection
     * @return Renderable
     */
    public function index()
    {
        // Get or create default business for this user
        $user = auth()->user();
        $business = $this->getOrCreateBusiness($user);

        $malls = config('gallface.malls', [
            'hcm' => [
                'name' => 'Havelock City Mall',
                'code' => 'hcm',
                'icon' => 'fas fa-building',
                'color' => '#3498db'
            ],
            'ogf' => [
                'name' => 'One Galle Face',
                'code' => 'ogf',
                'icon' => 'fas fa-hotel',
                'color' => '#e74c3c'
            ],
            'ccc' => [
                'name' => 'Colombo City Centre',
                'code' => 'ccc',
                'icon' => 'fas fa-city',
                'color' => '#f39c12'
            ]
        ]);
        return view('gallface::index', compact('malls'));
    }

    /**
     * Display mall-specific dashboard
     * @param string $mall_code
     * @return Renderable
     */
    public function dashboard($mall_code = 'ogf')
    {
        // Get or create default business for this user
        $user = auth()->user();
        $business = $this->getOrCreateBusiness($user);
        $business_id = $business->id;

        $malls = config('gallface.malls', [
            'hcm' => [
                'name' => 'Havelock City Mall',
                'code' => 'hcm',
                'icon' => 'fas fa-building',
                'color' => '#3498db'
            ],
            'ogf' => [
                'name' => 'One Galle Face',
                'code' => 'ogf',
                'icon' => 'fas fa-hotel',
                'color' => '#e74c3c'
            ],
            'ccc' => [
                'name' => 'Colombo City Centre',
                'code' => 'ccc',
                'icon' => 'fas fa-city',
                'color' => '#f39c12'
            ]
        ]);

        if (!isset($malls[$mall_code])) {
            abort(404, 'Mall not found');
        }

        $current_mall = $malls[$mall_code];

        // Get business locations with their API credentials
        $business_locations = BusinessLocation::where('business_id', $business_id)
            ->with(['locationApiCredentials' => function($query) use ($mall_code) {
                $query->where('mall_code', $mall_code);
            }])
            ->get();

        // Get sync history from actual sync logs
        $sync_history = $this->getSyncHistory($business_id, $mall_code);

        // Get configured locations count
        $configured_locations = LocationApiCredential::where('business_id', $business_id)
            ->where('mall_code', $mall_code)
            ->where('is_active', true)
            ->count();

        return view('gallface::dashboard', compact(
            'malls',
            'current_mall',
            'mall_code',
            'business_locations',
            'sync_history',
            'configured_locations'
        ));
    }

    /**
     * Display mall-specific settings
     * @param string $mall_code
     * @return Renderable
     */
    public function setting(Request $request, $mall_code = 'ogf')
    {
        // Get or create default business for this user
        $user = auth()->user();
        $business = $this->getOrCreateBusiness($user);
        $business_id = $business->id;

        $malls = config('gallface.malls', [
            'hcm' => [
                'name' => 'Havelock City Mall',
                'code' => 'hcm',
                'icon' => 'fas fa-building',
                'color' => '#3498db'
            ],
            'ogf' => [
                'name' => 'One Galle Face',
                'code' => 'ogf',
                'icon' => 'fas fa-hotel',
                'color' => '#e74c3c'
            ],
            'ccc' => [
                'name' => 'Colombo City Centre',
                'code' => 'ccc',
                'icon' => 'fas fa-city',
                'color' => '#f39c12'
            ]
        ]);

        if (!isset($malls[$mall_code])) {
            abort(404, 'Mall not found');
        }

        $current_mall = $malls[$mall_code];

        // Get business locations with their API credentials
        $business_locations = BusinessLocation::where('business_id', $business_id)
            ->with(['locationApiCredentials' => function($query) use ($mall_code) {
                $query->where('mall_code', $mall_code);
            }])
            ->get();

        return view('gallface::setting', compact(
            'malls',
            'current_mall',
            'mall_code',
            'business_locations'
        ));
    }

    /**
     * Save location API credentials
     */
    public function saveLocationCredentials(Request $request, $mall_code)
    {
        // Get or create default business for this user
        $user = auth()->user();
        $business = $this->getOrCreateBusiness($user);

        $validator = Validator::make($request->all(), [
            'location_id' => 'required|integer|exists:business_locations,id',
            'api_url' => 'required|url',
            'api_key' => 'required|string',
            'client_id' => 'required|string',
            'client_secret' => 'required|string',
            'username' => 'nullable|string',
            'password' => 'nullable|string',
            'stall_no' => 'nullable|string',
            'pos_id' => 'nullable|string',
            'sync_type' => 'required|in:manual,realtime,scheduled',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $business_id = $business->id;

            $credentials = LocationApiCredential::updateOrCreate(
                [
                    'business_id' => $business_id,
                    'business_location_id' => $request->location_id,
                    'mall_code' => $mall_code
                ],
                [
                    'api_url' => $request->api_url,
                    'api_key' => $request->api_key,
                    'client_id' => $request->client_id,
                    'client_secret' => $request->client_secret,
                    'username' => $request->username,
                    'password' => $request->password,
                    'stall_no' => $request->stall_no,
                    'pos_id' => $request->pos_id,
                    'sync_type' => $request->sync_type,
                    'is_active' => true
                ]
            );

            return response()->json([
                'success' => true,
                'message' => 'API credentials saved successfully'
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to save credentials: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Test location API credentials
     */
    public function testLocationCredentials(Request $request, $mall_code, $location_id)
    {
        try {
            // Get or create default business for this user
            $user = auth()->user();
            $business = $this->getOrCreateBusiness($user);
            $business_id = $business->id;

            $credentials = LocationApiCredential::where('business_id', $business_id)
                ->where('business_location_id', $location_id)
                ->where('mall_code', $mall_code)
                ->first();

            if (!$credentials) {
                return response()->json([
                    'success' => false,
                    'message' => 'No API credentials found for this location'
                ]);
            }

            if (!$credentials->hasCompleteCredentials()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Incomplete API credentials'
                ]);
            }

            // Use isolated API services for each mall
            switch ($mall_code) {
                case 'hcm':
                    $apiService = new HcmApiService($credentials->getCredentialsForApi());
                    return response()->json($apiService->testConnection());

                case 'ogf':
                    $apiService = new OgfApiService($credentials->getCredentialsForApi());
                    return response()->json($apiService->testConnection());

                case 'ccc':
                    $apiService = new CccApiService($credentials->getCredentialsForApi());
                    return response()->json($apiService->testConnection());

                default:
                    return response()->json([
                        'success' => false,
                        'message' => 'Unknown mall code: ' . $mall_code
                    ]);
            }

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Connection test failed: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Sync sales for specific location with comprehensive data
     */
    public function syncLocationSales(Request $request, $mall_code, $location_id)
    {
        try {
            // Get or create default business for this user
            $user = auth()->user();
            $business = $this->getOrCreateBusiness($user);
            $business_id = $business->id;

            $credentials = LocationApiCredential::where('business_id', $business_id)
                ->where('business_location_id', $location_id)
                ->where('mall_code', $mall_code)
                ->where('is_active', true)
                ->first();

            if (!$credentials) {
                return response()->json([
                    'success' => false,
                    'message' => 'No active API credentials found for this location'
                ]);
            }

            // Create sync log entry
            $syncLog = $this->createSyncLog($business_id, $location_id, $mall_code, 'manual', 'in_progress');

            // Get comprehensive sales data
            $salesData = $this->getComprehensiveSalesData($business_id, $location_id);

            // Use isolated API services for each mall
            switch ($mall_code) {
                case 'hcm':
                    $apiService = new HcmApiService($credentials->getCredentialsForApi());
                    $result = $apiService->syncSales($salesData, $location_id);
                    break;

                case 'ogf':
                    $apiService = new OgfApiService($credentials->getCredentialsForApi());
                    $result = $apiService->syncSales($salesData, $location_id);
                    break;

                case 'ccc':
                    $apiService = new CccApiService($credentials->getCredentialsForApi());
                    $result = $apiService->syncSales($salesData, $location_id);
                    break;

                default:
                    $result = [
                        'success' => false,
                        'message' => 'Unknown mall code: ' . $mall_code,
                        'records_synced' => 0
                    ];
            }

            // Update sync log
            $this->updateSyncLog($syncLog, $result);

            if ($result['success']) {
                $credentials->update(['last_synced_at' => now()]);
            }

            return response()->json($result);

        } catch (\Exception $e) {
            // Update sync log with error
            if (isset($syncLog)) {
                $this->updateSyncLog($syncLog, [
                    'success' => false,
                    'message' => $e->getMessage(),
                    'records_synced' => 0
                ]);
            }

            return response()->json([
                'success' => false,
                'message' => 'Sync failed: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Get comprehensive sales data with all transaction types
     */
    private function getComprehensiveSalesData($business_id, $location_id)
    {
        // Get transactions from the last 7 days
        $dateFrom = Carbon::now()->subDays(7)->startOfDay();
        $dateTo = Carbon::now()->endOfDay();

        // Check if we have the transactions table (this is a fallback implementation)
        if (!Schema::hasTable('transactions')) {
            return $this->getMockSalesData();
        }

        try {
            $sales = DB::table('transactions as t')
                ->leftJoin('contacts as c', 't.contact_id', '=', 'c.id')
                ->leftJoin('transaction_payments as tp', 't.id', '=', 'tp.transaction_id')
                ->leftJoin('transaction_sell_lines as tsl', 't.id', '=', 'tsl.transaction_id')
                ->leftJoin('products as p', 'tsl.product_id', '=', 'p.id')
                ->leftJoin('variations as v', 'tsl.variation_id', '=', 'v.id')
                ->where('t.business_id', $business_id)
                ->where('t.location_id', $location_id)
                ->where('t.type', 'sell')
                ->whereBetween('t.transaction_date', [$dateFrom, $dateTo])
                ->select(
                    't.id',
                    't.invoice_no',
                    't.transaction_date',
                    't.final_total',
                    't.tax_amount',
                    't.discount_amount',
                    't.payment_status',
                    't.status',
                    't.sub_type',
                    't.rp_redeemed',
                    't.rp_redeemed_amount',
                    'c.id as customer_id',
                    'c.mobile as loyalty_mobile',
                    DB::raw('GROUP_CONCAT(DISTINCT tp.method) as payment_methods'),
                    DB::raw('GROUP_CONCAT(DISTINCT tp.amount) as payment_amounts'),
                    DB::raw('COUNT(DISTINCT tsl.id) as line_count')
                )
                ->groupBy('t.id')
                ->get();

            $salesData = [];

            foreach ($sales as $sale) {
                // Get detailed sell lines for this transaction
                $sellLines = $this->getSellLines($sale->id);

                // Get payment details
                $payments = $this->getPaymentDetails($sale->id);

                $salesData[] = [
                    'invoice_no' => $sale->invoice_no,
                    'transaction_date' => $sale->transaction_date,
                    'customer_id' => $sale->customer_id,
                    'loyalty_mobile' => $sale->loyalty_mobile,
                    'final_total' => $sale->final_total,
                    'tax_amount' => $sale->tax_amount ?? 0,
                    'discount_amount' => $sale->discount_amount ?? 0,
                    'payment_status' => $sale->payment_status,
                    'is_return' => $sale->sub_type === 'return',
                    'is_exchange' => $sale->sub_type === 'exchange',
                    'is_refund' => $sale->status === 'refunded',
                    'is_void' => $sale->status === 'void',
                    'hcm_voucher_redemption' => $sale->rp_redeemed_amount ?? 0,
                    'gift_voucher_sale' => 0, // This would need custom field implementation
                    'gift_voucher_redemption' => 0, // This would need custom field implementation
                    'sell_lines' => $sellLines,
                    'payments' => $payments
                ];
            }

            return $salesData;

        } catch (\Exception $e) {
            Log::error('Failed to get sales data from database', [
                'error' => $e->getMessage(),
                'business_id' => $business_id,
                'location_id' => $location_id
            ]);

            return $this->getMockSalesData();
        }
    }

    /**
     * Get sell lines for a transaction
     */
    private function getSellLines($transaction_id)
    {
        try {
            return DB::table('transaction_sell_lines as tsl')
                ->leftJoin('products as p', 'tsl.product_id', '=', 'p.id')
                ->leftJoin('variations as v', 'tsl.variation_id', '=', 'v.id')
                ->where('tsl.transaction_id', $transaction_id)
                ->select(
                    'tsl.product_id',
                    'tsl.variation_id',
                    'tsl.quantity',
                    'tsl.unit_price_before_discount',
                    'tsl.unit_price_inc_tax',
                    'tsl.line_discount_amount',
                    'tsl.item_tax',
                    'p.sku',
                    'p.name as product_name'
                )
                ->get()
                ->map(function ($line) {
                    return [
                        'product_id' => $line->product_id,
                        'variation_id' => $line->variation_id,
                        'quantity' => $line->quantity,
                        'unit_price_before_discount' => $line->unit_price_before_discount,
                        'unit_price_inc_tax' => $line->unit_price_inc_tax,
                        'line_discount_amount' => $line->line_discount_amount ?? 0,
                        'item_tax' => $line->item_tax ?? 0,
                        'product' => [
                            'sku' => $line->sku,
                            'name' => $line->product_name
                        ]
                    ];
                })
                ->toArray();
        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * Get payment details for a transaction
     */
    private function getPaymentDetails($transaction_id)
    {
        try {
            return DB::table('transaction_payments')
                ->where('transaction_id', $transaction_id)
                ->select('method', 'amount', 'transaction_no', 'card_number', 'card_type')
                ->get()
                ->toArray();
        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * Get mock sales data for testing/fallback
     */
    private function getMockSalesData()
    {
        return [
            [
                'invoice_no' => 'INV-' . date('Ymd') . '-001',
                'transaction_date' => now()->toDateTimeString(),
                'customer_id' => null,
                'loyalty_mobile' => '+94771234567',
                'final_total' => 1500.00,
                'tax_amount' => 150.00,
                'discount_amount' => 50.00,
                'payment_status' => 'paid',
                'is_return' => false,
                'is_exchange' => false,
                'is_refund' => false,
                'is_void' => false,
                'hcm_voucher_redemption' => 0,
                'gift_voucher_sale' => 0,
                'gift_voucher_redemption' => 0,
                'sell_lines' => [
                    [
                        'product_id' => 1,
                        'variation_id' => 1,
                        'quantity' => 2,
                        'unit_price_before_discount' => 700.00,
                        'unit_price_inc_tax' => 750.00,
                        'line_discount_amount' => 50.00,
                        'item_tax' => 75.00,
                        'product' => [
                            'sku' => 'PROD-001',
                            'name' => 'Sample Product'
                        ]
                    ]
                ],
                'payments' => [
                    [
                        'method' => 'card',
                        'amount' => 1500.00,
                        'transaction_no' => 'TXN123456',
                        'card_number' => '**** **** **** 1234',
                        'card_type' => 'visa'
                    ]
                ]
            ]
        ];
    }

    /**
     * Create sync log entry
     */
    private function createSyncLog($business_id, $location_id, $mall_code, $sync_type, $status)
    {
        return DB::table('gallface_sync_logs')->insertGetId([
            'business_id' => $business_id,
            'business_location_id' => $location_id,
            'mall_code' => $mall_code,
            'sync_type' => $sync_type,
            'status' => $status,
            'entity_type' => 'sales',
            'started_at' => now(),
            'created_by' => auth()->id() ?? 1,
            'created_at' => now(),
            'updated_at' => now()
        ]);
    }

    /**
     * Update sync log entry
     */
    private function updateSyncLog($syncLogId, $result)
    {
        DB::table('gallface_sync_logs')
            ->where('id', $syncLogId)
            ->update([
                'status' => $result['success'] ? 'successful' : 'failed',
                'records_synced' => $result['records_synced'] ?? 0,
                'response_data' => json_encode($result['response_data'] ?? []),
                'error_message' => $result['success'] ? null : $result['message'],
                'completed_at' => now(),
                'updated_at' => now()
            ]);
    }

    /**
     * Get sync history from database
     */
    private function getSyncHistory($business_id, $mall_code, $limit = 10)
    {
        try {
            return DB::table('gallface_sync_logs as gsl')
                ->leftJoin('business_locations as bl', 'gsl.business_location_id', '=', 'bl.id')
                ->where('gsl.business_id', $business_id)
                ->where('gsl.mall_code', $mall_code)
                ->select(
                    'gsl.id',
                    'gsl.sync_type',
                    'gsl.status',
                    'gsl.records_synced',
                    'gsl.error_message',
                    'gsl.created_at',
                    'bl.name as location_name'
                )
                ->orderBy('gsl.created_at', 'desc')
                ->limit($limit)
                ->get()
                ->toArray();
        } catch (\Exception $e) {
            // Return mock data if table doesn't exist yet
            return [];
        }
    }

    /**
     * Get or create default business for the user
     */
    private function getOrCreateBusiness($user)
    {
        // Check if business exists for this user
        $business = Business::where('owner_id', $user->id)->first();

        if (!$business) {
            // Create default business for this user
            $business = Business::create([
                'name' => $user->name . "'s Business",
                'owner_id' => $user->id,
                'currency_id' => 1,
                'start_date' => now(),
                'fy_start_month' => 1,
                'accounting_method' => 'fifo',
                'is_active' => true
            ]);

            // Create default location
            BusinessLocation::create([
                'business_id' => $business->id,
                'location_id' => 'LOC-001',
                'name' => 'Main Location',
                'country' => 'Sri Lanka',
                'state' => 'Western',
                'city' => 'Colombo',
                'zip_code' => '00100',
                'invoice_scheme_id' => 1,
                'invoice_layout_id' => 1,
                'is_active' => true
            ]);
        }

        return $business;
    }
}