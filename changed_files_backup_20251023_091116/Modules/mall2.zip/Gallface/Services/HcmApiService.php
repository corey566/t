

<?php

namespace Modules\Gallface\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class HcmApiService
{
    private $credentials;
    private $baseUrl;
    private $testCredentials;
    
    public function __construct(array $credentials)
    {
        $this->credentials = $credentials;
        $this->baseUrl = rtrim($credentials['api_url'] ?? 'https://trms-api.azurewebsites.net', '/');
        
        // Use credentials from form
        $this->testCredentials = [
            'username' => $credentials['username'] ?? 'EXT-TEST-01',
            'password' => $credentials['password'] ?? 'UH2S&%z@',
            'stall_no' => $credentials['stall_no'] ?? '1',
            'pos_id' => $credentials['pos_id'] ?? 'EXT-TEST-01-1'
        ];
    }
    
    /**
     * Test API connection with ping endpoint
     */
    public function testConnection(): array
    {
        try {
            $response = Http::withBasicAuth(
                $this->testCredentials['username'], 
                $this->testCredentials['password']
            )->timeout(30)->post($this->baseUrl . '/api/ping', [
                'pos_id' => $this->testCredentials['pos_id'],
                'stall_no' => $this->testCredentials['stall_no'],
                'timestamp' => now()->toISOString()
            ]);
            
            if ($response->successful()) {
                return [
                    'success' => true,
                    'message' => 'HCM API connection successful - POS is active',
                    'response' => $response->json()
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'HCM API connection failed: ' . $response->body(),
                    'status_code' => $response->status()
                ];
            }
        } catch (\Exception $e) {
            Log::error('HCM API connection test failed', [
                'error' => $e->getMessage(),
                'base_url' => $this->baseUrl
            ]);
            
            return [
                'success' => false,
                'message' => 'Connection failed: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Send POS ping to monitor active status
     */
    public function sendPosPing(int $locationId): array
    {
        try {
            $response = Http::withBasicAuth(
                $this->testCredentials['username'], 
                $this->testCredentials['password']
            )->timeout(30)->post($this->baseUrl . '/api/ping', [
                'pos_id' => $this->testCredentials['pos_id'],
                'stall_no' => $this->testCredentials['stall_no'],
                'location_id' => $locationId,
                'timestamp' => now()->toISOString(),
                'status' => 'active'
            ]);
            
            if ($response->successful()) {
                return [
                    'success' => true,
                    'message' => 'POS ping sent successfully',
                    'response' => $response->json()
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'POS ping failed: ' . $response->body()
                ];
            }
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => 'POS ping failed: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Sync sales data to HCM in real-time
     */
    public function syncSales(array $salesData, int $locationId): array
    {
        try {
            // Prepare payload according to HCM API requirements
            $payload = [
                'pos_id' => $this->testCredentials['pos_id'],
                'stall_no' => $this->testCredentials['stall_no'],
                'location_id' => $locationId,
                'sync_timestamp' => now()->toISOString(),
                'transactions' => $this->prepareSalesData($salesData)
            ];
            
            Log::info('HCM Sales Sync Payload', $payload);
            
            $response = Http::withBasicAuth(
                $this->testCredentials['username'], 
                $this->testCredentials['password']
            )->timeout(120)->post($this->baseUrl . '/api/sales', $payload);
            
            if ($response->successful()) {
                $result = $response->json();
                return [
                    'success' => true,
                    'message' => 'Sales data synced successfully to HCM',
                    'records_synced' => $result['records_processed'] ?? count($salesData),
                    'response_data' => $result
                ];
            } else {
                Log::error('HCM Sales Sync Failed', [
                    'status' => $response->status(),
                    'body' => $response->body(),
                    'payload' => $payload
                ]);
                
                return [
                    'success' => false,
                    'message' => 'HCM sync failed: ' . $response->body(),
                    'records_synced' => 0
                ];
            }
        } catch (\Exception $e) {
            Log::error('HCM sales sync exception', [
                'error' => $e->getMessage(),
                'location_id' => $locationId,
                'sales_count' => count($salesData)
            ]);
            
            return [
                'success' => false,
                'message' => 'Sync failed: ' . $e->getMessage(),
                'records_synced' => 0
            ];
        }
    }
    
    /**
     * Prepare sales data according to HCM API requirements
     */
    private function prepareSalesData(array $salesData): array
    {
        $prepared = [];
        
        foreach ($salesData as $sale) {
            $transactionData = [
                'invoiceNo' => $sale['invoice_no'],
                'transactionDate' => Carbon::parse($sale['transaction_date'])->format('Y-m-d H:i:s'),
                'transactionType' => $this->determineTransactionType($sale),
                'paymentMethod' => $this->determinePaymentMethod($sale),
                'totalAmount' => (float)$sale['final_total'],
                'taxAmount' => (float)($sale['tax_amount'] ?? 0),
                'discountAmount' => (float)($sale['discount_amount'] ?? 0),
                'customerId' => $sale['customer_id'] ?? null,
                'customerMobile' => $sale['loyalty_mobile'] ?? null,
                'hcmLoyalty' => (float)($sale['hcm_voucher_redemption'] ?? 0),
                'totalGiftVoucherSale' => (float)($sale['gift_voucher_sale'] ?? 0),
                'giftVoucherRedemption' => (float)($sale['gift_voucher_redemption'] ?? 0),
                'items' => $this->prepareSaleLines($sale['sell_lines'] ?? []),
                'payments' => $this->preparePaymentData($sale['payments'] ?? [])
            ];
            
            $prepared[] = $transactionData;
        }
        
        return $prepared;
    }
    
    /**
     * Determine transaction type for HCM
     */
    private function determineTransactionType($sale): string
    {
        if (isset($sale['is_return']) && $sale['is_return']) {
            return 'RETURN';
        }
        
        if (isset($sale['is_exchange']) && $sale['is_exchange']) {
            return 'EXCHANGE';
        }
        
        if (isset($sale['is_refund']) && $sale['is_refund']) {
            return 'REFUND';
        }
        
        if (isset($sale['is_void']) && $sale['is_void']) {
            return 'VOID';
        }
        
        return 'SALE';
    }
    
    /**
     * Determine payment method for HCM
     */
    private function determinePaymentMethod($sale): string
    {
        $payments = $sale['payments'] ?? [];
        
        if (empty($payments)) {
            return 'CASH';
        }
        
        $hasCard = false;
        $hasCash = false;
        $hasHcmGiftCard = false;
        
        foreach ($payments as $payment) {
            if (in_array($payment['method'], ['card', 'credit_card', 'debit_card'])) {
                $hasCard = true;
            } elseif ($payment['method'] === 'cash') {
                $hasCash = true;
            } elseif ($payment['method'] === 'hcm_gift_card') {
                $hasHcmGiftCard = true;
            }
        }
        
        if (($hasCard && $hasCash) || ($hasCard && $hasHcmGiftCard) || ($hasCash && $hasHcmGiftCard)) {
            return 'MIXED';
        } elseif ($hasCard) {
            return 'CARD';
        } elseif ($hasHcmGiftCard) {
            return 'HCM_GIFT_CARD';
        } else {
            return 'CASH';
        }
    }
    
    /**
     * Prepare sale line items
     */
    private function prepareSaleLines(array $lines): array
    {
        $prepared = [];
        
        foreach ($lines as $line) {
            $prepared[] = [
                'productId' => $line['product_id'],
                'sku' => $line['product']['sku'] ?? '',
                'productName' => $line['product']['name'] ?? '',
                'quantity' => (float)$line['quantity'],
                'unitPrice' => (float)$line['unit_price_before_discount'],
                'unitPriceIncTax' => (float)$line['unit_price_inc_tax'],
                'lineDiscount' => (float)($line['line_discount_amount'] ?? 0),
                'itemTax' => (float)($line['item_tax'] ?? 0),
                'lineTotal' => (float)($line['quantity'] * $line['unit_price_inc_tax'])
            ];
        }
        
        return $prepared;
    }
    
    /**
     * Prepare payment data
     */
    private function preparePaymentData(array $payments): array
    {
        $prepared = [];
        
        foreach ($payments as $payment) {
            $prepared[] = [
                'method' => $payment['method'],
                'amount' => (float)$payment['amount'],
                'transactionNo' => $payment['transaction_no'] ?? null,
                'cardNumber' => $payment['card_number'] ?? null,
                'cardType' => $payment['card_type'] ?? null,
                'hcmGiftCardNo' => $payment['hcm_gift_card_no'] ?? null
            ];
        }
        
        return $prepared;
    }
    
    /**
     * Upload Excel data for day-end/month-end reporting
     */
    public function uploadExcelData(array $excelData, int $locationId, string $reportType = 'day_end'): array
    {
        try {
            $payload = [
                'pos_id' => $this->testCredentials['pos_id'],
                'stall_no' => $this->testCredentials['stall_no'],
                'location_id' => $locationId,
                'report_type' => $reportType,
                'upload_timestamp' => now()->toISOString(),
                'data' => $excelData
            ];
            
            $response = Http::withBasicAuth(
                $this->testCredentials['username'], 
                $this->testCredentials['password']
            )->timeout(180)->post($this->baseUrl . '/api/excel-upload', $payload);
            
            if ($response->successful()) {
                return [
                    'success' => true,
                    'message' => 'Excel data uploaded successfully',
                    'response' => $response->json()
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Excel upload failed: ' . $response->body()
                ];
            }
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => 'Excel upload failed: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Generate day-end Excel report
     */
    public function generateDayEndReport(int $locationId, string $date): array
    {
        try {
            $response = Http::withBasicAuth(
                $this->testCredentials['username'], 
                $this->testCredentials['password']
            )->timeout(120)->get($this->baseUrl . '/api/reports/day-end', [
                'pos_id' => $this->testCredentials['pos_id'],
                'stall_no' => $this->testCredentials['stall_no'],
                'location_id' => $locationId,
                'date' => $date
            ]);
            
            if ($response->successful()) {
                return [
                    'success' => true,
                    'data' => $response->json(),
                    'download_url' => $response->json()['download_url'] ?? null
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Day-end report generation failed: ' . $response->body()
                ];
            }
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => 'Day-end report failed: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Create sample invoice data for testing
     */
    public function createSampleInvoice(): array
    {
        return [
            'invoice_no' => 'HCM-TEST-' . date('YmdHis'),
            'transaction_date' => now()->toDateTimeString(),
            'customer_id' => null,
            'loyalty_mobile' => '+94771234567',
            'final_total' => 2500.00,
            'tax_amount' => 325.00,
            'discount_amount' => 100.00,
            'payment_status' => 'paid',
            'is_return' => false,
            'is_exchange' => false,
            'is_refund' => false,
            'is_void' => false,
            'hcm_voucher_redemption' => 500.00,
            'gift_voucher_sale' => 1000.00,
            'gift_voucher_redemption' => 0,
            'sell_lines' => [
                [
                    'product_id' => 1,
                    'variation_id' => 1,
                    'quantity' => 2,
                    'unit_price_before_discount' => 1200.00,
                    'unit_price_inc_tax' => 1300.00,
                    'line_discount_amount' => 100.00,
                    'item_tax' => 162.50,
                    'product' => [
                        'sku' => 'HCM-PROD-001',
                        'name' => 'Sample Product for HCM'
                    ]
                ],
                [
                    'product_id' => 2,
                    'variation_id' => 2,
                    'quantity' => 1,
                    'unit_price_before_discount' => 1000.00,
                    'unit_price_inc_tax' => 1200.00,
                    'line_discount_amount' => 0,
                    'item_tax' => 162.50,
                    'product' => [
                        'sku' => 'HCM-GIFT-VOUCHER',
                        'name' => 'HCM Gift Voucher'
                    ]
                ]
            ],
            'payments' => [
                [
                    'method' => 'card',
                    'amount' => 1500.00,
                    'transaction_no' => 'TXN' . time(),
                    'card_number' => '**** **** **** 1234',
                    'card_type' => 'visa'
                ],
                [
                    'method' => 'hcm_gift_card',
                    'amount' => 500.00,
                    'transaction_no' => 'HCM' . time(),
                    'hcm_gift_card_no' => 'HCM-GC-12345'
                ],
                [
                    'method' => 'cash',
                    'amount' => 500.00,
                    'transaction_no' => null
                ]
            ]
        ];
    }
}

