
<?php

namespace Modules\Gallface\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class OgfApiService
{
    private $credentials;
    private $baseUrl;
    
    public function __construct(array $credentials)
    {
        $this->credentials = $credentials;
        $this->baseUrl = rtrim($credentials['api_url'], '/');
    }
    
    /**
     * Test API connection for OGF
     */
    public function testConnection(): array
    {
        try {
            $response = Http::withHeaders([
                'X-API-Key' => $this->credentials['api_key'],
                'X-Client-ID' => $this->credentials['client_id'],
                'Content-Type' => 'application/json',
                'Accept' => 'application/json'
            ])->timeout(30)->get($this->baseUrl . '/api/v1/health');
            
            if ($response->successful()) {
                return [
                    'success' => true,
                    'message' => 'OGF API connection successful'
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'OGF API connection failed: ' . $response->body()
                ];
            }
        } catch (\Exception $e) {
            Log::error('OGF API connection test failed', [
                'error' => $e->getMessage(),
                'credentials' => array_keys($this->credentials)
            ]);
            
            return [
                'success' => false,
                'message' => 'Connection failed: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Sync sales data to OGF
     */
    public function syncSales(array $salesData, int $locationId): array
    {
        try {
            $payload = [
                'tenant_id' => $this->credentials['client_id'],
                'location_id' => $locationId,
                'transactions' => $salesData,
                'timestamp' => now()->toISOString()
            ];
            
            $response = Http::withHeaders([
                'X-API-Key' => $this->credentials['api_key'],
                'X-Client-ID' => $this->credentials['client_id'],
                'Content-Type' => 'application/json',
                'Accept' => 'application/json'
            ])->timeout(60)->post($this->baseUrl . '/api/v1/sales/sync', $payload);
            
            if ($response->successful()) {
                $result = $response->json();
                return [
                    'success' => true,
                    'message' => 'Sales data synced successfully to OGF',
                    'records_synced' => $result['processed_count'] ?? count($salesData),
                    'response_data' => $result
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'OGF sync failed: ' . $response->body(),
                    'records_synced' => 0
                ];
            }
        } catch (\Exception $e) {
            Log::error('OGF sales sync failed', [
                'error' => $e->getMessage(),
                'location_id' => $locationId,
                'sales_count' => count($salesData)
            ]);
            
            return [
                'success' => false,
                'message' => 'Sync failed: ' . $e->getMessage(),
                'records_synced' => 0
            ];
        }
    }
}
