
<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddStallPosFields extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('gallface_location_api_credentials', function (Blueprint $table) {
            $table->string('stall_no')->nullable()->after('password');
            $table->string('pos_id')->nullable()->after('stall_no');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('gallface_location_api_credentials', function (Blueprint $table) {
            $table->dropColumn(['stall_no', 'pos_id']);
        });
    }
}
