
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('gallface_sync_logs', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('business_id');
            $table->unsignedInteger('business_location_id');
            $table->string('mall_code');
            $table->enum('sync_type', ['manual', 'realtime', 'scheduled'])->default('manual');
            $table->enum('status', ['pending', 'in_progress', 'successful', 'failed', 'syncing']);
            $table->string('entity_type')->default('sales'); // sales, loyalty, reports
            $table->unsignedInteger('entity_id')->nullable();
            $table->json('request_data')->nullable();
            $table->json('response_data')->nullable();
            $table->text('error_message')->nullable();
            $table->integer('records_synced')->default(0);
            $table->timestamp('started_at')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->unsignedInteger('created_by');
            $table->timestamps();
            
            $table->foreign('business_id')->references('id')->on('business')->onDelete('cascade');
            $table->foreign('business_location_id')->references('id')->on('business_locations')->onDelete('cascade');
            $table->index(['business_id', 'mall_code']);
            $table->index(['business_location_id', 'status']);
            $table->index(['created_at']);
        });
    }

    public function down()
    {
        Schema::dropIfExists('gallface_sync_logs');
    }
};
