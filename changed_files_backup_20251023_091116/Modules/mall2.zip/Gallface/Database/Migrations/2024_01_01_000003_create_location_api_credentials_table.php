
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('gallface_location_api_credentials', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('business_id');
            $table->unsignedInteger('business_location_id');
            $table->string('mall_code');
            $table->string('api_url');
            $table->string('api_key');
            $table->string('client_id');
            $table->string('client_secret');
            $table->string('username')->nullable();
            $table->string('password')->nullable();
            $table->enum('sync_type', ['manual', 'realtime', 'scheduled'])->default('manual');
            $table->boolean('is_active')->default(true);
            $table->json('additional_settings')->nullable();
            $table->timestamp('last_synced_at')->nullable();
            $table->timestamps();
            
            $table->foreign('business_id')->references('id')->on('business')->onDelete('cascade');
            $table->foreign('business_location_id')->references('id')->on('business_locations')->onDelete('cascade');
            $table->unique(['business_location_id', 'mall_code'], 'unique_location_mall_credentials');
            $table->index(['business_id', 'mall_code']);
        });
    }

    public function down()
    {
        Schema::dropIfExists('gallface_location_api_credentials');
    }
};
