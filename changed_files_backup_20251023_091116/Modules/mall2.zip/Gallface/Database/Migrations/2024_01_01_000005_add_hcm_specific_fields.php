
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        // Add HCM-specific fields to location API credentials
        if (Schema::hasTable('gallface_location_api_credentials')) {
            Schema::table('gallface_location_api_credentials', function (Blueprint $table) {
                if (!Schema::hasColumn('gallface_location_api_credentials', 'sync_features')) {
                    $table->json('sync_features')->nullable()->comment('Enabled sync features like loyalty, vouchers, etc.');
                }
                if (!Schema::hasColumn('gallface_location_api_credentials', 'last_error')) {
                    $table->text('last_error')->nullable()->comment('Last sync error message');
                }
                if (!Schema::hasColumn('gallface_location_api_credentials', 'sync_frequency')) {
                    $table->integer('sync_frequency')->default(60)->comment('Sync frequency in minutes');
                }
            });
        }
        
        // Create transaction extensions table for HCM-specific data
        if (!Schema::hasTable('gallface_transaction_extensions')) {
            Schema::create('gallface_transaction_extensions', function (Blueprint $table) {
                $table->id();
                $table->unsignedInteger('business_id');
                $table->unsignedInteger('transaction_id')->nullable();
                $table->string('invoice_no')->index();
                $table->string('mall_code');
                $table->decimal('hcm_voucher_redemption', 22, 4)->default(0);
                $table->decimal('gift_voucher_sale', 22, 4)->default(0);
                $table->decimal('gift_voucher_redemption', 22, 4)->default(0);
                $table->string('loyalty_mobile')->nullable();
                $table->json('payment_breakdown')->nullable();
                $table->enum('transaction_source', ['pos', 'manual', 'api'])->default('pos');
                $table->timestamp('hcm_synced_at')->nullable();
                $table->json('hcm_sync_response')->nullable();
                $table->timestamps();
                
                $table->foreign('business_id')->references('id')->on('business')->onDelete('cascade');
                $table->index(['business_id', 'mall_code']);
                $table->index(['invoice_no', 'mall_code']);
                $table->index(['hcm_synced_at']);
            });
        }
    }

    public function down()
    {
        if (Schema::hasTable('gallface_location_api_credentials')) {
            Schema::table('gallface_location_api_credentials', function (Blueprint $table) {
                $table->dropColumn(['sync_features', 'last_error', 'sync_frequency']);
            });
        }
        
        Schema::dropIfExists('gallface_transaction_extensions');
    }
};
