@extends('gallface::layouts.master')

@section('title', 'Mall Integration Settings - ' . $current_mall['name'])

@section('content')
<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">
                        <i class="{{ $current_mall['icon'] }} tw-mr-2 tw-text-blue-600"></i>
                        {{ $current_mall['name'] }} Settings
                    </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{ url('/') }}">Home</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('gallface.dashboard', $mall_code) }}">{{ $current_mall['name'] }}</a></li>
                        <li class="breadcrumb-item active">Settings</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <section class="content">
        <div class="container-fluid">
            @if(session('success'))
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle tw-mr-2"></i>
                    {{ session('success') }}
                    <button type="button" class="close" data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                </div>
            @endif

            @if(session('error'))
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-circle tw-mr-2"></i>
                    {{ session('error') }}
                    <button type="button" class="close" data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                </div>
            @endif

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-map-marker-alt tw-mr-2"></i>
                                Location API Credentials
                            </h3>
                            <div class="card-tools">
                                <span class="badge badge-info">One credential set per location</span>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                @foreach($business_locations as $location)
                                    @php
                                        $credentials = $location->getCredentialsForMall($mall_code);
                                        $hasCredentials = $credentials && $credentials->hasCompleteCredentials();
                                    @endphp
                                    <div class="col-md-6 col-lg-4 mb-4">
                                    <div class="card tw-shadow-md tw-rounded-lg {{ $hasCredentials ? 'tw-border-green-200 tw-bg-green-50' : 'tw-border-yellow-200 tw-bg-yellow-50' }} tw-border-2">
                                        <div class="card-header tw-bg-white tw-border-b-2 {{ $hasCredentials ? 'tw-border-green-200' : 'tw-border-yellow-200' }} d-flex justify-content-between align-items-center">
                                            <h5 class="card-title mb-0 tw-font-semibold tw-text-gray-800">
                                                <i class="fas fa-store tw-mr-2 tw-text-blue-500"></i>
                                                {{ $location->name }}
                                            </h5>
                                            <div class="d-flex align-items-center tw-space-x-2">
                                                @if($hasCredentials)
                                                    <span class="badge badge-success tw-bg-green-500 tw-text-white tw-px-3 tw-py-1 tw-rounded-full">
                                                        <i class="fas fa-check tw-mr-1"></i>
                                                        Configured
                                                    </span>
                                                    <button type="button" 
                                                            class="btn btn-sm btn-outline-primary test-connection-btn tw-ml-2"
                                                            data-location-id="{{ $location->id }}"
                                                            data-location-name="{{ $location->name }}">
                                                        <i class="fas fa-plug tw-mr-1"></i>
                                                        Test
                                                    </button>
                                                @else
                                                    <span class="badge badge-warning tw-bg-yellow-500 tw-text-white tw-px-3 tw-py-1 tw-rounded-full">
                                                        <i class="fas fa-exclamation-triangle tw-mr-1"></i>
                                                        Not Configured
                                                    </span>
                                                @endif
                                            </div>
                                        </div>
                                            <div class="card-body">
                                                <form class="location-credentials-form" data-location-id="{{ $location->id }}">
                                                    <div class="form-group">
                                                        <label class="form-label">
                                                            <i class="fas fa-link tw-mr-1"></i>
                                                            API URL
                                                        </label>
                                                        <input type="url" 
                                                               class="form-control form-control-sm" 
                                                               name="api_url" 
                                                               value="{{ $credentials->api_url ?? '' }}"
                                                               placeholder="https://api.example.com">
                                                    </div>

                                                    <div class="form-group">
                                                        <label class="form-label">
                                                            <i class="fas fa-key tw-mr-1"></i>
                                                            API Key
                                                        </label>
                                                        <input type="text" 
                                                               class="form-control form-control-sm" 
                                                               name="api_key" 
                                                               value="{{ $credentials ? '••••••••' : '' }}"
                                                               placeholder="Your API Key">
                                                    </div>

                                                    <div class="row">
                                                        <div class="col-6">
                                                            <div class="form-group">
                                                                <label class="form-label">
                                                                    <i class="fas fa-user tw-mr-1"></i>
                                                                    Client ID
                                                                </label>
                                                                <input type="text" 
                                                                       class="form-control form-control-sm" 
                                                                       name="client_id" 
                                                                       value="{{ $credentials->client_id ?? '' }}"
                                                                       placeholder="Client ID">
                                                            </div>
                                                        </div>
                                                        <div class="col-6">
                                                            <div class="form-group">
                                                                <label class="form-label">
                                                                    <i class="fas fa-lock tw-mr-1"></i>
                                                                    Client Secret
                                                                </label>
                                                                <input type="password" 
                                                                       class="form-control form-control-sm" 
                                                                       name="client_secret" 
                                                                       value="{{ $credentials ? '••••••••' : '' }}"
                                                                       placeholder="Client Secret">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="row">
                                                        <div class="col-6">
                                                            <div class="form-group">
                                                                <label class="form-label">Username</label>
                                                                <input type="text" 
                                                                       class="form-control form-control-sm" 
                                                                       name="username" 
                                                                       value="{{ $credentials->username ?? '' }}"
                                                                       placeholder="EXT-TEST-01">
                                                            </div>
                                                        </div>
                                                        <div class="col-6">
                                                            <div class="form-group">
                                                                <label class="form-label">Password</label>
                                                                <input type="password" 
                                                                       class="form-control form-control-sm" 
                                                                       name="password" 
                                                                       value="{{ $credentials ? '••••••••' : '' }}"
                                                                       placeholder="Password">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="row">
                                                        <div class="col-6">
                                                            <div class="form-group">
                                                                <label class="form-label">
                                                                    <i class="fas fa-store tw-mr-1"></i>
                                                                    Stall No
                                                                </label>
                                                                <input type="text" 
                                                                       class="form-control form-control-sm" 
                                                                       name="stall_no" 
                                                                       value="{{ $credentials->stall_no ?? '' }}"
                                                                       placeholder="1">
                                                            </div>
                                                        </div>
                                                        <div class="col-6">
                                                            <div class="form-group">
                                                                <label class="form-label">
                                                                    <i class="fas fa-cash-register tw-mr-1"></i>
                                                                    POS ID
                                                                </label>
                                                                <input type="text" 
                                                                       class="form-control form-control-sm" 
                                                                       name="pos_id" 
                                                                       value="{{ $credentials->pos_id ?? '' }}"
                                                                       placeholder="EXT-TEST-01-1">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <label class="form-label">
                                                            <i class="fas fa-sync tw-mr-1"></i>
                                                            Sync Type
                                                        </label>
                                                        <select class="form-control form-control-sm" name="sync_type">
                                                            <option value="manual" {{ ($credentials->sync_type ?? 'manual') == 'manual' ? 'selected' : '' }}>
                                                                Manual Sync
                                                            </option>
                                                            <option value="realtime" {{ ($credentials->sync_type ?? '') == 'realtime' ? 'selected' : '' }}>
                                                                Real-time Sync
                                                            </option>
                                                            <option value="scheduled" {{ ($credentials->sync_type ?? '') == 'scheduled' ? 'selected' : '' }}>
                                                                Scheduled Sync
                                                            </option>
                                                        </select>
                                                    </div>

                                                    @if($mall_code === 'hcm')
                                                    <div class="form-group">
                                                        <label class="form-label">
                                                            <i class="fas fa-cogs tw-mr-1"></i>
                                                            HCM Sync Features
                                                        </label>
                                                        <div class="row">
                                                            <div class="col-6">
                                                                <div class="form-check">
                                                                    <input class="form-check-input" type="checkbox" name="sync_features[]" value="card_sales" id="card_sales_{{ $location->id }}" checked>
                                                                    <label class="form-check-label" for="card_sales_{{ $location->id }}">
                                                                        Card Sales
                                                                    </label>
                                                                </div>
                                                                <div class="form-check">
                                                                    <input class="form-check-input" type="checkbox" name="sync_features[]" value="cash_sales" id="cash_sales_{{ $location->id }}" checked>
                                                                    <label class="form-check-label" for="cash_sales_{{ $location->id }}">
                                                                        Cash Sales
                                                                    </label>
                                                                </div>
                                                                <div class="form-check">
                                                                    <input class="form-check-input" type="checkbox" name="sync_features[]" value="mixed_transactions" id="mixed_transactions_{{ $location->id }}" checked>
                                                                    <label class="form-check-label" for="mixed_transactions_{{ $location->id }}">
                                                                        Mixed Transactions
                                                                    </label>
                                                                </div>
                                                                <div class="form-check">
                                                                    <input class="form-check-input" type="checkbox" name="sync_features[]" value="returns" id="returns_{{ $location->id }}" checked>
                                                                    <label class="form-check-label" for="returns_{{ $location->id }}">
                                                                        Returns & Exchanges
                                                                    </label>
                                                                </div>
                                                                <div class="form-check">
                                                                    <input class="form-check-input" type="checkbox" name="sync_features[]" value="refunds" id="refunds_{{ $location->id }}" checked>
                                                                    <label class="form-check-label" for="refunds_{{ $location->id }}">
                                                                        Refunds & Voids
                                                                    </label>
                                                                </div>
                                                            </div>
                                                            <div class="col-6">
                                                                <div class="form-check">
                                                                    <input class="form-check-input" type="checkbox" name="sync_features[]" value="hcm_vouchers" id="hcm_vouchers_{{ $location->id }}" checked>
                                                                    <label class="form-check-label" for="hcm_vouchers_{{ $location->id }}">
                                                                        HCM Voucher Redemption
                                                                    </label>
                                                                </div>
                                                                <div class="form-check">
                                                                    <input class="form-check-input" type="checkbox" name="sync_features[]" value="discounts" id="discounts_{{ $location->id }}" checked>
                                                                    <label class="form-check-label" for="discounts_{{ $location->id }}">
                                                                        Discounts
                                                                    </label>
                                                                </div>
                                                                <div class="form-check">
                                                                    <input class="form-check-input" type="checkbox" name="sync_features[]" value="gift_voucher_sale" id="gift_voucher_sale_{{ $location->id }}" checked>
                                                                    <label class="form-check-label" for="gift_voucher_sale_{{ $location->id }}">
                                                                        Gift Voucher Sales
                                                                    </label>
                                                                </div>
                                                                <div class="form-check">
                                                                    <input class="form-check-input" type="checkbox" name="sync_features[]" value="gift_voucher_redemption" id="gift_voucher_redemption_{{ $location->id }}" checked>
                                                                    <label class="form-check-label" for="gift_voucher_redemption_{{ $location->id }}">
                                                                        Gift Voucher Redemption
                                                                    </label>
                                                                </div>
                                                                <div class="form-check">
                                                                    <input class="form-check-input" type="checkbox" name="sync_features[]" value="loyalty_mobile" id="loyalty_mobile_{{ $location->id }}" checked>
                                                                    <label class="form-check-label" for="loyalty_mobile_{{ $location->id }}">
                                                                        Loyalty Mobile Numbers
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <label class="form-label">
                                                            <i class="fas fa-clock tw-mr-1"></i>
                                                            Sync Frequency (minutes)
                                                        </label>
                                                        <select class="form-control form-control-sm" name="sync_frequency">
                                                            <option value="15">Every 15 minutes</option>
                                                            <option value="30">Every 30 minutes</option>
                                                            <option value="60" selected>Every hour</option>
                                                            <option value="240">Every 4 hours</option>
                                                            <option value="1440">Daily</option>
                                                        </select>
                                                    </div>
                                                    @endif

                                                    <div class="d-flex justify-content-between">
                                                        <button type="submit" class="btn btn-primary btn-sm">
                                                            <i class="fas fa-save tw-mr-1"></i>
                                                            Save Credentials
                                                        </button>

                                                        @if($hasCredentials)
                                                            <div class="btn-group" role="group">
                                                                <button type="button" 
                                                                        class="btn btn-success btn-sm sync-location-btn"
                                                                        data-location-id="{{ $location->id }}"
                                                                        data-location-name="{{ $location->name }}">
                                                                    <i class="fas fa-sync tw-mr-1"></i>
                                                                    Sync Now
                                                                </button>
                                                                @if($mall_code === 'hcm')
                                                                <button type="button" 
                                                                        class="btn btn-info btn-sm generate-report-btn"
                                                                        data-location-id="{{ $location->id }}"
                                                                        data-location-name="{{ $location->name }}">
                                                                    <i class="fas fa-file-excel tw-mr-1"></i>
                                                                    Day-End Report
                                                                </button>
                                                                <button type="button" 
                                                                        class="btn btn-warning btn-sm test-sample-btn"
                                                                        data-location-id="{{ $location->id }}"
                                                                        data-location-name="{{ $location->name }}">
                                                                    <i class="fas fa-receipt tw-mr-1"></i>
                                                                    Test Sample
                                                                </button>
                                                                <button type="button" 
                                                                        class="btn btn-secondary btn-sm pos-ping-btn"
                                                                        data-location-id="{{ $location->id }}"
                                                                        data-location-name="{{ $location->name }}">
                                                                    <i class="fas fa-satellite-dish tw-mr-1"></i>
                                                                    POS Ping
                                                                </button>
                                                                @endif
                                                            </div>
                                                        @endif
                                                    </div>
                                                </form>

                                                @if($credentials && $credentials->last_synced_at)
                                                    <div class="mt-2 text-muted small">
                                                        <i class="fas fa-clock tw-mr-1"></i>
                                                        Last synced: {{ $credentials->last_synced_at->diffForHumans() }}
                                                    </div>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- Loading Modal -->
<div class="modal fade" id="loadingModal" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-body text-center">
                <div class="spinner-border text-primary" role="status">
                    <span class="sr-only">Loading...</span>
                </div>
                <div class="mt-2">
                    <span id="loadingText">Processing...</span>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
$(document).ready(function() {
    const mallCode = '{{ $mall_code }}';

    // Show loading modal
    function showLoading(text = 'Processing...') {
        $('#loadingText').text(text);
        $('#loadingModal').modal('show');
    }

    // Hide loading modal
    function hideLoading() {
        $('#loadingModal').modal('hide');
    }

    // Save location credentials
    $('.location-credentials-form').on('submit', function(e) {
        e.preventDefault();

        const form = $(this);
        const locationId = form.data('location-id');
        const formData = form.serialize() + '&location_id=' + locationId;

        showLoading('Saving credentials...');

        $.ajax({
            url: `/gallface/${mallCode}/location-credentials`,
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: formData,
            success: function(response) {
                hideLoading();
                if (response.success) {
                    toastr.success('Credentials saved successfully');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    toastr.error(response.message || 'Failed to save credentials');
                }
            },
            error: function(xhr) {
                hideLoading();
                if (xhr.status === 422) {
                    const errors = xhr.responseJSON.errors;
                    let errorMessage = 'Validation failed:\n';
                    Object.keys(errors).forEach(key => {
                        errorMessage += '- ' + errors[key].join(', ') + '\n';
                    });
                    toastr.error(errorMessage);
                } else {
                    toastr.error('Failed to save credentials');
                }
            }
        });
    });

    // Test connection
    $('.test-connection-btn').on('click', function() {
        const locationId = $(this).data('location-id');
        const locationName = $(this).data('location-name');

        showLoading(`Testing connection for ${locationName}...`);

        $.ajax({
            url: `/gallface/${mallCode}/location/${locationId}/test`,
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                hideLoading();
                if (response.success) {
                    toastr.success('Connection test successful');
                } else {
                    toastr.error(response.message || 'Connection test failed');
                }
            },
            error: function() {
                hideLoading();
                toastr.error('Connection test failed');
            }
        });
    });

    // Sync location
    $('.sync-location-btn').on('click', function() {
        const locationId = $(this).data('location-id');
        const locationName = $(this).data('location-name');

        if (!confirm(`Start comprehensive sync for ${locationName}?\n\nThis will sync all enabled transaction types including:\n- Card and Cash Sales\n- Mixed Transactions\n- Returns, Exchanges, Refunds, Voids\n- HCM Voucher Redemptions\n- Gift Voucher Sales & Redemptions\n- Loyalty Mobile Numbers\n- Discounts`)) {
            return;
        }

        showLoading(`Syncing comprehensive sales data for ${locationName}...`);

        $.ajax({
            url: `/gallface/${mallCode}/location/${locationId}/sync`,
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                hideLoading();
                if (response.success) {
                    toastr.success(response.message || 'Comprehensive sync completed successfully');
                    if (response.records_synced) {
                        toastr.info(`${response.records_synced} records synced successfully`);
                    }
                    setTimeout(() => location.reload(), 3000);
                } else {
                    toastr.error(response.message || 'Sync failed');
                }
            },
            error: function(xhr) {
                hideLoading();
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    toastr.error(xhr.responseJSON.message);
                } else {
                    toastr.error('Sync request failed');
                }
            }
        });
    });

    // Generate day-end report (HCM specific)
    $('.generate-report-btn').on('click', function() {
        const locationId = $(this).data('location-id');
        const locationName = $(this).data('location-name');
        const today = new Date().toISOString().split('T')[0];

        if (!confirm(`Generate day-end Excel report for ${locationName} (${today})?`)) {
            return;
        }

        showLoading(`Generating day-end report for ${locationName}...`);

        $.ajax({
            url: `/gallface/${mallCode}/location/${locationId}/day-end-report`,
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: {
                date: today
            },
            success: function(response) {
                hideLoading();
                if (response.success) {
                    toastr.success('Day-end report generated successfully');
                    if (response.download_url) {
                        window.open(response.download_url, '_blank');
                    }
                } else {
                    toastr.error(response.message || 'Report generation failed');
                }
            },
            error: function() {
                hideLoading();
                toastr.error('Report generation request failed');
            }
        });
    });

    // Test sample invoice (HCM specific)
    $('.test-sample-btn').on('click', function() {
        const locationId = $(this).data('location-id');
        const locationName = $(this).data('location-name');

        if (!confirm(`Send test sample invoice to HCM for ${locationName}?\n\nThis will include:\n- Mixed payment methods (Card + HCM Gift Card + Cash)\n- Customer mobile number\n- HCM voucher redemption\n- Gift voucher sale\n- All transaction types`)) {
            return;
        }

        showLoading(`Sending test sample invoice for ${locationName}...`);

        $.ajax({
            url: `/gallface/${mallCode}/location/${locationId}/test-sample`,
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                hideLoading();
                if (response.success) {
                    toastr.success('Test sample invoice sent successfully');
                    toastr.info(`Invoice: ${response.sample_invoice.invoice_no}`);
                    console.log('Sample Invoice Data:', response.sample_invoice);
                    console.log('Sync Result:', response.sync_result);
                } else {
                    toastr.error(response.message || 'Test sample failed');
                }
            },
            error: function(xhr) {
                hideLoading();
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    toastr.error(xhr.responseJSON.message);
                } else {
                    toastr.error('Test sample request failed');
                }
            }
        });
    });

    // Send POS ping (HCM specific)
    $('.pos-ping-btn').on('click', function() {
        const locationId = $(this).data('location-id');
        const locationName = $(this).data('location-name');

        showLoading(`Sending POS ping for ${locationName}...`);

        $.ajax({
            url: `/gallface/${mallCode}/location/${locationId}/pos-ping`,
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                hideLoading();
                if (response.success) {
                    toastr.success('POS ping sent successfully - POS is active');
                } else {
                    toastr.error(response.message || 'POS ping failed');
                }
            },
            error: function() {
                hideLoading();
                toastr.error('POS ping request failed');
            }
        });
    });
});
</script>
@endpush
@endsection