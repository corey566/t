<!-- Gallface Module Navigation -->
<nav class="tw-bg-white tw-shadow-sm tw-border-b tw-border-gray-200 tw-mb-4">
    <div class="container-fluid">
        <div class="tw-flex tw-justify-between tw-items-center tw-py-3">
            <div class="tw-flex tw-items-center tw-space-x-4">
                <a href="{{ route('gallface.index') }}" class="tw-flex tw-items-center tw-text-gray-700 hover:tw-text-blue-600 tw-transition-colors">
                    <i class="fas fa-shopping-center tw-mr-2 tw-text-blue-500"></i>
                    <span class="tw-font-semibold">Mall Integration Platform</span>
                </a>

                @if(isset($mall_code) && isset($current_mall))
                    <span class="tw-text-gray-400">></span>
                    <span class="tw-text-gray-600 tw-font-medium">{{ $current_mall['name'] }}</span>
                @endif
            </div>

            @if(isset($mall_code) && isset($current_mall))
                <div class="tw-flex tw-items-center tw-space-x-2">
                    @if($current_mall['has_backend'])
                        <span class="badge badge-success tw-bg-green-100 tw-text-green-800 tw-px-3 tw-py-1">
                            <i class="fas fa-check-circle tw-mr-1"></i>
                            Backend Active
                        </span>
                    @else
                        <span class="badge badge-warning tw-bg-yellow-100 tw-text-yellow-800 tw-px-3 tw-py-1">
                            <i class="fas fa-tools tw-mr-1"></i>
                            Backend Coming Soon
                        </span>
                    @endif

                    <a href="{{ route('gallface.dashboard', $mall_code) }}" class="btn btn-sm btn-outline-primary">
                        <i class="fas fa-tachometer-alt tw-mr-1"></i>
                        Dashboard
                    </a>

                    <a href="{{ route('gallface.setting', $mall_code) }}" class="btn btn-sm btn-outline-secondary">
                        <i class="fas fa-cog tw-mr-1"></i>
                        Settings
                    </a>
                </div>
            @endif
        </div>
    </div>
</nav>

<!-- Help Modals -->
<div class="modal fade" id="helpModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="helpModalTitle">Help</h4>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body" id="helpModalBody">
                <!-- Content will be loaded dynamically -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
function showSyncTypesHelp() {
    $('#helpModalTitle').text('Sync Types Explained');
    $('#helpModalBody').html(`
        <div class="row">
            <div class="col-md-4">
                <div class="card border-primary">
                    <div class="card-header bg-primary text-white">
                        <h5><i class="fas fa-hand-pointer"></i> Manual Sync</h5>
                    </div>
                    <div class="card-body">
                        <p>Sync data only when manually triggered by users.</p>
                        <strong>Best for:</strong>
                        <ul>
                            <li>Testing purposes</li>
                            <li>Occasional sync needs</li>
                            <li>Full control over timing</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-success">
                    <div class="card-header bg-success text-white">
                        <h5><i class="fas fa-bolt"></i> Real-time Sync</h5>
                    </div>
                    <div class="card-body">
                        <p>Automatically sync data immediately when sales are made.</p>
                        <strong>Best for:</strong>
                        <ul>
                            <li>Live inventory updates</li>
                            <li>Immediate CRM updates</li>
                            <li>High-frequency operations</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-info">
                    <div class="card-header bg-info text-white">
                        <h5><i class="fas fa-clock"></i> Scheduled Sync</h5>
                    </div>
                    <div class="card-body">
                        <p>Sync data at specific times (daily, weekly, monthly).</p>
                        <strong>Best for:</strong>
                        <ul>
                            <li>Batch processing</li>
                            <li>Off-peak hours sync</li>
                            <li>Resource optimization</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    `);
    $('#helpModal').modal('show');
}

function showAPIHelp() {
    $('#helpModalTitle').text('API Configuration Guide');
    $('#helpModalBody').html(`
        <div class="alert alert-info">
            <h5><i class="fas fa-info-circle"></i> API Configuration Requirements</h5>
            <p>To integrate with mall CRM systems, you need the following credentials:</p>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <h6><i class="fas fa-link text-primary"></i> API URL</h6>
                <p>The base endpoint URL provided by the mall's API documentation.</p>
                <code>Example: https://api.mallname.com/v1</code>
            </div>
            <div class="col-md-6">
                <h6><i class="fas fa-key text-warning"></i> API Key</h6>
                <p>Unique authentication key for your application.</p>
                <code>Example: sk_live_abc123...</code>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <h6><i class="fas fa-id-card text-success"></i> Client ID</h6>
                <p>Public identifier for your application.</p>
                <code>Example: app_123456789</code>
            </div>
            <div class="col-md-6">
                <h6><i class="fas fa-user-secret text-danger"></i> Client Secret</h6>
                <p>Private key used for secure authentication.</p>
                <code>Example: cs_secret_xyz789...</code>
            </div>
        </div>
        
        <div class="alert alert-warning mt-3">
            <h6><i class="fas fa-shield-alt"></i> Security Best Practices</h6>
            <ul>
                <li>Never share credentials with unauthorized users</li>
                <li>Test connections before saving settings</li>
                <li>Rotate credentials regularly</li>
                <li>Use HTTPS endpoints only</li>
            </ul>
        </div>
    `);
    $('#helpModal').modal('show');
}

function showAbout() {
    $('#helpModalTitle').text('About Mall Integration Platform');
    $('#helpModalBody').html(`
        <div class="text-center mb-4">
            <h3><i class="fas fa-shopping-center text-primary"></i> Mall Integration Platform</h3>
            <p class="lead">Version 6.0</p>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <h5><i class="fas fa-info-circle text-info"></i> Platform Features</h5>
                <ul>
                    <li>Multi-mall CRM integration</li>
                    <li>Real-time sales synchronization</li>
                    <li>Flexible sync scheduling</li>
                    <li>Comprehensive error handling</li>
                    <li>Business location management</li>
                    <li>Secure credential storage</li>
                </ul>
            </div>
            <div class="col-md-6">
                <h5><i class="fas fa-building text-success"></i> Supported Malls</h5>
                <ul>
                    <li><strong>One Galle Face (OGF)</strong> - Active</li>
                    <li><strong>Haveloc City Mall (HCM)</strong> - Active</li>
                    <li><strong>Colombo City Center (CCC)</strong> - Coming Soon</li>
                </ul>
            </div>
        </div>
        
        <hr>
        
        <div class="text-center">
            <p><strong>Developed by:</strong></p>
            <h4><i class="fas fa-code text-primary"></i> Yazeed Company - CodeStudio</h4>
            <p class="text-muted">Professional software development solutions</p>
        </div>
    `);
    $('#helpModal').modal('show');
}
</script>