
@extends('layouts.app')

@section('title', __('Mall Integration Platform'))

@section('content')
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="tw-text-xl md:tw-text-3xl tw-font-bold tw-text-black">
                    <i class="fas fa-shopping-center"></i>
                    Mall Integration Platform
                </h1>
                <p class="tw-text-gray-600 tw-mt-2">Manage integrations with multiple mall CRM systems</p>
            </div>
            <div class="col-sm-6">
                <div class="float-right">
                    <small class="tw-text-gray-500">Powered by Yazeed Company - CodeStudio</small>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="content">
    <div class="container-fluid">
        <div class="row">
            @foreach($malls as $code => $mall)
            <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                <div class="card tw-shadow-lg tw-rounded-xl tw-border-0 tw-transition-transform tw-duration-300 hover:tw-scale-105">
                    <div class="card-header tw-bg-gradient-to-r tw-from-blue-500 tw-to-purple-600 tw-text-white tw-rounded-t-xl">
                        <h3 class="card-title tw-font-bold tw-text-lg">
                            <i class="fas fa-building tw-mr-2"></i>
                            {{ $mall['name'] }}
                        </h3>
                        <div class="card-tools">
                            @if($mall['status'] === 'active')
                                <span class="badge badge-success tw-bg-green-500">
                                    <i class="fas fa-check-circle tw-mr-1"></i>
                                    Active
                                </span>
                            @else
                                <span class="badge badge-warning tw-bg-yellow-500">
                                    <i class="fas fa-clock tw-mr-1"></i>
                                    Coming Soon
                                </span>
                            @endif
                        </div>
                    </div>
                    <div class="card-body tw-p-6">
                        <div class="tw-mb-4">
                            <div class="tw-flex tw-items-center tw-mb-2">
                                <i class="fas fa-code tw-text-blue-500 tw-mr-2"></i>
                                <strong>Code:</strong> 
                                <span class="tw-ml-2 tw-font-mono tw-bg-gray-100 tw-px-2 tw-py-1 tw-rounded">{{ strtoupper($code) }}</span>
                            </div>
                            <div class="tw-flex tw-items-center tw-mb-2">
                                <i class="fas fa-server tw-text-green-500 tw-mr-2"></i>
                                <strong>Backend:</strong> 
                                <span class="tw-ml-2">
                                    @if($mall['has_backend'])
                                        <span class="tw-text-green-600">
                                            <i class="fas fa-check tw-mr-1"></i>
                                            Integrated
                                        </span>
                                    @else
                                        <span class="tw-text-orange-600">
                                            <i class="fas fa-tools tw-mr-1"></i>
                                            In Development
                                        </span>
                                    @endif
                                </span>
                            </div>
                        </div>
                        
                        @if($mall['status'] === 'active')
                            <div class="tw-space-y-2">
                                <a href="{{ route('gallface.dashboard', $code) }}" 
                                   class="btn btn-primary btn-block tw-bg-blue-600 hover:tw-bg-blue-700 tw-transition-colors">
                                    <i class="fas fa-tachometer-alt tw-mr-2"></i>
                                    Open Dashboard
                                </a>
                                <a href="{{ route('gallface.setting', $code) }}" 
                                   class="btn btn-outline-secondary btn-block tw-border-gray-300 hover:tw-bg-gray-100 tw-transition-colors">
                                    <i class="fas fa-cog tw-mr-2"></i>
                                    Settings
                                </a>
                            </div>
                        @else
                            <button class="btn btn-secondary btn-block" disabled>
                                <i class="fas fa-clock tw-mr-2"></i>
                                Coming Soon
                            </button>
                        @endif
                    </div>
                </div>
            </div>
            @endforeach
        </div>
        
        <!-- Quick Stats Overview -->
        <div class="row mt-4">
            <div class="col-12">
                <div class="card tw-shadow-lg tw-rounded-xl tw-border-0">
                    <div class="card-header tw-bg-gray-50 tw-rounded-t-xl">
                        <h3 class="card-title tw-font-bold tw-text-lg">
                            <i class="fas fa-chart-line tw-mr-2 tw-text-blue-500"></i>
                            Integration Overview
                        </h3>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3 col-sm-6">
                                <div class="info-box tw-bg-blue-50">
                                    <span class="info-box-icon tw-bg-blue-500">
                                        <i class="fas fa-shopping-center tw-text-white"></i>
                                    </span>
                                    <div class="info-box-content">
                                        <span class="info-box-text">Total Malls</span>
                                        <span class="info-box-number">{{ count($malls) }}</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-6">
                                <div class="info-box tw-bg-green-50">
                                    <span class="info-box-icon tw-bg-green-500">
                                        <i class="fas fa-check-circle tw-text-white"></i>
                                    </span>
                                    <div class="info-box-content">
                                        <span class="info-box-text">Active Integrations</span>
                                        <span class="info-box-number">{{ collect($malls)->where('status', 'active')->count() }}</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-6">
                                <div class="info-box tw-bg-yellow-50">
                                    <span class="info-box-icon tw-bg-yellow-500">
                                        <i class="fas fa-clock tw-text-white"></i>
                                    </span>
                                    <div class="info-box-content">
                                        <span class="info-box-text">Coming Soon</span>
                                        <span class="info-box-number">{{ collect($malls)->where('status', 'coming_soon')->count() }}</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-6">
                                <div class="info-box tw-bg-purple-50">
                                    <span class="info-box-icon tw-bg-purple-500">
                                        <i class="fas fa-sync tw-text-white"></i>
                                    </span>
                                    <div class="info-box-content">
                                        <span class="info-box-text">Sync Types</span>
                                        <span class="info-box-number">3</span>
                                        <small class="tw-text-gray-500">Manual, Real-time, Scheduled</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
.info-box {
    @apply tw-rounded-lg tw-border-0 tw-shadow-sm;
}
.info-box-icon {
    @apply tw-rounded-lg;
}
</style>
@endsection
