
<?php

use Illuminate\Support\Facades\Route;
use Modules\Gallface\Http\Controllers\GallfaceController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Main module routes
Route::prefix('gallface')->group(function() {
    Route::get('/', [GallfaceController::class, 'index'])->name('gallface.index');
    
    // Mall-specific routes
    Route::prefix('{mall_code}')->group(function() {
        Route::get('/', [GallfaceController::class, 'dashboard'])->name('gallface.dashboard');
        Route::get('/settings', [GallfaceController::class, 'setting'])->name('gallface.setting');
        
        // Location API credentials
        Route::post('/location-credentials', [GallfaceController::class, 'saveLocationCredentials'])->name('gallface.save-credentials');
        
        // Location-specific operations
        Route::prefix('location/{location_id}')->group(function() {
            Route::post('/test', [GallfaceController::class, 'testLocationCredentials'])->name('gallface.test-connection');
            Route::post('/sync', [GallfaceController::class, 'syncLocationSales'])->name('gallface.sync-location');
            Route::post('/day-end-report', [GallfaceController::class, 'generateDayEndReport'])->name('gallface.day-end-report');
            Route::post('/pos-ping', [GallfaceController::class, 'sendPosPing'])->name('gallface.pos-ping');
            Route::post('/test-sample', [GallfaceController::class, 'testSampleInvoice'])->name('gallface.test-sample');
        });
    });
});
