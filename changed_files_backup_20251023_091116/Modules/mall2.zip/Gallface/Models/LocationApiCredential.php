<?php

namespace Modules\Gallface\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Business;
use App\BusinessLocation;

class LocationApiCredential extends Model
{
    protected $table = 'gallface_location_api_credentials';

    protected $fillable = [
        'business_id',
        'business_location_id',
        'mall_code',
        'api_url',
        'api_key',
        'client_id',
        'client_secret',
        'username',
        'password',
        'stall_no',
        'pos_id',
        'sync_type',
        'is_active',
        'additional_settings',
        'last_synced_at'
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'additional_settings' => 'array',
        'last_synced_at' => 'datetime'
    ];

    protected $hidden = [
        'api_key',
        'client_secret',
        'password'
    ];

    public function business(): BelongsTo
    {
        return $this->belongsTo(Business::class);
    }

    public function businessLocation(): BelongsTo
    {
        return $this->belongsTo(BusinessLocation::class);
    }

    /**
     * Get credentials for API service
     */
    public function getCredentialsForApi(): array
    {
        return [
            'api_url' => $this->api_url,
            'api_key' => $this->api_key,
            'client_id' => $this->client_id,
            'client_secret' => $this->client_secret,
            'username' => $this->username,
            'password' => $this->password,
            'stall_no' => $this->stall_no,
            'pos_id' => $this->pos_id,
        ];
    }

    /**
     * Check if credentials are complete
     */
    public function hasCompleteCredentials(): bool
    {
        return !empty($this->api_url) && 
               !empty($this->api_key) && 
               !empty($this->client_id) && 
               !empty($this->client_secret);
    }
}
